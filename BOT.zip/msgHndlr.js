const { decryptMedia } = require('@open-wa/wa-decrypt')
const fs = require('fs-extra')
const moment = require('moment-timezone')
const get = require('got')
const color = require('./lib/color')
const { spawn, exec } = require('child_process')
const translate = require('@vitalets/google-translate-api')
const { liriklagu, quotemaker, fb, sleep } = require('./lib/functions')
const { authormenu, ownermenu, adminmenu, modmenu, menu, nsfwmenu, bot, sk, info, shortcut, donate, cerdas, template, kode, intro } = require('./lib/menu')
const { msgFilter } = require('./lib/msgFilter')
const { stdout } = require('process')
const cmd = JSON.parse(fs.readFileSync('./lib/cmd.json'))
const nsfw_ = JSON.parse(fs.readFileSync('./lib/NSFW.json'))
moment.tz.setDefault('Asia/Jakarta').locale('id')
module.exports = msgHandler = async (client, message) => {
    try {
        const { type, id, from, t, sender, isGroupMsg, chat, caption, isMedia, mimetype, quotedMsg, quotedMsgObj, mentionedJidList, author } = message
        let { body } = message
        const { name, formattedTitle } = chat
        let { pushname, verifiedName } = sender
        pushname = pushname || verifiedName
        const commands = caption || body || ''
        const command = commands.toLowerCase().split(' ')[0] || ''
        const args =  commands.split(' ')
        const msgs = (message) => {
            if (command.startsWith('.')) {
                if (message.length >= 10) {
                    return `${message.substr(0, 15)}`
                } else {
                    return `${message}`
                }
            }
        }
        const mess = {
            author: '⚠️ Perintah ini hanya bisa digunakan oleh Author Bot senpai!',
            group: '⚠️ Perintah ini hanya bisa digunakan dalam Group senpai!',
            owner: '⚠️ Perintah ini hanya bisa digunakan oleh Owner Group senpai!',
            admin: '⚠️ Perintah ini hanya bisa digunakan oleh Admin Group senpai!',
            mod: '⚠️ Perintah ini hanya bisa digunakan oleh Admin & Moderator Group senpai!',
            bot: '⚠️ Perintah ini hanya bisa digunakan ketika Bot menjadi Admin senpai!',
            cmd: '⚠️ Command belum diaktifkan senpai!',
            nsfw: '⚠️ Command NSFW belum diaktifkan senpai!',
            spam: '⚠️ Baka, senpai spam!',
            ban: '⚠️ Baka, senpai diban!',
            wait: '⏳ Sedang di proses, silahkan tunggu sebentar senpai!',
            link: '⚠️ Link tidak valid senpai!',
            null: '⚠️ Tidak ada hasil senpai!',
            theme: '⚠️ Tema tidak tersedia senpai!',
        }
        const time = moment(t * 1000).format('DD/MM HH:mm:ss')
        const botNumber = await client.getHostNumber()
        const blockNumber = await client.getBlockedIds()
        const groupId = isGroupMsg ? chat.groupMetadata.id : ''
        const groupAdmins = isGroupMsg ? await client.getGroupAdmins(groupId) : ''
        const isGroupAdmins = isGroupMsg ? groupAdmins.includes(sender.id) : false
        const isBotGroupAdmins = isGroupMsg ? groupAdmins.includes(botNumber + '@c.us') : false
        const isBlocked = blockNumber.includes(sender.id)
        const isCmd = isGroupMsg ? cmd.includes(chat.id) : false
        const isNsfw = isGroupMsg ? nsfw_.includes(chat.id) : false
        const pahrulNumber = '6289527504647@c.us'
        const dausNumber = '6283166439105@c.us'
        const abiNumber = '6285775297461@c.us'
        const bayuNumber = '6285242812945@c.us'
        const moderatorNumber = '6285776974518@c.us'
        const moderatorNumber2 = '62859196400094@c.us'
        const isPahrul = sender.id === pahrulNumber
        const isDaus = sender.id === dausNumber
        const isAbi = sender.id === abiNumber
        const isBayu = sender.id === bayuNumber
        const isModerator = sender.id === moderatorNumber 
        const isModerator2 = sender.id === moderatorNumber2
        const uaOverride = 'WhatsApp/2.2029.4 Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'
        const isUrl = new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/gi)
        if (command.startsWith('.') && msgFilter.isFiltered(from) && !isGroupMsg) { 
            await client.reply(from, mess.spam, id)
            return console.log(color('[SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname)) 
        }
        if (command.startsWith('.') && msgFilter.isFiltered(from) && isGroupMsg) { 
            await client.reply(from, mess.spam, id)
            return console.log(color('[SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle)) 
        } 
        if (!isGroupMsg && command.startsWith('.')) console.log('\x1b[1;31m~\x1b[1;37m>.', '[\x1b[1;32mEXEC\x1b[1;37m].', time, color(msgs(command)), 'from.', color(pushname))
        if (isGroupMsg && command.startsWith('.')) console.log('\x1b[1;31m~\x1b[1;37m>.', '[\x1b[1;32mEXEC\x1b[1;37m].', time, color(msgs(command)), 'from.', color(pushname), 'in.', color(formattedTitle))
        if (!isGroupMsg && !command.startsWith('.')) console.log('\x1b[1;33m~\x1b[1;37m>.', '[\x1b[1;31mMSG\x1b[1;37m].', time, color(body), 'from.', color(pushname))
        if (isGroupMsg && !command.startsWith('.')) console.log('\x1b[1;33m~\x1b[1;37m>.', '[\x1b[1;31mMSG\x1b[1;37m].', time, color(body), 'from.', color(pushname), 'in.', color(formattedTitle))
        msgFilter.addFilter(from)
        switch(command) {
        case '.':  case '!':  case '/':  case '#': case '!menu': case '/menu': case '#menu': case '.help': case '!help': case '/help': case '#help':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, '⚠️ Perintah salah senpai!\nKetik *.menu* untuk melihat perintah yang tersedia!', id)
            break    
        
        case '.kis': case '.authormenu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isPahrul) return client.reply(from, mess.author, id)
            await client.reply(from, authormenu, id)
            break          
        case '.ssbot':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isPahrul) return client.reply(from, mess.author, id)
            const sesPic = await client.getSnapshot()
            await client.sendFile(from, sesPic, 'session.png', 'Nih senpai!', id)
            break
        case '.outall':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isPahrul) return client.reply(from, mess.author, id)
            const allGroups = await client.getAllGroups()
            for (let gclist of allGroups) {
                await client.reply(from, 'Sayonara mina-san 👋🥺', id)
                await client.leaveGroup(gclist.contact.id)
            }
            break
        case '.clearall':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isPahrul) return client.reply(from, mess.author, id)
            const allChatz = await client.getAllChats()
            for (let dchat of allChatz) {
                await client.reply(from, '✅ Perintah diterima senpai, clear all chat!', id)
                await client.clearChat(dchat.id)
            }
            break

        case '.om': case '.ownermenu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            const isGroupOwner = sender.id === chat.groupMetadata.owner
            if (!isGroupOwner) return client.reply(from, mess.owner, id)
            await client.reply(from, ownermenu, id)
            break      
        case '.kickall':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupOwner) return client.reply(from, mess.owner, id)
            if (!isBotGroupAdmins) return client.reply(from, mess.bot, id)
            const allMem = await client.getGroupMembers(groupId)
            for (let i = 0; i < allMem.length; i++) {
                if (groupAdmins.includes(allMem[i].id)) {
                    await client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa kick Member saja!', id)
                } else {
                    await client.removeParticipant(groupId, allMem[i].id)
                }
            }
            client.reply(from, '✅ Perintah diterima senpai, kick all Member dari Group!', id)
            break   
        
        case '.am': case '.adminmenu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            await client.reply(from, adminmenu, id)
            break  
        case '.a': case '.all':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            const groupMem = await client.getGroupMembers(groupId)
            let hehe = `Everyone : ${groupMem.length}\n`
            for (let i = 0; i < groupMem.length; i++) {
                hehe += `@${groupMem[i].id.replace(/@c.us/g, '')}\n`
            }
            await sleep(2000)
            await client.sendTextWithMentions(from, hehe, id)
            break
        case '.promote':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            if (mentionedJidList.length === 0) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.promote* _@member_\nContoh : *.promote* _@jihyo_', id)
            if (mentionedJidList.length >= 2) return client.reply(from, '⚠️ Maaf senpai, perintah ini hanya dapat digunakan kepada 1 Member!', id)
            if (groupAdmins.includes(mentionedJidList[0])) return client.reply(from, '⚠️ Maaf senpai, Member tersebut sudah menjadi Admin!', id)
            if (!isBotGroupAdmins) return client.reply(from, mess.bot, id)
            await client.sendTextWithMentions(from, `✅ Perintah diterima senpai, mengangkat @${mentionedJidList[0]} sebagai Admin!`, id)
            await client.promoteParticipant(groupId, mentionedJidList[0])
            break
        case '.demote':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            if (mentionedJidList.length === 0) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.demote* _@admin_\nContoh : *.demote* _@jokowi_', id)
            if (mentionedJidList.length >= 2) return client.reply(from, '⚠️ Maaf senpai, perintah ini hanya dapat digunakan kepada 1 Admin!', id)
            if (!groupAdmins.includes(mentionedJidList[0])) return client.reply(from, '⚠️ Maaf senpai, Member tersebut sudah tidak menjadi Admin!', id)
            if (!isBotGroupAdmins) return client.reply(from, mess.bot, id)
            await client.sendTextWithMentions(from, `✅ Perintah diterima senpai, munurunkan @${mentionedJidList[0]} dari jabatan Admin!`, id)
            await client.demoteParticipant(groupId, mentionedJidList[0])
            break
        case '.k': case '.kick':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            if (mentionedJidList.length === 0) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.kick* _@member_\nContoh : *.kick* _@jokowi_', id)
            for (let i = 0; i < mentionedJidList.length; i++) {
            if (groupAdmins.includes(mentionedJidList[i])) return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa kick Member saja!', id)
            if (!isBotGroupAdmins) return client.reply(from, mess.bot, id)
            await client.sendTextWithMentions(from, `✅ Perintah diterima senpai, kick @${mentionedJidList[0]} dari Group!`, id)
            await client.removeParticipant(groupId, mentionedJidList[i])
            }
            break
        case '.d': case '.delete':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isGroupAdmins) && (!isModerator) && (!isModerator2)) return client.reply(from, mess.mod, id)
            if (!quotedMsg) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.delete* _[hapus chat bot]_\nNote : Reply chat yang ingin dihapus', id)
            if (!quotedMsgObj.fromMe) return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa hapus chatnya saja!', id)
            await client.reply(from, '✅ Perintah diterima senpai, delete chat!', id)
            await client.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break
        case '.out':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            await client.sendText(from,'Sayonara mina-san 👋🥺', id).then(() => client.leaveGroup(groupId))
            break
        case '.cmd':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isPahrul) && (!isDaus) && (!isAbi) && (!isBayu)) return client.reply(from, mess.admin, id)
            if (args.length === 1) return client.reply(from, '⚠️ Pilih on/off senpai!', id)
            if (args[1].toLowerCase() === 'on') {
                cmd.push(chat.id)
                fs.writeFileSync('./lib/cmd.json.', JSON.stringify(cmd))
                await client.reply(from, '🌝 Command diaktifkan senpai!', id)
            } else if (args[1].toLowerCase() === 'off') {
                cmd.splice(chat.id, 1)
                fs.writeFileSync('./lib/cmd.json.', JSON.stringify(cmd))
                await client.reply(from, '🌚 Command dinonaktifkan senpai!', id)
            } else {
                await client.reply(from, '⚠️ Pilih on/off senpai!', id)
            }
            break 
        case '.ban':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isPahrul) && (!isDaus) && (!isAbi) && (!isBayu) && (!isModerator) && (!isModerator2)) return client.reply(from, mess.mod, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.ban* _nomor_\nContoh : *.ban* _6282227504647_', id)
            if (!args[1].includes('628')) return client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.ban* _nomor_\nContoh : *.ban* _6282227504647_`, id)
            if (args[1].includes('@')) return client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.ban* _nomor_\nContoh : *.ban* _6282227504647_`, id)
            if (args[1] === '6289527504647') return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa ban Member saja!', id)
            if (args[1] === '6285775297461') return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa ban Member saja!', id)
            if (args[1] === '6283166439105') return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa ban Member saja!', id)
            if (args[1] === '6285242812945') return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa ban Member saja!', id)
            if (args[1] === '6289527506749') return client.reply(from, '⚠️ Maaf senpai, Bot cuma bisa ban Member saja!', id)
            const banq = args[1]
            const banq2 = (banq + '@c.us')
            await client.sendTextWithMentions(from, `✅ Perintah diterima senpai, ban @${args[1]}`, id)
            await client.contactBlock(banq2)
            break
        case '.unban':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isPahrul) && (!isDaus) && (!isAbi) && (!isBayu) && (!isModerator) && (!isModerator2)) return client.reply(from, mess.mod, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.unban* _nomor_\nContoh : *.unban* _6282227504647_', id)
            if (!args[1].includes('628')) return client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.unban* _nomor_\nContoh : *.unban* _6282227504647_`, id)
            const unbanq = args[1]
            const unbanq2 = (unbanq + '@c.us')
            await client.sendTextWithMentions(from, `✅ Perintah diterima senpai, unban @${args[1]}`, id)
            await client.contactUnblock(unbanq2)
            break
        case '.banned':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isPahrul) && (!isDaus) && (!isAbi) && (!isBayu) && (!isModerator) && (!isModerator2)) return client.reply(from, mess.mod, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (blockNumber.length == 0) return client.reply(from, `Tidak ada yang diban senpai!`, id)
            let hih = `Banned : ${blockNumber.length}\n`
            for (let i of blockNumber) {
                hih += `@${i.replace(/@c.us/g,'')}\n`
            }
            await client.sendTextWithMentions(from, hih, id)
            break
        case '.link':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            if (!isBotGroupAdmins) return client.reply(from, mess.bot, id)
            const inviteLink = await client.getGroupInviteLink(groupId);
            await client.sendLinkWithAutoPreview(from, inviteLink, ``)
            break
        case '.revoke':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isGroupAdmins) return client.reply(from, mess.admin, id)
            if (!isBotGroupAdmins) return client.reply(from, mess.bot, id)
            await client.reply(from, `✅ Perintah diterima senpai, revoke link Group!`, id)
            await client.revokeGroupInviteLink(groupId)
            break
        case '.nsfw':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isPahrul) && (!isDaus) && (!isAbi) && (!isBayu)) return client.reply(from, mess.admin, id)
            if (args.length === 1) return client.reply(from, '⚠️ Pilih on/off senpai!', id)
            if (args[1].toLowerCase() === 'on') {
                nsfw_.push(chat.id)
                fs.writeFileSync('./lib/NSFW.json.', JSON.stringify(nsfw_))
                await client.reply(from, '🌝 NSFW Command diaktifkan senpai!\nKetik *.nsfwmenu* untuk melihat perintah NSFW!', id)
            } else if (args[1].toLowerCase() === 'off') {
                nsfw_.splice(chat.id, 1)
                fs.writeFileSync('./lib/NSFW.json.', JSON.stringify(nsfw_))
                await client.reply(from, '🌚 NSFW Command dinonaktifkan senpai!', id)
            } else {
                await client.reply(from, '⚠️ Pilih on/off senpai!', id)
            }
            break 
   
        case '.mm': case '.modmenu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if ((!isGroupAdmins) && (!isModerator) && (!isModerator2)) return client.reply(from, mess.mod, id)
            await client.reply(from, modmenu, id)
            break  

        case '.m': case '.menu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, menu, id)
            break   
        case '.p':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, 'Salam yang benar senpai 😤', id) 
            break
        case '.hi': case '.halo': case '.hello':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, 'Hola senpai 👋😁', id) 
            break
        case '.salam':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, 'Waalaikumussalam senpai 👋😁', id)
            break
        case '.ping':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            /**
            * Get Time duration
            * @param  {Date} timestamp
            * @param  {Date} now
            */
            const processTime = (timestamp, now) => {
            return moment.duration(now - moment(timestamp * 1000)).asSeconds()
            }
            await client.reply(from, `Pong! ⏳ ${processTime(t, moment())}s`, id)
            break
        case '.author':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.sendTextWithMentions(from, `Author Bot : @${pahrulNumber}`, id)
            break
        case '.owner':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            const Owner_ = chat.groupMetadata.owner
            await client.sendTextWithMentions(from, `Owner Group : @${Owner_}`, id)
            break
        case '.admin':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            let mimin = 'Admin Group :\n'
            for (let admon of groupAdmins) {
                mimin += `@${admon.replace(/@c.us/g, '')}\n` 
            }
            await sleep(2000)
            await client.sendTextWithMentions(from, mimin, id)
            break
        case '.moderator':
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (isBlocked) return client.reply(from, mess.ban, id)
            let mimin2 = `Moderator Group :\n@${moderatorNumber}\n@${moderatorNumber2.replace(/@c.us/g, '')}`
            await client.sendTextWithMentions(from, mimin2, id)
            break
        case '.intro': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            await client.reply(from, intro, id)
            break      

        case '.wiki':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.wiki* _kata kunci_\nContoh : *.wiki* _jihyo_', id)
            const wiki = await get.get('https://mhankbarbar.herokuapp.com/api/wiki?q='+body.slice(6)+'&lang=id&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (wiki.error) {
                await client.reply(from, mess.null, id)
            } else {
                await client.reply(from, wiki.result, id)
            }
            break
        case '.wiki2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.wiki2* _kata kunci_\nContoh : *.wiki2* _jihyo_', id)
            const wiki2 = await get.get('https://mhankbarbar.herokuapp.com/api/wiki?q='+body.slice(7)+'&lang=en&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (wiki2.error) {
                await client.reply(from, mess.null, id)
            } else {
                await client.reply(from, wiki2.result, id)
            }
            break
        case '.brainly':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const brainly = require('brainly-scraper')
            module.exports = BrainlySearch = (pertanyaan, jumlah, cb) => {
            brainly(pertanyaan.toString(),Number(jumlah)).then((res) => {
            let brainlyResult = []
            res.data.forEach((ask) => {
            let opt = {
                pertanyaan: ask.pertanyaan,
                fotoPertanyaan: ask.questionMedia
            }
            ask.jawaban.forEach(answer => {
                opt.jawaban = {
                    judulJawaban: answer.text,
                    fotoJawaban: answer.media
                }
            })
            brainlyResult.push(opt)
            })
            return brainlyResult
            }).then(x => {
            cb(x)
            }).catch(err => {
            console.log(err.error)
            })
            }
            if (args.length >= 2){
                let tanya = body.slice(9)
                let jum = Number(tanya.split('.')[1]) || 1
                if (jum > 10) return client.reply(from, '⚠️ Maaf senpai, maksimal 10 jawaban!', id)
                if (Number(tanya[tanya.length-1])){
                    tanya
                }
                await BrainlySearch(tanya.split('.')[0],Number(jum), function(res){
                    res.forEach(x=>{
                        if (x.jawaban.fotoJawaban.length == 0) {
                            client.reply(from, `Pertanyaan : ${x.pertanyaan}\n\nJawaban : ${x.jawaban.judulJawaban}\n`, id)
                        } else {
                            client.reply(from, `Pertanyaan : ${x.pertanyaan}\n\nJawaban : ${x.jawaban.judulJawaban}\n\nLink : ${x.jawaban.fotoJawaban.join('\n')}`, id)
                        }
                    })
                })
            } else {
                await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.brainly* _pertanyaan/pertanyaan .1-10_\nContoh : *.brainly* _apakah pahrul gay?/apakah pahrul gay? .1-10_\nNote : .1-10 adalah jumlah jawaban yang diinginkan.', id)
            }
            break
        case '.translate':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.translate* _kode teks/kode [reply chat]_`, id)
            if (quotedMsg) {
                const dataTextReal = quotedMsg.type == 'chat' ? quotedMsg.body : quotedMsg.type == 'image' ? quotedMsg.caption : ''
                const lang = args[1].toString()
                    const trans = async (dataText, lang) => {
                    console.log(`Translate text to ${lang}...`)
                    const result = await translate(dataTextReal, {
                        to: lang
                        })
                        .then((res) => client.reply(from, res.text, id))
                        .catch((err) => client.reply(from, mess.null, id))
                }
                trans(dataTextReal, lang) 
            } else if (args.length >= 2) {
                const dataTextManu = body.slice(13)
                const lang = args[1].toString()
                    const trans = async (dataText, lang) => {
                    console.log(`Translate text to ${lang}...`)
                    const result = await translate(dataTextManu, {
                        to: lang
                        })
                        .then((res) => client.reply(from, res.text, id))
                        .catch((err) => client.reply(from, mess.null, id))
                }
                trans(dataTextManu, lang)
            } else {
                await client.reply(from, mess.null, id)
            }
            break
        case '.math':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const math = require('mathjs')
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.math* _[kabataku]_\nContoh : *.math* _6+9_', id)
            const math2 = math.evaluate(body.slice(6))
            await client.reply(from, `${math2}`, id)
            break
        case '.note':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.note* _teks_\nContoh : *.note* _jihyo_', id)
            const note = await get.get('https://mhankbarbar.herokuapp.com/nulis?text='+body.slice(6)+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, note.result, 'note.jpg', `Nih senpai!`, id)
            break
        case '.tts':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.tts* _kode teks_\nContoh : *.tts* _en dasar cebong_\nNote : ketik *.kode* untuk melihat kode bahasa!', id)
            const ttsId = require('node-gtts')('id')
            const ttsEn = require('node-gtts')('en')
            const ttsJp = require('node-gtts')('ja')
            const ttsAr = require('node-gtts')('ar')
            const ttsZh = require('node-gtts')('zh')
            const ttsDe = require('node-gtts')('de')
            const ttsRu = require('node-gtts')('ru')
            const ttsKo = require('node-gtts')('ko')
            const ttsEs = require('node-gtts')('es')
            const ttsPt = require('node-gtts')('pt')
            const ttsAf = require('node-gtts')('af')
            const ttsNl = require('node-gtts')('nl')
            const ttsIt = require('node-gtts')('it')
            const ttsHi = require('node-gtts')('hi')
            const ttsTa = require('node-gtts')('ta')
            const ttsTh = require('node-gtts')('th')
            const ttsTr = require('node-gtts')('tr')
            const dataText = body.slice(8)
            if (dataText === '') return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.tts* _kode teks_\nContoh : *.tts* _en dasar cebong_\nNote : ketik *.kode* untuk melihat kode bahasa!', id)
            if (dataText.length > 500) return client.reply(from, '⚠️ Maaf senpai, teks terlalu panjang!', id)
            var dataBhs = body.slice(5, 7)
            if (dataBhs == 'id') {
                ttsId.save('./media/tts/resId.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resId.mp3', id)
                })
            } else if (dataBhs == 'en') {
                ttsEn.save('./media/tts/resEn.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resEn.mp3', id)
                })
            } else if (dataBhs == 'jp') {
                ttsJp.save('./media/tts/resJp.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resJp.mp3', id)
                })
            } else if (dataBhs == 'ar') {
                ttsAr.save('./media/tts/resAr.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resAr.mp3', id)
                })
            } else if (dataBhs == 'zh') {
                ttsZh.save('./media/tts/resZh.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resZh.mp3', id)
                })
            } else if (dataBhs == 'de') {
                ttsDe.save('./media/tts/resDe.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resDe.mp3', id)
                })
            } else if (dataBhs == 'ru') {
                ttsRu.save('./media/tts/resRu.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resRu.mp3', id)
                })
            } else if (dataBhs == 'ko') {
                ttsKo.save('./media/tts/resKo.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resKo.mp3', id)
                })
            } else if (dataBhs == 'es') {
                ttsEs.save('./media/tts/resEs.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resEs.mp3', id)
                })
            } else if (dataBhs == 'pt') {
                ttsPt.save('./media/tts/resPt.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resPt.mp3', id)
                })
            } else if (dataBhs == 'af') {
                ttsAf.save('./media/tts/resAf.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resAf.mp3', id)
                })
            } else if (dataBhs == 'nl') {
                ttsNl.save('./media/tts/resNl.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resNl.mp3', id)
                })
            } else if (dataBhs == 'it') {
                ttsIt.save('./media/tts/resIt.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resIt.mp3', id)
                })
            } else if (dataBhs == 'hi') {
                ttsHi.save('./media/tts/resHi.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resHi.mp3', id)
                })
            } else if (dataBhs == 'ta') {
                ttsTa.save('./media/tts/resTa.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resTa.mp3', id)
                })
            } else if (dataBhs == 'th') {
                ttsTh.save('./media/tts/resTh.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resTh.mp3', id)
                })
            } else if (dataBhs == 'tr') {
                ttsTr.save('./media/tts/resTr.mp3', dataText, function () {
                    client.sendPtt(from, './media/tts/resTr.mp3', id)
                })
            } else {
                await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.tts* _kode teks_\nContoh : *.tts* _en dasar cebong_\nNote : ketik *.kode* untuk melihat kode bahasa!', id)
            }
            break
        case '.kode': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, kode, id)
            break   
        
        case '.write':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.write* _teks_\nContoh : *.write* _jihyo_', id)
            await client.reply(from, body.slice(7), id)
            break 
        case '.alay':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.alay* _teks_\nContoh : *.alay* _jihyo_', id)
            const alay = await get.get('https://api.terhambar.com/bpk?kata='+body.slice(6)).json()
            await client.reply(from, alay.text, id)
            break
        case '.hilih':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.hilih* _teks_\nContoh : *.hilih* _jihyo_', id)
            const hilih = await get.get('https://api.i-tech.id/tools/hilih?key=JDPQSX-rz6Wf0-DgfTRY-SXsBB8-oX1ZMU&kata='+body.slice(7)).json()
            await client.reply(from, hilih.result, id)
            break
        case '.cool':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.cool* _teks_\nContoh : *.cool* _iri bilang bos_', id)
            const cool = await get.get('https://api.haipbis.xyz/randomcooltext?text='+body.slice(6)).json()
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, cool.image, 'cool.jpg', `Nih senpai!`, id)
            break 
        case '.simi':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.simi* _teks_\nContoh : *.simi* _jihyo_', id)
            const simi = await get.get('https://simsumi.herokuapp.com/api?text='+body.slice(6)+'&lang=id').json()
            if (simi.success == "") return client.reply(from, mess.null, id)
            await client.reply(from, simi.success, id)
            break
        case '.quotes':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const quotes = await get.get('https://api.terhambar.com/qts/').json()
            await client.reply(from, quotes.quotes, id)
            break
        case '.quotes2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const quotes2 = await get.get('https://api.haipbis.xyz/randomquotes').json()
            await client.reply(from, `${quotes2.quote}\n\nAuthor : ${quotes2.author}\n\nCategory : ${quotes2.category}`, id)
            break
        case '.nimequotes':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const nimequotes = await get.get('https://api.haipbis.xyz/randomanimequotes').json()
            await client.reply(from, nimequotes.simple, id)
            break
        case '.doujinquotes':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const doujinquotes = await get.get('https://meme-api.herokuapp.com/gimme/DoujinQuotes').json()
            await client.sendFileFromUrl(from, doujinquotes.url, 'doujinquotes.jpg', doujinquotes.title, id)
            break
        case '.quotesmaker':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            arg = body.trim().split('/')
            if (arg.length >= 4) {
                client.reply(from, mess.wait, id)
                const quotes = arg[1]
                const author = arg[2]
                const theme = arg[3]
                await quotemaker(quotes, author, theme).then(amsu => {
                    client.sendFile(from, amsu, 'quotesmaker.jpg','👊😎').catch(() => {
                        client.reply(from, mess.theme, id)
                    })
                })
            } else {
                await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.quotesmaker* _/teks/watermark/tema_\nContoh : *.quotesmaker* _/Free Fire rutinitasku, kamu prioritasku/Editor Berkelas/Gaming_', id)
            }
            break
        case '.ff': //93
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const ff = [
            'Booyah harus diperjuangkan dan setiap perjuangan pantas mendapatkan booyah.',
            'Bukan yang pertama datang, yang terpenting adalah siapa yang bisa bertahan sampai akhir.',
            'Aku lebih suka pejuang booyah yang berbahaya dari pada cheater!.',
            'Free Fire melatihku menghabisi musuh, juga melindungi teman.',
            'Untuk menjadi nomor satu, kamu harus terus berusaha dan hadapi setiap ujian.',
            'Pacaran sama pemain Free Fire itu gampang. Lagi enggak ngedate, push rank pun jadi.',
            'Kamu itu mirip kayak airdrop yang ingin kuraih, tapi banyak juga yang menginginkanmu.',
            'Bukan ku tak ingin membalas chatmu, tapi mengertilah bahwa Free Fireku enggak ada opsi pause.',
            'Izinkan aku mencintaimu tanpa harus menghapus Free Fireku.',
            'Sendiri bukan berarti sepi, karena berdua pun belum tentu booyah.',
            'Ditinggal pas lagi sayang banget itu sakit, tapi ditinggal pas lagi knocked out itu lebih sakit lagi.',
            'Mendapatkan kamu itu layaknya mengejar rank grand master, sama sulitnya.',
            'Kamu harus tahu, Free Fire cuma sekadar pengisi waktu kosongku. Tapi kamulah pengisi hati kosongku.',
            'Karena Free Fire, aku jadi lupa memberi kabar ke pasangan. Parahnya, sampai lupa kalau aku sebenarnya enggak punya pasangan.',
            'Jangankan musuh, teman satu tim pun bakal rakus ketika ada loot.',
            'Savage dan victory-mu enggak seindah booyah-ku.',
            'Booyah tanpa pengorbanan itu mustahil, seperti awm tanpa scope.',
            'Free Fire rutinitasku, kamu prioritasku.',
            'Cintai pubg-mu tanpa harus menghina Free Fire-ku.',
            'Sakitnya diputusin pacar, enggak sesakit kena landmine Free Fire.',
            'Mabar boleh, ibadah jangan sampai terlewat.',
            'Jarak bisa memisahkan, tapi party selalu bisa menyatukan kita.',
            'Hidup itu kayak zona aman, harus terus bergerak atau tereliminasi.',
            'Free Fire bisa memberitahuku mana teman yang mau berbagi dan yang mau menang sendiri.',
            'Free Fire boleh jadi bukan game hd, tapi kebahagiaan enggak selalu datang dari kemewahan.',
            'Kami mau berperang bukan bertamu.',
            'Pintu? Apa itu?.',
            'Pubg game haram!.',
            'Em el game cacat!.',
            'Genshin impact game burik!.',
            'Free Fire game legend!.',
            'Free Fire lebih baik daripada sholat!.',
            'Pubg banyak bot ea.',
            'Pubg game bocil!.',
            'Bang aku bocil pubg :v.',
            'Free Fire banyak player cewenya.',
            'Bocil Free Fire tuh elit gk kayak pubg tolol semua.',
            'Tiada game sebaik & se hd Free Fire.',
            'Saya bocil bang ayo send id nya kita mabar bang.',
            'Pubg banyak bocil noob.',
            'Halo ada bocil Free Fire disini xixixixixi.',
            'Bocil freefire mah sadar diri bro, dia gk bnyk ngomong, gk kaya bocil pubg, toxicnya minta ampun.',
            'Kata siapa Free Fire gk pernah masuk tv itu bukti nya. Player pubg malu tuh.',
            'Baneed bagi yang bandel dan tidak taat aturan.',
            'Ggwp.',
            '1 kata untuk Free Fire : hd!.',
            'Player Free Fire ramah tamah no toxic.',
            'Hahah jamur di epep halal bor.',
            'Pubg game plagiat!.',
            'Untung pake helm.',
            'Pabji sok sok an game nomer 1 di indonesia padahal game tai, kaku, jelek mendingan Free Fire keren gk kaku zona gk secepat kilat, halal dan ff game sultan punya skin senjata legenf dan no 1 di dunia. Ingat ketika kelak cita cita ku jadi presiden akan ku suruh orang² menguninstal pubji dan bermain ff.',
            'Gini amat jadi pelayer pubg banyak bocil goblok nya.',
            'Ep ep adalah game nomor 1.',
            'Dasar pubg game buriq.',
            'Menghina musuh malah kena sendiri bukan main main.',
            'Brazil du yu redy tu lus.',
            'Brazil du yu redy tu win.',
            'Buat malu indo aja kau pubg.',
            'Booyah: boocah payah.',
            'Makan jamur ea.',
            'Pubg = permainan untuk babi goblogg.',
            'Pubg game kafir!.',
            'Buriq tapi gak haram ea.',
            'Hina aja teros.',
            'Iri bilang bos.',
            'Off ada bocah yang main pubg.',
            'Ikan patin ikan tongkol, jangan sok paten kentol.',
            'Ikan teri di kasih saos, iri bilang boss.',
            'Wak uwak makan peyek, lah bising kau pepek.',
            'Welcome to game mobile legend, game burik yang penting nomor 1 di indonesia.',
            'Epep nomor 1.',
            'Epep numba wan.',
            'Game banyak event gratisan jangan sok keras tau kan game apa.',
            'Lebih baik diskonan dari pada pubg baju masih bot ambil bajing yang mahal.',
            'Pabji game buriq murahan pula 3k dah dapat 299 diamond.',
            'Coba bayangin pubg collab sama bts, bayangin aja dulu.',
            'Yang ngatain ff malu" in negara, fix= otaknya tolol banget,  nihhh bukti bahwa ff pernah menjadi juara dunia. By. Evos capital.',
            'Alokalokalokalok, karakter kok ketawa.',
            'Kau boleh hina ibuku, tapi tidak dengan Free Fire.',
            'Kau boleh hina waifuku, tapi tidak dengan Free Fire.',
            'Kau boleh hina agamaku, tapi tidak dengan Free Fire.',
            'Bang giv alok bang.',
            'Boooyahhhh!.',
            'Anjay mabar.',
            'Maap, bro hp gw kentang.',
            'Ayam gw tiap malem ilang dari kandang ini semua gara gara game haram pubg.',
            'Buat apa ada pintu kalo bisa lewat jendela.',
            'Kisah sedih Free Fire.',
            'Yaahhaaa hayyuuukkk.',
            'Anjing yg hina Free Fire.',
            'Maen pubg = murtad.',
            'Maen freee fire = pahala naik haji.',
            'Rela makan indomie agar bisa topup Free Fire.',
            ]                
            let ff2 = ff[Math.floor(Math.random() * ff.length)]
            await client.reply(from, ff2, id)
            break
        case '.fakta': //100
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const fakta = [
            'Lemon mengandung banyak gula daripada stroberi.',
            'Huruf yang paling sering dipakai yakni karakter E, sedangkan karakter yang paling jarang dipakai yakni karakter Q.',
            'Kupu-kupu tidak sanggup terbang kalau suhu tubuh mereka kurang dari 86 derajat celcius.',
            'Satu kilogram lalat mengandung lebih banyak protein daripada satu kilogram daging sapi.',
            '"I" yakni kata yang paling sering diucapkan dalam bahasa Inggris.',
            'Kucing mempunyai mata paling besar daripada mamalia lainnya.',
            'Bunglon sanggup menggerakkan kedua matanya dalam dua arah pada waktu yang sama.',
            'Kangguru tidak sanggup berjalan mundur.',
            'Penyakit pernafasan yakni penyebab maut utama di China.',
            'Nepal yakni satu-satunya negara yang mempunyai bendera bukan berbentuk persegi panjang.',
            'Lithuania mempunyai tingkat bunuh diri tertinggi di dunia.',
            'Istana Buckingham mempunyai 602 kamar.',
            'Seekor tikus sanggup bertahan usang tanpa air daripada unta.',
            'Seorang laki-laki berjulukan Charles Osborne mengalami cegukan selama 69 tahun.',
            'Lebih banyak orang terbunuh setiap tahunnya oleh lebah daripada ular.',
            'Dari semua kata dalam bahasa Inggris, kata "Set" mempunyai arti (definisi paling banyak.',
            'Manusia menggunakan total 72 otot yang berbeda dalam berbicara.',
            'Nama depan yang paling terkenal di dunia yakni Muhammad.',
            'Swiss yakni satu-satunya negara yang mempunyai bendera berbentuk persegi.',
            'Jantung udang berada di kepalanya.',
            'Tanda tangan Julius Caesar bernilai sekitar $2.000.000.',
            'Katak tidak sanggup menelan dengan mata terbuka.',
            'Jenis berlian paling langka ialah yang berwarna hijau.',
            'Satu-satunya benua yang tidak mempunyai gunung berapi aktif yakni Australia.',
            'Peru mempunyai lebih banyak Piramida daripada Mesir.',
            'Finlandia mempunyai jumlah pulau terbesar di dunia (lebih dari 179.550).',
            'Coca Cola awalnya mengandung kokain.',
            'Leonardo Da Vinci membutuhkan waktu 10 tahun untuk melukis Mona Lisa.',
            'Anggur sanggup meledak kalau anda memasukannya di dalam microwave.',
            'Kulit yakni organ terbesar yang membentuk tubuh manusia.',
            'Telur mengandung semua vitamin kecuali vitamin C.',
            'Alpukat mempunyai kalori lebih banyak daripada buah lainnya.',
            'Phobophobia yakni phobia terhadap suatu phobia atau ketakutan dengan rasa takut.',
            'Tulang paha insan lebih berpengaruh daripada beton.',
            'Taj Mahal seluruhnya terbuat dari marmer.',
            'Jenggot pirang tumbuh lebih cepat daripada jenggot yang gelap.',
            'Lidah bunglon mempunyai panjang dua kali lipat dari panjang tubuhnya.',
            'Kaki yakni kepingan tubuh yang paling umum digigit serangga.',
            'Darah 6 kali lebih tebal daripada air.',
            '85% kehidupan tanaman di dunia ditemukan di laut.',
            'Kilat menyambar Bumi 6000 kali setiap menitnya.',
            'Kucing rumahan tidak menyukai aroma jeruk.',
            'Nasi yakni makanan pokok bagi 50% populasi di dunia.',
            'Mutiara sanggup meleleh dalam cuka.',
            'Seekor iguana sanggup berada di bawah air selama 28 menit.',
            'Air di Samudra Atlantik lebih asin daripada air di Samudra Pasifik.',
            'Hujan mengandung vitamin B12.',
            'Bulan purnama 9 kali lebih terperinci daripada setengah bulan.',
            'Ada lebih banyak serangga di dunia daripada adonan semua binatang lainnya.',
            'Salju yang kotor meleleh lebih cepat daripada salju yang bersih.',
            'Jerapah tidak mempunyai pita suara.',
            'Hiu sanggup mencicipi setetes darah dari jarak 4 km.',
            '80% pencurian di dunia dilakukan oleh orang-orang berusia 13-21 tahun.',
            'Kanada mempunyai lebih banyak danau daripada negara lainnya.',
            '90% dari semua acara vulkanik terjadi di lautan.',
            'Ikan Todak mempunyai tulang berwarna hijau.',
            'Seekor burung pelatuk sanggup mematuk 20 kali per-detik.',
            'Eropa yakni satu-satunya benua tanpa gurun pasir.',
            'Hawaii yakni satu-satunya negara kepingan AS yang menanam kopi.',
            'Satu-satunya karakter yang tidak muncul dalam tabel periodik yakni karakter J.',
            'Sepak bola yakni olahraga yang paling banyak diikuti.',
            'Di Irlandia Utara, perempuan berpenghasilan lebih banyak 3,4% daripada pria.',
            'Burj Khalifa mempunyai 24.000 jendela.',
            '97% pengendara motor di Paraguay tidak menggunakan helm.',
            'Amazon mempekerjakan lebih dari setengah juta pekerja pada tahun 2017.',
            'Nomor telepon termahal di dunia dilelang di Qatar yaitu 666 6666, terjual seharga 1,5 juta Euro.',
            'Aristoteles mengira tanaman mempunyai jiwa.',
            'Papua Nugini mempunyai 832 bahasa.',
            'Ada lebih dari 40 bandara di Antartika.',
            'Di Prancis, yakni legal (diperbolehkan untuk menikahi orang mati.',
            'Babi tidak sanggup berkeringat.',
            'Air kelapa sanggup dipakai sebagai plasma darah.',
            'Gorilla bersendawa ketika ia bahagia.',
            'Cherophobia yakni ketakutan akan kesenangan.',
            'Hamster berlari hingga 8 mil pada malam hari dengan menggunakan roda.',
            'Anjing pelacak yakni satu-satunya binatang yang buktinya sanggup diterima di pengadilan.',
            'Seperempat tulang di tubuh terletak di kaki.',
            'Sapi membunuh lebih banyak orang daripada hiu.',
            'Bola baja akan memantul lebih tinggi daripada bola karet.',
            'Di Jupiter dan Saturnus terjadi hujan berlian.',
            'Rusia mempunyai luas permukaan yang lebih besar daripada Pluto.',
            'Ketika seekor penguin jantan jatuh cinta pada penguin perempuan, ia akan mengitari seluruh pantai untuk menemukan kerikil yang tepat untuk diberikan kepadanya.',
            'Sambaran petir 6 kali lebih panas daripada matahari.',
            'Hanya 2% populasi insan di dunia yang mempunyai mata berwarna hijau.',
            'Hidung sanggup mengingat 50.000 aroma yang berbeda.',
            'Setelah berolahraga, diharapkan 5 jam semoga suhu tubuh kembali normal.',
            'Bekicot bernafas melalui kakinya.',
            'Stroberi mengandung lebih banyak vitamin C daripada jeruk.',
            'Lemon lebih asam daripada cuka.',
            'Seekor ikan koi berjulukan Hanoko hidup selama 225 tahun.',
            'Mona Lisa tidak mempunyai alis.',
            'Saat anda meninggal, rambut anda masih akan bertumbuh selama beberapa bulan.',
            'Raja hati di kartu remi yakni satu-satunya raja tanpa kumis.',
            'Mary Stuart menjadi ratu Skotlandia ketika usianya gres 6 hari.',
            'Anak-anak tumbuh lebih cepat di animo semi.',
            'Kapasitas penyimpanan otak insan melebihi 4 terrabyte.',
            'Austria yakni negara pertama yang menggunakan kartu pos.',
            'Orang Jepang biasanya menaruh kecap pada nasi mereka.',
            'Produk pertama yang dikeluarkan Sony yakni rice cooker.',
            '10% dari pendapatan pemerintah di Rusia berasal dari penjualan vodka.',
            ]                
            let fakta2 = fakta[Math.floor(Math.random() * fakta.length)]
            await client.reply(from, fakta2, id)
            break
        case '.hoax': //100
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const hoax = [    
            'Aji ramadhan itu mitos.',
            'Wancakerwati itu mitos.',
            '1cak universe is gay.',
            'Yg baca ini geh.',
            'Corona cuma akal-akalan elite global.',
            'Vaksin menyebabkan kebodohan.',
            'Masker menyebabkan susah bernafas.',
            'Free Fire game hd.',
            'Utang indonesia lunas.',
            'Kata "jokowi" jika diterjemahkan ke dalam bahasa china artinya thu khang thi phu.',
            'Jokowi mundur secara terhormat hari ini.',
            'Jokowi barter vaksin corona dengan lahan untuk perusahaan china.',
            'Cina sahabat indonesia.',
            'Indonesia bersih dari koruptor.',
            'Jokowi tepati janji.',
            'Ma`ruf amin login.',
            'Ma`ruf amin = kakek sugiono.',
            'Megawati nenekku.',
            'Puan maharani ibuku.',
            'Dpr sangat merakyat.',
            'Pki tidak salah.',
            'Jokowi itu pki.',
            'Jojo anime gay.',
            'Nafas manual on.',
            'Kedip manual on.',
            'Tuan crab ditangkap polisi dan diperiksa kpk.',
            'Lama tak terdengar kabar malika, ternyata open bo.',
            'Megawati open bo.',
            'Puan maharani open bo.',
            'Jokowi bandar togel.',
            'Jokowi hobi ngutang.',
            'Bbm gratis, di playstore tapi.',
            'Bisnis qnet sangat menguntungkan.',
            'Join vtuber indonesia = calon milyarder.',
            'Jungkook raja meme.',
            'Israel janji bikin indonesia seperti palestina jika terus ikut campur.',
            'Israel bebaskan palestina.',
            'Papua merdeka.',
            'Timor leste join indonesia lagi.',
            'Jokowi murtad.',
            'Aji ramadhan ada di group ini, cuma nyamar aja.',
            'Admin 1cak ada di group ini, cuma nyamar aja.',
            'Wancakerwati banyak di group ini, cuma sider aja.',
            'Bapak-bapak banyak di group ini, cuma sider aja.',
            'Reply pesan ini maka battery hpmu akan penuh 100%.',
            'Reply pesan ini maka kuotamu bertambah 100gb.',
            'Reply pesan ini maka ram hpmu bertambah menjadi 8gb.',
            'Lgbt tidak salah.',
            'Bank indonesia transfer uang ke rekening pribadi.',
            'Kfc bagi-bagi 3.000 snack bucket gratis.',
            'Mata uang rupiah akan digantikan mata uang yuan.',
            'Mata uang yuan akan sah beredar di indonesia.',
            'Orang minang pelit.',
            'Aceh merdeka.',
            'Kpop > budaya lokal.',
            'Rumah puan maharani ketua umun dpr ri dibakar para demo.',
            'Boruto > naruto.',
            'Sagiri lonte.',
            'Indonesia masuk piala dunia.',
            'Messi ditransfer ke persebaya.',
            'Ronaldo ditransfer ke arema.',
            'Jokowi 3 periode.',
            'Jokowi presiden seumur hidup.',
            'Cebong kampret bersatu.',
            'Jawa > sunda.',
            'Sunda > jawa.',
            'Madura > dayak.',
            'Dayak > madura.',
            'Hentai > jav.',
            'Jav > hentai.',
            'Brazzer > jav.',
            'Pornhub tutup.',
            'Kominfo kerja sama dengan pornhub.',
            'Ganja dilegalkan.',
            'Dj indo remix gagak tiktiok viral > musik lainnya.',
            'Batik punya malaysia.',
            'Surga ditelapak kaki bts.',
            'Hina bts = kena azab.',
            'Sagiri bukan lonte.',
            'Pedofil bukan gangguan.',
            'Loli > milf.',
            'Cina > pribumi.',
            'Jokowi jual sumatera ke cina.',
            'Jokowi jual kalimantan ke cina.',
            'Mobil esemka dijual murah cuma 50jt.',
            'Semua salah jokowi.',
            'Masalah indonesia bukan urusan jokowi.',
            'Jokowi meninggal.',
            'Dj kowee sedang meremix suara rakyat.',
            'Nazi itu komunis.',
            'Your mom gay.',
            'Jokowi presiden terbaik.',
            'Pdip akan jadi partai tunggal, partai lain akan dibubarkan.',
            'Coli menyebabkan kebotakan.',
            'Coli menyebabkan kemandulan.',
            'Kpop > wibu.',
            'Jokowi = umar bin khatab.',
            'Anime haram.',
            'Free Fire > pubg.',
            'Xi jinping puji jokowi, sebut ri ramah & penting buat china.',
            'Indonesia jadi provinsi cina.',
            'Kim jong un meninggal.',
            ]                
            let hoax2 = hoax[Math.floor(Math.random() * hoax.length)]
            await client.reply(from, hoax2, id)
            break
        case '.joke': //100
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const joke = [
            'Buah apa yang durhaka? Melon kundang.',
            'Buah apa yang ditakuti mahasiswa? Belimbingan skripsi.',
            'Buah apa yang suka bangun pagi? Apel pagi.',
            'Buah apa yang bisa menampung banyak barang? Leci meja.',
            'Buah apa yang pernah menjajah indonesia? Terong belanda.',
            'Buah apa yang punya duit banyak? Srikaya.',
            'Buah apa yang lucu suka bikin ketawa? Buahahahaha.',
            'Buah apa yang dimakan berbahaya? Buah apa aja yang makannya di jalan tol.',
            'Buah apa yang bikin ketagihan dan selalu fresh? Buah bibir.',
            'Buah apa yang paling mantap? Buah dada.',
            'Binatang apa yang punya banyak keahlian? Kukang. Ada kukang tambal ban, kukang bangunan, kukang service tv..',
            'Binatang apa yang nyariin bapaknya mulu? Beee...beee...beee. Kambing nyariin babenya mulu.',
            'Binatang apa yang bisa nyanyi dangdut? Cheetah citata.',
            'Binatang apa yang pendiam? Semute.',
            'Siput apa yang kemana-mana bawa kera? Siputa dari goa hantu.',
            'Kodok apa yang bisa membunuh? Kodokakan kau cepat mati.',
            'Ikan yang bisa terbang? Lelelawar.',
            'Ikan apa yang suka berhenti? Ikan pause.',
            'Binatang apa yang paling sederhana? Ala kadal nya.',
            'Ayam apa yang paling besar? Ayam semesta..',
            'Penyanyi luar negeri yang suka bersepeda? Selena gowes.',
            'Penyanyi luar negeri yang susah nelen? Ed sered.',
            'Pemain sepakbola yang beratnya 3 kg? Bambang tabung gas.',
            'Gubernur apa yang suka bernyanyi? Biduan kamil.',
            'Wakil presiden yang suka streaming video? Muhammad youtuber kalla.',
            'Penyanyi yang suka nggak sadar? Pingsan mamboo.',
            'Penyanyi yang rambutnya nggak lurus? Ayu keriting.',
            'Penyanyi yang selalu tabah? Pasrah ungu.',
            'Artis yang ditunggu-tunggu saat ramadhan? Afgan maghrib.',
            'Penyanyi apa yang nggak pintar? Celine dih oon.',
            'Sayur apa yang munculnya selalu di akhir film? Toamat.',
            'Sayur apa yang pintar nyanyi? Kolplay.',
            'Sayur apa yang paling suci? Kailan suci aku penuh dosa.',
            'Sayuran apa yang susah dilupain? Bayam bayam wajah dirimu.',
            'Sayur apa yang dingin? Kembang cold.',
            'Sayur apa yang sukanya nunjuk orang lain? Sayur lo deh.',
            'Sayur yang suka dipanggil abang? Bro koli.',
            'Sayur apa yang bikin senang? Toge ther with you forever.',
            'Lalapan apa yang bisa menimbulkan korban jiwa? Lalapan liar.',
            'Sayur apa yang ada pangkatnya? Sayur mayor..',
            'Kenapa cicak mutusin ekornya tiba-tiba? Kan bisa dibicarakan baik-baik.',
            'Tau perbedaan yourwelcome sama terima kasih kembali? Sama-sama sama sama-sama.',
            'Kalau nikah ga ada wali boleh ganti noah ga?.',
            'Kenapa wanita mudah dirayu buaya? Karena mereka percaya lidah buaya banyak khasiatnya.',
            'Php bukanlah pemberi harapan palsu tetapi orang madura jualan hp.',
            'Kemarin saya beli permen karet, pas dikunyah pedas, eh permen karet dua.',
            'Kenapa air mata warnanya bening? Kalau hijau namanya air matcha.',
            'Kalau ada yg jahatin kita biarkan saja, biar iwan yg fales.',
            'Kereta apa yg imut kalau jalan? Kereta api, cute! Cute! Cute!.',
            'Pasien yg kena gejala rindu dilarikan kemana? Ke ruangan i see you.',
            'Tadi ada pengamen nyanyi lagu denting piano, padahal main gitar.',
            'Ibukota banten di serang.',
            'Barusan saya ke apotek beli obat tidur, pas pulang saya bawa pelan-pelan, takutnya bangun.',
            'Burung apa yang suka nolak? Burung gakgak.',
            'Barusan saya kekamar, saya kaget kok kasur saya ga ada, saya cari ternyata ketutupan seprei.',
            'Kenapa dunia terasa gelap?, oh ternyata kacamata hitamku belum dibuka.',
            'Sehat selalu ya buat member group ini, tetap sosial dispenser.',
            'Kesenian apa yg dilakukan nasabah bank? Tari tunai.',
            'Lele apa yg bisa terbang? Lelelawar.',
            'Kenapa kucing maling ikan ga di penjara? Karena kucing ga wrong.',
            'Kota apa yg banyak bapak-bapaknya? Purwodaddy.',
            'Gendang-gendang apa yg gabisa dipukul? Gendang telinga.',
            'Warna-warna apa yg tidak peduli sama kita? Biru don`t care.',
            'Hewan apa yg diinjak ga marah? Keramik.',
            'Kienapa kita berdoa sebleum minum air? Karena ada jin di air, 2 hidrojin dan 1 oksijin.',
            'Jika istrimu ga bekerja dan suka jepang, pasti wibu rumah tangga.',
            'Alhamdulillah setelah beli motor bebek, banyak telurnya.',
            'Belut apa yg berbahaya? Belutang.',
            'Kalau nikah sirih, sirihnya direbus apa ditumbuk?.',
            'Hewan apa yg bisa minta maaf? Ayam sorry.',
            'Gajah apa yg belalainya pendek? Gajah pesek.',
            'Nama anak yg ada unsur makanan padang, dendeng alexander balado.',
            'Usaha yg ga bikin gulung tikar, usha gulung kabel.',
            'Kenapa tempe lama bikinya? Karena berbahan kedelay.',
            'Huruf yg sering kedinginan? B, karena diantara ac.',
            'Jika cinta masih mandang fisik, sama ikan aja sana karean ikan banyak fisiknya.',
            'Info lokernya dong, jenazah sd.',
            'Tadi saya nemu hp di jalan, bagi yg merasa kehilangan mohon temui saya, soalnya butuh chargernya.',
            'Selain kurma buah apa yg berasal dari arab? Al pukat.',
            'Gara-gara covid19 seorang kakek tega menjual kue putunya sendiri.',
            'Gajah-gajah apa yg baik? Gajahat.',
            'Kenapa hujan yurunnya air? Kalau turun dajjal nanti kiamat.',
            'Utang indonesia pasti lunas, tahu dariaman? Sumedang.',
            'Ikan-ikan apa yg bisa bersih-bersih? Ikan sapu-sapu.',
            'Kalau kita mau mengutarakan sesuatu, apa boleh menghadap selatan?.',
            'Anak saya ngeyel, kuliah ngambil komputer, pulang bonyok.',
            'Ikan-ikan apa yg matanya banayk? Ikan teri sebaskom.',
            'Hewan apa yg gajelas? Paanda.',
            'Kenapa ikan ga tidur? Karena kasurnya basah.',
            'Burung kakatua umurnya berapa ya?.',
            'Apa bedanya kucing dengan kucring, kucing kakinya empat, kucring kakinya emprat.',
            'Hewan apa ygselalu telat, kaki seribu, lama paki sepatu.',
            'Kenapa sepeda harus di goes, karena kalau digoyang itu istri.',
            'Pengen makan siang, eh udah malam.',
            'Omnibuslaw omnya siapa sih? Bikin ribut aja.',
            'Kenapa gasuka dpr sih? Kalau ga dpr, dirumah masak & makan dimana?.',
            'Kalau istri cosplay anak sma, dia malah ga nafsu sama saya, soalnya saya pakai rok juga.',
            'Tolong yg suka nyinyir ngapain demo, ga guna. Asal kalian tau saya sudah dapat banyak dompet & hp.',
            'Jangan tidur telentang, ketelen tulang ikan aja sakit.',
            'Kenapa nikah harus pakai wali, padahal saya sukanya noah.', 
            ]                
            let joke2 = joke[Math.floor(Math.random() * joke.length)]
            await client.reply(from, joke2, id)
            break
        case '.darkjoke': //37
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const darkjoke = [
            'Seorang eksekutor menanyakan apa pesan terakhir pembantai sebelum kursi listrik dinyalakan. "ya", jawab pembantai, "gandeng tanganku.".',
            '"Saya punya kabar baik dan buruk tentang kondisimu saat ini. Yang mana yang ingin kau dengar pertama kali?" kata dokter ke pasiennya. "kabar baik dok." pinta pasien. "kami telah mendiagnosa penyakitmu di lab, dan kamu masih punya kesempatan dua hari lagi untuk hidup." "kabar buruknya?" "kami berusaha berangkat dari lab ke tempatmu selama dua hari.".',
            'Istri, "sayang, anak kita pergi terlalu jauh!" suami, "ketapelnya mengagumkan.".',
            'Mengapa tunawisma tidak diperbolehkan bermain baseball? Karena mereka tidak tahu apa itu homerun.',
            '"Pekerjaan saya adalah berkumpul dengan hewan-hewan." "sayang, how cute! Di toko hewan mana kamu bekerja?" "bukan, saya tukang jagal.".',
            'Sebuah batu nisan terukir: "aku bilang aku hanya sakit!".',
            '"Siri, mengapa aku jomblo?" siri membuka kamera depan.',
            '"Anak ibu baru saja menyebut wajahku jelek!" "maaf beribu maaf, padahal aku sudah ajarkan padanya bahwa jangan menilai buku dari sampulnya.".',
            'Apa persamaan remaja hamil diluar nikah dengan anak yang dikandungnya? Mereka sama-sama berpikir, "ibuku mungkin akan membunuhku.".',
            '"Kemana anda akan membawaku dok?" "ke kamar mayat." "apa?! Aku belum mati!" "kita juga belum sampai.".',
            'Pada pesta pernikahan saudaraku, bibiku bercanda kepadaku, "ferisa, apa kau berikutnya?" aku langsung pulang, aku ingat aku pernah berkata sama kepadanya di acara pemakaman.',
            'Setelah bekerja, aku menjadi relawan untuk menolong anak-anak buta. Buta di sini adalah kata kerja, bukan kata sifat.',
            'Seorang pria terbangun dari komanya. Pertama kali yang dia lihat adalah istrinya yang memakai gaun serba hitam.',
            'Pernikahanku seperti cerita-cerita dongeng, aku memberinya banyak roti dan meninggalkannya di hutan.',
            '"Mengapa ayahmu meninggal?" "jarinya terkena palu." "tetapi itu tidak dapat menjadikannya meninggal bukan?" "dia tidak berhenti berteriak jadi aku menembaknya.".',
            'Bagaimana kamu menyebut anjing yang tidak memiliki kaki? Tidak perlu disebut, dia juga tidak akan (bisa) pulang.',
            '"Ayah, maafkan aku! Aku tidak sengaja mendorong nenek hingga meninggal!" "apa kau bercanda?! Masih ada kakek di kulkas!".',
            'Binatang apa yang berkaki lima? Serigala yang kembali dari perkemahan di hutan.',
            'Seorang dokter memvonis bahwa hidupku tinggal dua tahun lagi. Aku membunuhnya, kemudian pengadilan memberiku lima belas tahun. Sekian.',
            'Seseorang bertanya kepadaku bagaimana sampai ke rumah sakit dengan cepat. Aku mendorongnya ke tengah jalan.',
            'Mengapa tifani jatuh dari ayunan? Karena dia tidak memiliki tangan.',
            '"Dia laki-laki! Aku tidak percaya ini! Dia benar-benar laki-laki." dia begitu berkaca-kaca. Diki, 27 tahun, tiba-tiba mengakhiri liburannya di thailand.',
            'Apa yang didapat seorang tanpa lengan di hari ulang tahunnya? Tidak tahu, dia belum buka kadonya.',
            'Ingin memberikan kehangatan kepada seseorang seumur hidupnya? Bakar dia.',
            'Hitam, putih, merah, apa itu? Biarawati jatuh dari tangga. Hitam, putih, dan tertawa apa itu? Biarawati yang mendorongnya.',
            'Aku mengunjungi indekos temanku, dia bilang bahwa anggap saja rumahku sendiri. Jadi aku lempar dia dari jendela, aku tidak suka rumahku kedatangan tamu.',
            'Jika kau tersenyum, kau mungkin sedang berpikir untuk melakukan sesuatu yang jahat. Jika aku tertawa, aku telah selesai melakukannya.',
            'Orang kuat tidak menaruh orang lain di bawahnya. Mereka mengangkat mereka tinggi-tinggi terlebih dahulu.',
            'Ibu, mengapa aku tiba-tiba mengalami sakit kepala yang hebat? Nak, menjauh dari target panahan!.',
            'Cara menyelamatkan orang dari tenggelam? Singkirkan kakimu dari kepalanya.',
            'Ibu, mengapa keluarga kita meninggal satu persatu secara tiba-tiba? Ibu? Ibu… ibuuuu…….',
            '"Anakku, mengapa kau tidak pernah menegur roni lagi?" "apa ibu mau menegur orang bodoh, kerjanya mabuk-mabukkan, dan memakai narkotika?" "tentu saja tidak, nak." "sama, dia juga.".',
            'Humor gelap itu seperti sepasang ginjal yang sehat, tidak semua orang mendapatkannya.',
            'Seseorang terjatuh dari tebing, bersamaan dengan itu istrinya menelpon, "sayang, apa kau baik-baik saja." "tentu saja." "ada yang terluka?" "aku belum selesai jatuhhnyyyaaaaaaaaa…. Aaaaa…..".',
            'Dua kanibal sedang menyantap buruan mereka masing-masing. Kanibal 1, "daging karyawati dari gedung seberang cukup lezat." kanibal 2, "begitu juga istrimu.".',
            '"Tapi ayah, aku tidak ingin pergi ke sulawesi." "diam! Teruslah berenang!".',
            '"Dengan kondisi yang seperti ini kau dapat hidup hingga 70 tahun." "dok, saya sudah 70 tahun.".',          
            ]                
            let darkjoke2 = darkjoke[Math.floor(Math.random() * darkjoke.length)]
            await client.reply(from, darkjoke2, id)
            break
        case '.toxic': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const toxic = [
            'BABI',
            'MONYET',
            'ANJING',
            'RIZKY',
            'JEMBUT',
            'MEMEK',
            'KONTOL',
            'TEMPIK',
            'KIMAK',
            'GAY',
            'LESBI',
            'YOGA',
            'SETAN',
            'CANGCUT',
            'BAGONG',
            'BANGSAT',
            'NGENTOT',
            'GEH',
            'BUAYA',
            'ASU',
            'JOKOWI',
            'KUDA',
            'JASJUS',
            'BOCIL',
            'BOCAH',
            'PELER',
            'NOOB',
            'AUTIS',
            'IDIOT',
            'GILA',
            'HARAM',
            'LAKNAT',
            'LONTE',
            'GIGOLO',
            'MURTAD',
            'KAFIR',
            'JAWA',
            'SUNDA',
            'SUNDAL',
            'CINA',
            'VIRUS',
            'MINANG',
            'BATAK',
            'GANJA',
            'MABOK',
            'AMER',
            'TUAK',
            'BONEK',
            'DEJEK',
            'VIKING',
            'GORENGAN',
            'BASI',
            'EEK',
            'TAIK',
            'AMPAS',
            'PELACUR',
            'PENGGANGURAN',
            'WIBU',
            'NOLEP',
            'WIBU',
            'MEGAWATI',
            'TIKUS',
            'CURUT',
            'SAMPAH',
            'KUBURAN',
            'MATI',
            'SELOKAN',
            'BAU',
            'BUSUK',
            'KAMBING',
            'CEBONG',
            'CEBI',
            'KAMPRET',
            'ONTA',
            'KADRUN',
            'SJW',
            'TWITTARD',
            'NORMIES',
            'ANUS',
            'DUBUR',
            'ASEM',
            'AMIS',
            'PEJU',
            'MANI',
            'SPERMA',
            'MUNTAH',
            'NAJIS',
            'OPEN MINDED',
            'BUDAK',
            'SARA',
            'RASIS',
            'CHING CHONG',
            'BOB & VAGENE',
            'INDIA',
            'XI JINPING',
            'HAIIYYAAA',
            'UTANG',
            'SESAT',
            'GILA',
            'PANTEK',
            'YAHUDI',
            'ISRAEL',
            'YUDAS',
            'IMPOSTOR',
            'PKI',
            'KOMUNIS',
            'KAPITALIS',
            'FUCK',
            'SHIT',
            'NIGGER',
            'NIBBA',
            'NIGGA',
            'AHOK',
            'RADIKAL',
            'EMCEIH',
            'DPR',
            'MEGAWATI',
            'MILOS',
            'JAMET',
            'KUPROY',
            'THOT',
            'HOE',
            'TIKTOK',
            ]
            let toxic2 = toxic[Math.floor(Math.random() * toxic.length)]
            const toxic3 = [
            `MUKA LO KEK ${toxic2}`, 
            `BADAN LO KEK ${toxic2}`, 
            `MULUT LO KEK ${toxic2}`, 
            `LO KEK ${toxic2}`, 
            `LO TAU ${toxic2} ?`,
            `${toxic2} LO ${toxic2}`,
            `NGAPA ${toxic2} GA SENENG?`,
            `RIBUT SINI LO ${toxic2}`,
            `JANGAN NGAKAK LO ${toxic2}`,
            `WOY ${toxic2}!`,
            `GW SIH OWH AJA YA ${toxic2}`,
            `GA SENENG? SEND LOKASI LO ${toxic2}`,
            `CAPEK GW ${toxic2}`, 
            `MALES GW ${toxic2}`, 
            `BOSEN GW ${toxic2}`, 
            `HARI INI KAU MAU GELUT ${toxic2}?`, 
            `GW TAU LO ITU ${toxic2}`,
            `GW GANTENG DAN LO KEK ${toxic2}`,
            `BUCIN LO ${toxic2}`,
            `NAJIS BAPERAN KEK ${toxic2}`,
            `OFF BAPERAN KEK ${toxic2}`,
            `NGETEH ${toxic2}`,
            `NGOPI ${toxic2}`,
            `GAYA LO SOK IYE, MUKALO KEK ${toxic2}`,
            `${toxic2} AWOKWOWKOK`,
            `AWOKWOWKOK ${toxic2}`,
            `BAPAK LO KEK ${toxic2}`, 
            `EMAK LO KEK ${toxic2}`, 
            `BAPAK LO ${toxic2}`, 
            `EMAK LO ${toxic2}`, 
            `BISA AJA LO ${toxic2}`, 
            `CALON ${toxic2}`, 
            `ANAK ${toxic2}`, 
            `DIDIKAN ${toxic2}`, 
            `TITISAN ${toxic2}`, 
            `KETURUNAN ${toxic2}`, 
            `JANGAN DITIRU NI ${toxic2}`, 
            `${toxic2}`, 
            `${toxic2} ${toxic2}`, 
            `${toxic2} ${toxic2} ${toxic2}`, 
            ]                   
            let toxic4 = toxic3[Math.floor(Math.random() * toxic3.length)]
            await client.reply(from, `${toxic4}`, id)
            break
        case '.arti':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.arti* _nama_\nContoh : *.arti* _jihyo_', id)
            const arti = await get.get('https://scrap.terhambar.com/nama?n='+body.slice(6)).json()
            await client.reply(from, `Artinya : ${arti.result.arti}`, id)
            break
        case '.sifat': //61
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.sifat* _nama_\nContoh : *.sifat* _jihyo_', id)
            const sifat = [
            'Supel atau mudah bergaul',
            'Sombong',
            'Labil',
            'Optimis',
            'Humoris',
            'Kreatif',
            'Minder',
            'Fussy atau suka cari perhatian',
            'Pendendam',
            'Sulit memaafkan',
            'Perfeksionis',
            'Pesimis',
            'Hard to please atau standar yang tinggi',
            'Terlalu sensitif',
            'Sensitif',
            'Penyendiri',
            'Moody',
            'Mandiri',
            'Egois',
            'Ambisius',
            'Helper',
            'Kritis',
            'Bossy',
            'Pembangkang',
            'Rendah hati',
            'Jujur',
            'Dermawan',
            'Pelit',
            'Keras kepala',
            'Setia',
            'Pendusta',
            'Bijaksana',
            'Tempramental',
            'Sopan',
            'Berjiwa besar',
            'Lapang dada',
            'Baperan',
            'Lembek',
            'Cengeng',
            'Adil',
            'Rajin',
            'Tekun',
            'Giat',
            'Bisa diandalkan',
            'Disiplin',
            'Pemaaf',
            'Berani',
            'Percaya diri',
            'Tawakkal',
            'Bersyukur',
            'Kasih sayang',
            'Penyayang',
            'Pesimis',
            'Sabar',
            'Nekat',
            'Gila',
            'Pengutang',
            'Pussy',
            'Integritas',
            'Ulet',
            'Tabah',                
            ]                
            let sifat2 = sifat[Math.floor(Math.random() * sifat.length)]
            await client.reply(from, `Sifatnya : ${sifat2}`, id)
            break
        case '.iman': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const iman = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const iman2 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']              
            let iman3 = iman[Math.floor(Math.random() * iman.length)]
            let iman4 = iman2[Math.floor(Math.random() * iman2.length)]
            await client.reply(from, `Imanmu : ${iman3}${iman4}%`, id)
            break
        case '.mati': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const mati = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const mati2 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']  
            const mati3 = ['Detik', 'Menit', 'Jam', 'Hari', 'Minggu', 'Bulan', 'Tahun']                 
            let mati4 = mati[Math.floor(Math.random() * mati.length)]
            let mati5 = mati2[Math.floor(Math.random() * mati2.length)]
            let mati6 = mati3[Math.floor(Math.random() * mati3.length)]
            await client.reply(from, `Sisa Umurmu : ${mati4}${mati5} ${mati6}`, id)
            break
        case '.ramal': //17
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const ramal = [
            'Kamu akan menemukan beberapa kebenaran yang tidak terduga dari orang-orang di sekitar kamu. Bersikaplah bijaksana dan kamu akan terhindari dari argumen di masa depan.',
            'Ide-ide yang jelas dan tegas akan menjadi tema hari ini dan hal ini akan menyingkirkan keraguan kamu. Selera humor kamu yang baik akan menular.',
            'Kamu berada dalam kondisi yang baik, tapi pastikan kamu tetap makan secara teratur.',
            'Hari ini tidak ada gunanya meminta kamu untuk membuat upaya yang besar. Kamu hanya mempunyai satu keinginan yaitu untuk menikmati kesenangan dunia.',
            'Bersikaplah terbuka dan jelas maka semuanya akan baik- baik saja. Kamu akan merasa bahwa orang lain yang membuat kamu lelah, tapi sebenarnya tindakan-tindakan kamulah yang perlu diperhatikan.',
            'Bicaralah dengan pasangan kamu. Jangan terus terhambat oleh emosi negatif. Apapun situasi kamu, maka ekspresikanlah diri kamu secara penuh untuk kembali pada jalur yang benar.',
            'Hari ini kamu akan dipenuhi dengan perasaan senang dan bahagia. Kamu yang sedang menjalin hubungan akan menikmati situasi yang ada dan kamu yang tidak dalam komitmen jangka panjang akan mampu merubah strategi kamu secara positif.',
            'Kamu akan memetik hasil dari upaya yang kamu kerjakan bulan lalu.',
            'Saat ini, hasil itu akan menjadi sesuatu untuk kamu rayakan. Kamu juga akan melewati fase yang baik secara finansial. Fokuslah terhadap keuangan dan rencana-rencana kamu.',
            'Hari ini kepekaan kamu terlalu berlebihan. Kamu juga punya kecenderungan untuk bersikap terlalu sensitif dan membuat orang lain merasa tidak nyaman.',
            'Berhentilah sejenak, namun jangan mengisolasi diri kamu. Pergilah tanpa perasaan bersalah atau khawatir, seperti kamu harus berolahraga untuk mendapatkan keseimbangan yang lebih baik.',
            'Hal-hal yang berkaitan dengan kehidupan percintaan kamu akan menjadi lebih tenang dan santai. Hal ini akan memungkinkan kamu untuk fokus terhadap diri kamu dan cobalah mengerjakan hal-hal penting yang berguna.',
            'Hari ini akan ada godaan-godaan di sekitar kamu yang dapat mengambil sebuah belokan yang tiba-tiba dalam kehidupan emosional kamu.',
            'Jangan membuat keputusan apapun terburu-buru. Hindari menilai berdasarkan penampilan.',
            'Ada berbagai macam hal terjadi di sekitar kamu, namun kamu hanya memiliki satu keinginan, yakni sendirian. Itulah yang kamu butuhkan.',
            'Jalan pikiran kamu akan mendesak kamu untuk kembali ke cangkang kamu. Hal ini akan sangat disayangkan. Bersikaplah terbuka kepada orang lain.',
            'Apapun situasi kamu, Kamu akan merasa terinspirasi secara positif untuk bergerak mendekati ide-ide kamu. Jangan menyerah ya.',
            ]                
            let ramal2 = ramal[Math.floor(Math.random() * ramal.length)]
            await client.reply(from, ramal2, id)
            break
        case '.mimpi':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.mimpi* _teks_\nContoh : *.mimpi* _succubus_', id)
            const mimpi = await get.get('https://api.vhtear.com/artimimpi?query='+args[1]+'&apikey=bot').json()
            await client.reply(from, mimpi.result.hasil, id)
            break
        case '.togel': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const togel = ['Singapore', 'Hongkong', 'Japan', 'Macau', 'Seoul', 'Australia']
            const togel2 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const togel3 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
            const togel4 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const togel5 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
            let togel6 = togel[Math.floor(Math.random() * togel.length)]              
            let togel7 = togel2[Math.floor(Math.random() * togel2.length)]
            let togel8 = togel3[Math.floor(Math.random() * togel3.length)]
            let togel9 = togel4[Math.floor(Math.random() * togel4.length)]
            let togel10 = togel5[Math.floor(Math.random() * togel5.length)]
            await client.reply(from, `${togel6} ${togel7}${togel8}${togel9}${togel10}`, id)
            break
        case '.jodoh': //50lk 50pr
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const jodoh = [
            'Budi',
            'Ali',
            'Haikal',
            'Juned',
            'Alex',
            'Udin',
            'Otong',
            'Joni',
            'Joko',
            'Amat',
            'Petot',
            'Tigor',
            'Danny',
            'Wawan',
            'Daus',
            'Abi',
            'Anto',
            'Bambang',
            'Rizky',
            'Umar',
            'Raihan',
            'Bambang',
            'Supri',
            'Paimin',
            'Andi',
            'Aldi',
            'Aldo',
            'Christoper',
            'Pahrul',
            'Yusuf',
            'Imam',
            'Andika',
            'Jon',
            'Olga',
            'Toni',
            'Tommy',
            'Fajar',
            'Zul',
            'Lutfie',
            'Felix',
            'Doni',
            'Emon',
            'Jojo',
            'Ilham',
            'Bayu',
            'Amir',
            'Dimas',
            'Angga',
            'Toyib',
            'Taufiq',
            'Caca',
            'Wanda',
            'Mega',
            'Siska',
            'Mia',
            'Dea',
            'Tiara',
            'Frida',
            'Fellen',
            'Annisa',
            'Ayu',
            'Diana',
            'Irma',
            'Susi',
            'Putri',
            'Ani',
            'Aulia',
            'Nur',
            'Dewi',
            'Dian',
            'Sri',
            'Eka',
            'Indah',
            'Sari',
            'Memey',
            'Fitri',
            'Ratna',
            'Dyah',
            'Puspita',
            'Maria',
            'Ratih',
            'Tika',
            'Tya',
            'Febri',
            'Rahma',
            'Anita',
            'Novi',
            'Ria',
            'Yunita',
            'Vania',
            'Rina',
            'Rani',
            'Intan',
            'Rini',
            'Maya',
            'Amel',
            'Amanda',
            'Nadia',
            'Citra',
            'Wulan',          
            ]                
            let jodoh2 = jodoh[Math.floor(Math.random() * jodoh.length)]
            await client.reply(from, `Jodohmu : ${jodoh2}`, id)
            break
        case '.couple':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.couple* _pasangan_\nContoh : *.couple* _pahrul jihyo_', id)
            const couple = ['a&n2=a', 'b&n2=a', 'c&n2=a', 'd&n2=a', 'e&n2=a', 'f&n2=a', 'g&n2=a', 'h&n2=a', 'i&n2=a', 'j&n2=a', 'k&n2=a', 'l&n2=a', 'm&n2=a', 'n&n2=a', 'o&n2=a', 'p&n2=a', 'q&n2=a', 'r&n2=a', 's&n2=a', 't&n2=a', 'u&n2=a', 'v&n2=a', 'w&n2=a', 'x&n2=a', 'y&n2=a', 'z&n2=a']
            let couple2 = couple[Math.floor(Math.random() * couple.length)]
            const couple3 = await get.get('http://scrap.terhambar.com/jodoh?n1='+couple2).json()
            await client.sendFileFromUrl(from, couple3.result.gambar, 'couple.jpg', `Sisi Positif : ${couple3.result.sisi.positif}\n\nSisi Negatif : ${couple3.result.sisi.negatif}`, id)
            break
        case '.gombal': //100
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const gombal = [
            'Kalau disuruh melupakanmu, aku akan ke kelurahan dulu. Minta surat keterangan tidak mampu.',
            'Cintaku padamu seperti utang. Awalnya kecil, didiemin, tau-tau gede sendiri.',
            'Mendengar kamu kentut saja aku sudah bahagia.',
            'Aku tanpa kamu bagaikan ambulance tanpa uwiw uwiw.',
            'Ngemil apa yang paling enak? Ngemilikin kamu sepenuhnya.',
            'Hari minggu itu weekend tapi kalau cinta kita will never end.',
            'Aku rela ditangkap polisi asal tuduhannya atas pencurian hatimu.',
            'Kalau kamu jadi senar gitar, aku gak mau jadi gitarisnya karena aku gak mau mutusin kamu.',
            'Jepang bikin robot. Jerman bikin mobil. Kamu bikin kangen.',
            'Sejak kenal kamu, bawaannya pengen belajar terus. Belajar jadi yang terbaik.',
            'Aku tahu kita tak seumuran, tapi aku ingin seumur hidup dengan kamu.',
            'Aku rela jadi belalang asal kamu kupu-kupunya. Lalu kita siang makan nasi kalau malam minum susu.',
            'Katanya kalau sering hujan itu bisa bikin seseorang terhanyut, kalau aku sekarang sedang terhanyut di dalam cintamu.',
            'Aku ingin bertukar tulang denganmu. Aku jadi tulang punggungmu, kamu jadi tulang rusukku.',
            'Enak ya jadi kamu, kalau mau liat bidadari, tinggal liat di kaca.',
            '1Aku bakalan berhenti cinta sama kamu kalau gajah sudah bisa terbang sendiri.',
            'Kalau aku jadi wakil rakyat aku pasti gagal deh. Gimana mau mikirin rakyat, kalau yang selalu ada dipikiranku hanyalah kamu.',
            'Andaikan satu bintang akan jatuh tiap kali aku mengingatmu, bulan pasti akan protes. Soalnya dia bakal sendiri di angkasa.',
            'Jika kamu tanya berapa kali kamu datang ke pikiranku, jujur saja, cuma sekali. Habisnya, gak pergi-pergi sih!',
            'Angkutan kota jauh dekat 2.000, kalau kamu jauh dekat ya di hatiku.',
            'Aku rela jadi abang nasi goreng asalkan setiap malam aku bisa lewat depan rumah kamu.',
            'Aku rela dipenjara seumur hidup asalkan pelanggarannya karena mencintaimu.',
            'Mbak, aku pesen nasi goreng 1 sama jus 1 yah | jus apa mas? | jus the way you are.',
            'Sekarang aku gendutan gak sih? Kamu tau gak kenapa? Soalnya kamu udah mengembangkan cinta yang banyak di hatiku.',
            'Jangan gr deh. Aku kangen kamu sedikit aja kok. Sedikit berlebihan maksudnya.',
            'Pepatah mengatakan, empat sehat lima sempurna. Namun, aku tidak merasakan kesempurnaan itu sebelum aku merasakan kasih sayangmu.',
            'Tanggal merah sekalipun aku tidak libur untuk memikirkan kamu.',
            'Cintaku padamu bagai diare. Tak bisa kutahan, terus keluar begitu saja.',
            'Kalo nanti malam ada pocong ngintip di jendela, jangan takut yah, dia memang sengaja aku suruh untuk jagain kamu bobo.',
            'Kalo naik motor sama kamu pasti ditilang deh. Soalnya kita kan bertiga, aku, kamu, dan cinta.',
            'Neng, bakar-bakaran yuk | bakar apa? | kita bakar masa lalu dan buka lembaran baru dengan cinta kita.',
            'Di atas langit masih ada langit! Di bawah langit masih ada aku yang tulus mencintaimu.',
            'Orangtuamu pengrajin bantal yah? Karena terasa nyaman jika di dekatmu.',
            'Aku ga lulus ulangan umum sayang, gara-gara di bagian essay-nya aku tulis surat cinta buat kamu.',
            'Kera apa yang harus dimusnahkan? Keraguan untuk melamarmu.',
            'Tau ga kenapa aku mau masuk elektro? Aku mau bikin pembangkit listrik tenaga cinta. Pasti rumah kita paling terang.',
            'Kalo kamu lagi di as, patung liberty ga akan bawa obor tapi bakal bawa bunga!',
            'Tahu gak kenapa kita cuma bisa lihat pelangi setengah lingkaran? Sebab setengahnya lagi ada di mata kamu.',
            'Napas aku kok sesek banget ya?, karena separuh nafasku ada di kamu.',
            'Kamu itu seperti garam di lautan, tidak terlihat namun akan selalu ada untuk selamanya.',
            'Ada 3 hal di duinia ini yang tidak bisa kuhitung, jumlah bintang di langit, ikan di laut dan cintaku padamu.',
            'Aku tidak peduli ramalan bmkg, sebab saat hujan, badai bahkan tsunami aku akan tetap bertahan pada cintamu.',
            'Kalau kamu adalah bumi, maka aku adalah atmosfirnya. Dengan begitu setiap saat bisa melindungimu dari sakitnya serangan meteor dan komet.',
            'Aku rela dipenjara asalkan pelanggarannya karena mencintaimu.',
            'Cintaku padamu seperti ban kereta api, tidak pernah kempes.',
            'Jika aku jadi wakil rakyat sepertinya kau bakal gagal deh? Gimana aku mikirin rakyat, kalau yang ada dipikiranku hanyalah kamu.',
            'Jika kau memegang 7 bunga mawar di depan cermin, maka kau adalah mawar ke-8 yang terindah di seluruh dunia.',
            'Eh pinjem flashdisk dong, aku pengen transfer data cintaku buat kamu.',
            'Kutuliskan namamu di langit, angin meniupnya. Kutuliskan namamu di laut, badai membawanya. Kutuliskan namamu di hatiku, cinta namanya.',
            'Kalau disuruh melupakanmu, aku akan ke kelurahan dulu. Minta surat keterangan tidak mampu.',
            'Sejak kenal kamu, bawaannya pengen belajar terus. Belajar jadi yang terbaik.',
            'Aku setuju-setuju aja kok kalau harga bbm makin mahal, asalkan senyum kamu tetap murah sama aku.',
            'Berulang tahun memang indah. Akan tetapi lebih indah jika berulang kali bersamamu.',
            'Aku sukanya sih apel dibandingkan anggur, makanya aku suka ngapelin kamu ketimbang nganggurin kamu.',
            'Kamu tahu gak bedanya kamu sama daun? Kalau daun jatuhnya ke tanah, kalau kamu jatuhnya ke hatiku.',
            'Setiap melihat senyumanmu aku dapat merasakan hangatnya matahari. Setiap melihatmu tertawa aku seperti melihat indahnya bintang.',
            'Kursi makin lama makin antik, kamu makin lama makin cantik.',
            'Rumah joglo ada di jogja, kalau kamu jomlo kabarin ya.',
            'Gimana aku bisa tidur kalau jam segini kamu masih nongkrong di pikiranku.',
            'Aku ingin kita seperti sandal jepit sebab hanya ada dua, tidak ada yang namanya orang ketiga.',
            'Rasa sayangku ke kamu kaya pas powerangers waktu gak ada monste nggak berubah.',
            'Kalau hitungan satu sampai sepuluh, cintaku cukup nomor dua, yaitu dualem banget.',
            'Aku tanpamu bagaikan ambulans tanpa wiu wiuw wiuw ',
            'Kamu memang seperti lempeng bumi, bergeser sedikit saja sudah menggoncang hatiku.',
            'Dalam benak orang bijak ada ide, solusi dan alasan. Dalam benak para ahli ada formula kimia, teori dan rumus. Di dalam benakku, hanya ada kamu!.',
            'Kata dimulai dengan abc, angka dimulai dengan 123. Lagu dimulai dengan do re mi. Cinta dimulai dengan aku dan kamu.',
            'Cintaku padamu seperti utang. Awalnya kecil, didiemin, tau-tau gede sendiri.',
            'Mendengar kamu kentut saja aku sudah bahagia.',
            'Jepang bikin robot. Jerman bikin mobil. Kamu bikin kangen.',
            'Kamu tau nggak, aku seperti mentega, dan kamu seperti wajan panas. Soalnya pas lihat muka kamu aku meleleh.',
            'Angkutan kota jauh dekat 2 ribu, kalau kamu jauh dekat ya di hatiku.',
            'Sekarang aku gendutan gak sih? Kamu tau gak kenapa? Soalnya kamu udah mengembangkan cinta yang banyak di hatiku.',
            'Aku rela dipenjara seumur hidup asalkan pelanggarannya karena mencintaimu.',
            'Tanggal merah sekalipun aku tidak libur untuk memikirkan kamu.',
            'Aku rela jadi abang nasi goreng asalkan setiap malam aku bisa lewat depan rumah kamu.',
            'Jangan gr deh. Aku kangen kamu sedikit aja kok. Sedikit berlebihan maksudnya.',
            'Pepatah mengatakan, empat sehat lima sempurna. Namun, aku tidak merasakan kesempurnaan itu sebelum aku merasakan kasih sayangmu.',
            'Kalo naik motor sama kamu pasti ditilang deh. Soalnya kita kan bertiga, aku, kamu, dan cinta.',
            'Neng, bakar-bakaran yuk! | bakar apa? | kita bakar masa lalu dan buka lembaran baru dengan cinta kita.',
            'Orangtuamu pengrajin bantal yah? Karena terasa nyaman jika di dekatmu.',
            'Kalo kamu lagi di amerika serikat, patung liberty nggak akan bawa obor tapi bakal bawa bunga!',
            'Tahu gak kenapa kita cuma bisa lihat pelangi setengah lingkaran? Sebab setengahnya lagi ada di mata kamu.',
            'Di atas langit masih ada langit! Di bawah langit masih ada aku yang tulus mencintaimu.',
            'Walaupun jarak kita bagai matahari dan pluto saat ephehelium. Amplitudo gelombang hatimu berintervensi dengan hatiku.',
            'Aku rela menjadi lilin dalam hati kamu, dan kamu yang jagain lilinnya.',
            'Jika kamu tanya berapa kali kamu datang ke pikiranku, jujur saja, cuma sekali. Habisnya, gak pergi-pergi sih!',
            'Aku rela menjadi lilin dalam hati kamu, dan kamu yang jagain lilinnya.',
            'Lihat kebunku penuh dengan bunga, lihat dirimu aku berbunga-bunga.',
            'Yang kamu lihat di kulkas, itu bukan hati sapi. Itu hatiku yang beku karena ditinggal kamu.',
            'Bagaimana kalau kita berdua jadi komplotan perampok?. Aku merampok hatimu dan kamu merampas hatiku.',
            'Kamu ada spidol gak? | ada, buat apa? | buat warnaian kalender, biar gak ada kata libur untuk mencintaimu.',
            'Orang kurus itu setia, makan aja tidak pernah nambah apalagi pasangan.',
            'Cukup harga bensin saja yang turun, perasaanmu jangan.',
            'Aku hanya ingin hidup cukup. Cukup lihat senyummu setiap hari.',
            'Aku rela ikut lomba lari keliling dunia, asalkan engkau yang menjadi garis finishnya.',
            'Selain ada garuda di dadaku, di dadaku juga selalu ada kamu.',
            'Cita-citaku dulu pengen jadi dokter tapi setelah mengenalmu, berubah jadi ingin membahagiakanmu.',
            'Kamu tau gak apa persamaannya kamu sama ac? Sama-sama bikin aku sejuk.',
            'Kalau orang kebutuhan primernya ada tiga yaitu sandang pangan dan papan, tapi kalau aku : kamu, kamu, kamu.',
            ]                
            let gombal2 = gombal[Math.floor(Math.random() * gombal.length)]
            await client.reply(from, gombal2, id)
            break
        case '.twister':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.twister* _en/id_', id)
            const twister = await get.get('https://api.haipbis.xyz/randomtonguetwister/'+args[1]).json()
            await client.reply(from, twister.text, id)
            break
        case '.fml':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const fml = await get.get('https://api.haipbis.xyz/fml').json()
            await client.reply(from, fml.fml, id)
            break
        case '.yesno': //2
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const yesno = [
            'Yes.',
            'No.',
            ]                
            let yesno2 = yesno[Math.floor(Math.random() * yesno.length)]
            await client.reply(from, yesno2, id)
            break
        case '.kerang': //6
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.kerang* _pertanyaan_\nContoh : *.kerang* _apakah saya gay?_', id)
            const kerang = [
            'Tidak keduanya.',
            'Kurasa tidak.',
            'Tidak.',
            'Iya.',
            'Tidak ada.',
            'Coba tanya lagi.',
            ]                
            let kerang2 = kerang[Math.floor(Math.random() * kerang.length)]
            await client.reply(from, kerang2, id)
            break
        case '.tips': //13
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const tips = [
            'Jangan main klarinet.',
            'Jangan pernah melambaikan lampu senter ke depan dan ke belakang terlalu cepat. Itu dianggap undangan.',
            'Jangan pernah berhenti menatap sekitar.',
            'Jangan makan keju, kecuali yang kotak.',
            'Jangan pakai topi sombrero.',
            'Jangan pakai baju bodoh.',
            'Jangan pakai rok panjang.',
            'Jangan pakai sepatu merah.',
            'Jangan berlagak seperti kera.',
            'Jika beruang sudah mendekat, buat gambar lingkaran besar untuk melindungi diri dari gigitan beruang. Usahakan jangan lonjong.',
            'Jangan lari.',
            'Jangan jalan pincang.',
            'Jangan merangkak.',
            ]                
            let tips2 = tips[Math.floor(Math.random() * tips.length)]
            await client.reply(from, tips2, id)
            break
        case '.riddle': //10
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const riddle = [
            'Parrot\n\nAku mulai kesepian karena terlalu lama tinggal sendirian. Karena itu, aku memutuskan memelihara seekor burung kakatua. Kakatua itu mulai meniru semua perkataanku, bahkan menyapaku tiap hari. Tiap pagi ia selalu berkata, “Ohayou” (selamat pagi) dan tiap malam ketika aku pulang kerja, ia selalu berkata, “Welcome.” (selamat datang). Benar-benar burung yang pintar.',
            'Night of Cold Day\n\nKami baru saja pulang kantor dan karena malam ini cukup dingin, temanku memutuskan membeli sesuatu yang hangat dulu di warung.\nSaat aku berdiri di luar menunggunya, aku bertabrakan dengan seorang anak kecil.\n“Oh maaf,” kataku, walaupun anak itu yang menabrakku. Namun anak itu tetap saja berlari tanpa bahkan melihat ke arahku. “Dasar anak sekarang,” pikirku, “Diajari apa sama orang tuanya?” Lagipula malam-malam begini mengapa anak sekecil itu berada di luar rumah?\nTiba-tiba seorang wanita berlari dengan tergopoh-gopoh ke arahku, “Apa anda melihat anak saya?” tanyanya.\n“Oh, tadi ia berlari ke arah sana!” jawabku.\nTemanku kemudian keluar dan kamipun melanjutkan perjalanan. Karena sangat mengantuk, aku segera tertidur. Namun paginya, aku menemukan berita mengejutkan di koran bahwa seorang ibu yang memiliki seorang anak ditemukan terbunuh di rumahnya malam itu. Yang membuatku kaget, peristiwa ini terjadi tak jauh dari warung dimana temanku membeli minuman hangat tadi malam. Ah, semoga saja wanita itu bukan ibu yang kutemui tadi malam. Kasihan jika benar. Lingkungan ini benar-benar tidak aman. Aku harus pindah secepat mungkin.',
            'A Killer Inside The House\n\nAku terbangun tengah malam dan merasakan suatu perasaan tak enak.\nAku menyalakan lampu mejaku dan melihat genangan darah yang sangat banyak di selimutku.\nAku menjerit dan berlari keluar kamarku. Aku buru-buru turun ke lantai bawah dan melihat Buddy, anjingku, kini terbaring bersimbah darah di dasar tangga. Aku hendak keluar melalui pintu depan ketika aku mendengar suara di ruang makan. Pembunuh itu masih ada di sini!\nAku segera berlari ke atas lagi untuk menemukan orang tuaku, berharap mereka masih hidup.\nAku membuka pintu kamar orang tuaku dan melihat kolam darah di lantai. Darah menetes dari atas tempat tidur dimana kedua orang tuaku terbaring tak bernyawa.\nAku mendengar sang pembunuh naik ke atas. Pelan namun pasti, ia membuat suara decitan ketika kakinya menginjak anak tangga yang terbuat dari kayu.\nAku meringkuk di pojok ruangan,tak ada lagi jalan keluar.\nPembunuh itu masuk melalui pintu.\nAku bernapas lega. Itu bukan pembunuh, ternyata itu pria berseragam polisi.\nAku hendak berlari ke arahnya, meminta tolong. Namun ia justru bergerak mundur ketika ia melihatku.\n“Ke…kenapa?” tanyaku ketakutan, “A…apa ia ada di belakangku?”\nKemudian ia berkata dengan suara tegas sambil berusaha meraih pistol yang ada di sabuknya.\n“Nak, tenanglah dan berikan kepadaku pisau itu!”',
            'Test of Courage\n\nSaat OSPEK, kami semua diharuskan mengikuti uji nyali di sebuah pemakaman tua. Kami dikirim berdua-dua untuk melintasi kuburan tersebut untuk menguji keberanian kami. Aku dan temanku sangat ketakutan karena saat itu sudah tengah malam.\nBegitu sampai di kamp, kami berdua tertawa sambil menunjukkan tangan kanan kami yang membiru. Pasti karena kami berpegangan tangan terlalu erat saking takutnya. Kalau dipikir-pikir hal itu sangat konyol. Tak ada alasan bagi kami ketakutan seperti itu sebab tak ada satupun hal seram terjadi pada kami malam itu.',
            'Fireworks\n\nMalam itu aku menyaksikan kembang api dari lantai atas sebuah gedung bersama sahabatku.\n“Hei, maafkan aku akhirnya jadian dengan mantanmu,” katanya, “Aku merasa seperti orang jahat, merebutnya darimu.”\n“Ah tidak apa-apa.” Jawabku, “Dia kan sudah memilihmu. Aku justru senang.”\n“Oh, begitu. Syukurlah kamu tidak marah. Selamat tahun baru…”\n“Selamat tahun baru!” aku berkata sambil menepuk punggung sahabatku itu.',
            'Vandalism\n\nBelakangan ini aku mengalami kejadian tak mengenakkan. Begitu aku pulang, kamarku selalu saja acak-acakan. Tak ada yang hilang sih, tapi ini mulai mengangguku. akhirnya aku memutuskan untuk memasang kamera CCTV di pojok kamarku.\nKetika aku pulang hari ini, akupun mengecek isinya. Awalnya tak ada apapun yang terjadi, namun kemudian aku melihat kenop pintuku berputar. Pintu kamarku terbuka dan seorang wanita, sambil membawa pisau di tangannya, masuk ke dalam kamarku. Sambil tertawa-tawa ia mengobrak-abrik seisi kamarku dan kemudian bersembunyi di dalam lemari.\nDi dalam video, seseorang kembali memutar kenop pintu dan membukanya. Itu aku.',
            'Murder\n\nHari ini aku mengundang temanku, A, untuk bermain game di rumah. A dan aku bermain game hingga larut malam. Akhirnya kami lelah dan memutuskan menonton televisi. Malam itu sangat membosankan karena semua acara prime time sudah habis dan yang tertinggal hanyalah acara berita. Namun ada satu berita yang menarik perhatianku,\n“Pagi ini di Chiyoda terjadi sebuah kasus pembunuhan misterius. Korbannya adalah seorang guru karate dan tubuhnya ditemukan terpotong-potong. Perlu diingat bahwa senjata pembunuhnya belum ditemukan jadi sangat sulit bagi polisi untuk melacak pelaku sebenarnya ..”\n“Wah seram sekali. Bukankah tempat tinggalmu di Chiyoda? Berhati-hatilah!” kataku pada A.\nA hanya tertawa, “Hahaha, menakutkan sekali, ada pembunuh berantai berkeliaran …”\n“Aku serius. Mungkin ia mengincar jago bela diri. Bukankah kau juga ahli judo?”\n“Ya…ya…ya…justru karena aku ahli judo, aku bisa membela diri kalau bertemu dengannya. Eh, hari sudah malam, aku pulang saja.”\n“Hei, menginap saja di sini! Bahaya kalau kau pulang malam-malam!”\n“Hahaha….aku sama sekali tak takut dengan pembunuh yang berkeliaran membawa pisau dapur. Bye!”\nAku mengantar A ke pintu dan begitu ia pulang, aku gemetar ketakutan.',
            'A Short Nap\n\nAku sangat lelah. Memiliki dua anak di bawah umur 3 tahun sangat menguras tenagaku. Aku tenggelam ke dalam sofa dengan penuh rasa syukur, mematikan televisi, dan benar-benar menikmati suasana tenang yang langka ini. Aku pasti tertidur karena kelelahan sebab hal berikutnya yang aku tahu, suamiku yang baru pulang kerja menggoncang-goncangkan bahuku.\n“Hei, tukang tidur.” katanya, “Apa anak-anak sudah tidur semua?”\nAku segera panik, melompat dari sofa, dan meninggalkan suamiku yang dalam kondisi kebingungan melihat reaksiku. Aku berlari ke arah lorong. Detak jantungku memuncak ketika aku mencapai pintu di sebelah kanan. Aku berdoa, berharap aku salah.\nAku membuka pintu kamar mandi.',
            'Intern Teacher\n\nSuatu hari seorang calon guru melakukan magang di sebuah SD di Jepang. Ini adalah kali pertamanya mengajar, sehingga ia merasa sangat gugup. Untunglah murid2nya sangat ramah dan dengan waktu cepat ia sudah merasa dekat dengan murid2nya.\nNamun beberapa hari sebelum masa magangnya berakhir, salah seorang anak perempuan di kelasnya meninggal bersama kakak laki2nya. Mereka sedang tertidur di lantai dua saat api menelan rumah mereka. Hanya kedua orang tuanya dan adik mereka yang masih bayi yang tidur di lantai satu mereka menyelamatkan diri.\nTeman2 sekelasnya shock dan menangis tersedu-sedu saat upacara pemakaman mereka. Setelah pemakaman, sang guru magang melihat-lihat lukisan yang dibuat oleh gadis itu sebagai tugas kelas seni. Temanya adalah keluarga. Di sana ia menggambar rumah dan keluarganya. Ia dan kakaknya sedang melambaikan tangannya dari jendela lantai dua. Sementara ayahnya sedang menggendong bayi mereka, bersama dengan ibunya yang sedang menyirami tanaman di halaman.\nMereka terlihat seperti keluarga yang bahagia. Sungguh sangat disayangkan.',
            'kaca Mata\n\nAku baru berumur 7 tahun ketika orang tuaku mengetahui bahwa aku sebuta kelelawar. Sebenarnya kelelawar tidaklah buta. Mereka memiliki penglihatan, namun sangat buruk. Seperti itulah kondisiku. Aku belum pernah mengikuti tes penglihatan sehingga aku beranggapan bahwa orang lain melihat sebagaimana aku melihat dunia. Aku hanya melihat bayangan-bayangan kabur, figur yang samar-samar, cukup untuk membuatku tidak menabrak mereka. TV bagiku adalah radio yang dilengkapi dengan permainan cahaya dan aku hanya bisa membedakan mainanku dari warna-warnanya. Ketika aku tak kunjung belajar membaca, orang tuaku membawaku ke rumah sakit dan akhirnya mengetahui kekuranganku.\nDuniaku berubah selamanya ketika aku mendapat kacamata pertamaku.\nAku melihat segalanya! Aku melihat kamar dokter mata, dinding, langit-langit, tanganku, dan orang-orang yang ada di ruangan. Aku melihat ayah, ibu, dokter, dan para perawat. Dengan takjub aku melihat warna mata ayahku untuk pertama kalinya.\nNamun untuk pertama kalinya pula aku masih melihat beberapa orang di ruangan tetaplah samar, gelap, dan kabur. Mereka ada banyak dan aku tahu mereka mengawasiku seperti aku mengawasi mereka.\nDan aku menyadari kaki mereka tak menyentuh tanah.',
            ]                
            let riddle2 = riddle[Math.floor(Math.random() * riddle.length)]
            await client.reply(from, riddle2, id)
            break   
        case '.pantun': //100 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const pantun = [
            'Luar pelabuhan namanya demaga\nmau berenang mesti ati-ati\nkalo perempuan mau masuk surga\nharus turutin dah apa kata suami',
            'Dapet kado isinya tomat\nbodo amat!!',
            'Kalau sudah namanya cinta\nberbunga-bunga rasanya hati\nkalau sudah ketemu si dia\nkayak orang gila senyum2 sendiri',
            'Buah kedondong buah kesemek\nbuah naga buah apel\nbuah manggis buah duren\nitulah nama-nama buah',
            'Makan nasi sepiring berdua\nsungguh nikmat tiada tara\nawas cowok suka menggoda\ndiam-diam dia buaya',
            'Buka facebook, pake kata sandi\nelo budug emang jarang mandi',
            'Si mamang beli senjata\nsenjata buat nembak si poltak\nkau memang cantik jelita\nsayang tawamu mirip kuntilanak',
            'Ke pasar, nyari obat gatal\ndasar, gak modal!',
            'Disana gunung, disini gunung,\nditengah-tengah pulau jawa\nsaya bingung, kamu juga bingung\nitu gunungnya segede apa',
            'Dulu delman, sekarang gokar\ndulu teman, sekarang pacar',
            'Si supri jago kayang\nsi dodo pura-pura mati\nsetiap hari mabuk kepayang\nkalau tak jumpa si jantung hati',
            'Stroberi mangga apel\nsorry gak level',
            'Jalan jalan ke kota depok\neh nemu uang segepok\napa gerangan dibalik tembok\ntaunya nenek lagi cebok',
            'Kakak monyonk adiknya memble\ndah turunan jelek kali ye',
            'Buah duku buah rambutan\ncuci piring bawah jembatan\nentah jodoh atau pun bukan\nmari awali dengan persahabatan',
            'Ayam kurus bulunya banyak\nkasian yang beli, rugi bandar',
            'Berlayar-layar ke tepian\ndari hulu sungai bengawan\ndaripada hidup kesepian\nmending kita cepat nikahan',
            'Buah duren di pohon pisang\nrese amat tuh duren',
            'Jalan-jalan ke negeri arab\njangan lupa membeli kitab\ncewek sekarang tidak bisa diharap\nbodi bohai betis berkurap',
            'Buah kedong-dong buah tomat\neh lu odong amat',
            'Badan sakit karena meriang\nminum obat pemberian kawan\npercayalah! Saya ini pria penyayang\nsayang kepada banyak perempuan',
            'Buah pisang buah tomat\ndisimpan di lumbung padi\npantas tercium bau menyengat\nrupanya kau yang belum mandi',
            'Jalan-jalan ke kota solo\njangan lupa mampir ke bantul\nbegini nasib seorang jomblo\ncuma bisa memeluk dengkul',
            'Anak pramuka orang jakarta\nbeli lem yang amat pekat\nsaya buka lowongan cinta\nsilakan dm bila berminat',
            'Jangan takut\njangan kawatir\nitu kentut\nbukan petir',
            'Gud morning, selamat pagi!\ngigi elo kuning, bau terasi',
            'Bola pingpong dimakan gelatik\nbiar ompong yang penting cantik',
            'Ke cikini bawa keranjang\nkeranjang kotak dari sampang\nbagaimana hati tiada bimbang\nkepala botak kok minta dikepang',
            'Sayur matang punya si bopak\nmakan lalap dicampur sambel\ntidur telentang gak bisa nyenyak\ntidur tengkurap ada yang ganjel',
            'Di penjara jualan kerupuk\nkerupuk opak rasa kikil badak\nresiko asmara dunia facebook\ncinta ditolak unfriend bertindak',
            'Sakit hati rasanya pedih\nmending makan rujak kedondong\ndaripada menangis sedih\nmending kamu saya gendong',
            'Bawa peti ke tengah kota\njatuh di kali berair amis\nbila hati sudah jatuh cinta\nkopi pahit terasa manis',
            'Ke pontianak beli kopiah\nkopiah indah kau dapati\nbegitu banyak gadis yang singgah\nhanya dinda yang memikat hati',
            'Warna balon rupa-rupa\ndibeli di hari raya\naku tak mengharap apa-apa\nhanya cinta dan setia',
            'Burung perkutut tersambar petir\nkayu jati untuk diukir\njangan takut jangan khawatir\nhatiku setia sampai akhir',
            'Sumedang dulu sebelum bandung\ndi jalanan naik sepeda\nsejak dulu hatiku bingung\nbenar ternyata kamu mendua',
            'Ada buaya jangan diganggu\nbuaya tidur tak punya nama\nsudah lama aku menunggu\nkapan cintaku kau terima? ',
            'Ikan patin jadi masakan\ndimasaknya di kota palembang\nkurus badan bukan kurang makan\nkurus memikirkan kamu seorang',
            'Badan sakit pasti meriang\nminum obat dari cawan\nsaya ini pria penyayang\nsayang kepada banyak perempuan',
            'Masuk debu pedihlah mata\npergi ke desa naik kereta\nmenatap kamu makin cinta\napakah impian kan jadi nyata? ',
            'Bangau pergi menuju kota\npulang lagi ke hutan alam\ndi balik hati ada cinta\nmekar di dalam diam-diam',
            'Kalau ingin batu permata\nmenyelamlah ke samudera\nkalau ingin sebuah cinta\naku siap memberikannya',
            'Bila ingin ikan petis\ndatang saja ke maluku\njika ingin lelaki romantis\ndatang saja kepadaku',
            'Kayu meranti kayu telugu\ntumbuh anggrek jadi benalu\nkamu menanti aku menunggu\nmengatakan cinta rasanya malu',
            'Perahu layar ke tepian\ndari hulu sungai asahan\ndaripada hidup kesepian\nmending kita cepat nikahan',
            'Tepi pantai bermain pasir\nkota jepara kota ukir\nsudah lama diriku naksir\nnamun dia kelamaan mikir',
            'Buah mangga buah kweni\ndimakan dengan pisang raja\nmohon terima cintaku ini\nkalau tidak, pedih terasa',
            'Anak ikan main di paya,\nbanyak berudu tiada induknya\ntolong katakan kepada saya\nkalau rindu apa obatnya?',
            'Pergi ke kebun ambil pepaya\nbanyak petani sedang bekerja\ntolong obati hati saya\ndengan cinta darimu saja',
            'Naik delman dekat pak kusir\nbanyak lubang lambat jalannya\npantas saja saya naksir\nkamu memang cantik orangnya',
            'Ada orang maluku di jitak\ndijitak sama orang batak\nselama jantungku masih berdetak\ncintaku tak akan luluh lantak',
            'Buah markisah buah kdondong\nhey org susah jgn bengong gitu donk',
            'Melon manis di air es\nkemana ajach lo ga pernah chat\nanak tikus rindu ibunya\nsombong nich ceritanya',
            'Ke pulau naik perahu\npulangnya sama si titik\njika kamu sahabatku\npasti akan jadi cantik',
            'Indah sungguh bunga di taman\ndisusun orang buat ucapan\ningin kuselam hatimu teman\nbegitu sukarnya mencari jawaban',
            'Hobiku adalah memegang palu\nribuan jendela telah ku buka\nku ingin kamu jadi sahabatku\nmeski dilanda suka duka',
            'Anak haruan mati terperangkap\nbelut itu dikatakan sepat\npadamu sahabat daku berharap\ndi sudut hatiku namamu terpahat',
            'Lihat pemandangan dari jembatan\npakai kemeja terlihat gagah\ningat kawan jaga persahabatan\nkarena sahabat sangatlah indah',
            'Suara si pungguk mendayu-dayu\nmemuja bulan tak pernah jemu\nbiar di dunia kuhimpun rindu\ndi akhirat sana kumohon bertemu',
            'Janganlah kau gundah\naku khawatir kesambet setan\npantai itu memang indah\ntapi lebih indah persahabatan',
            'Mengintai kejora dimalam hari\nhanya kelihatan menjelang pagi\nterimakasih sahabat kerana memahami\nsegala kelemahan diriku ini',
            'Tersungging senyum manis di bibirmu\nhilanglah duka terpancar rindu\nku ukir namamu di dasar qalbu\nukhwah prsahabtan menjadi dambaku',
            'Yang merah itu dikatakan cinta\nyang indah itu dikatakan berharga\nbagaimana akhirnya persahabatan kita\nsmoga menuntun hingga ke syurga.',
            'Ke rumah nenek untuk sowan\nrumah nenek di kota tamanan\nsekian dari ku kawan\nsemoga bermanfaat dalam pertemanan',
            'Dari bali beli bunga sekuntum\ntapi langsung diambil abdul\npilihlah teman yang sopan santun\njangan pilih yang amburadul',
            'Menatap langit melihat awan\nditemani anak bernama tia\nyang terakhir untukmu kawan\npilihlah teman yang betul setia',
            'Jangan menulis diatas kaca\nmenulislah diatas meja\njangan menangis karena cinta\nmenangislah karena dosa…',
            'Diseberang sungai ada sulaiman\nternyata ada juga si wawan\nberikut beberapa tips berteman\nuntuk kamu wahai kawan',
            'Pergi bernyanyi di dekat taman\nbernyanyi bersama dengan si pragia\nhai kawan pandailah berteman\ntuk hidup tentram bahagia',
            'Merenung langit di kala senja\nmengharap fajar akan menjelma\npadamu tuhan kupanjatkan doa\npersahabatan ini subur selamanya',
            'Buah duku buah rambutan\ncuci piring bawah jembatan\nentah jodohku entah bukan\nyang penting persahabatan',
            'Ada kepompong ada kupu\nbales donk chat dari aku',
            'Sebuah dinding tertempel grafik\nternyata dibuat oleh si akang\npilih juga yang tidak munafik\nbaik di depan baik di belakang',
            'Di kursi ada bunga sekuntum\nlalu langsung diambil abdul\npilihlah teman yang sopan santun\njangan pilih yang amburadul',
            'Sarapan pagi pake tempe\nsiang dikit pake jagung\ntampangnya ucup sih memang oke\ntapi sayang otaknya linglung',
            'Kacang di rebus biar mateng\nmateng masak buah ke dondong\nbang ucup aye akuin si orangnya ganteng\nganteng nya si cuma di kampung gedong',
            'Makan permen jangan dikulum\nbeli paku pada karat\nassalamualaikum\nyang gak nyaut biar pada asem urat',
            'Beli rebung dipasar kenari\ndari cikarang ke cileunyi.\nmandiin burung tiap pagi,\nampe skarang kagak bunyi-bunyi',
            'Badan siapa terkena kudis\nobatnya borehin lada\nsiang malem abang godain gadis\npas bersanding ama janda',
            'Ke tanah abang beli selendang\nke cikarang makan nasi padang\neh bang iye dulu aye rela di panggil sayang\ntapi sekarang kalo manggil lagi aye tendang.',
            'Jangan suka minum kapsul\napa lagi yang warnanya merah\nsiapa bilang malem jumat pada sunah rosul\norang lagi lampu merah',
            'Ke apotik beli obat kapsul\nada ikan dimakan trenggiling\nenak punya bini pada sunah rossul\ncuma aye sunahnya ama bantal guling,',
            'Ke sebrang beli lada\nsampe di sebrang beli bakwan\nsekarang banyak janda\nyang ngaku-ngaku masuh perawan',
            'Dari mana asalnya pete\njalan-jalan beli cakwe\nkalo udah dipepet pak erte\nmasih ada bang disamping rumah pak erwe',
            'Kekemang beli kaen\neh dapetnye malah pete\nlah emang ada yang laen\nudeh dipepet sama pak erte',
            'Kapal selem udah berkarat\nrumanah beli obat kapsul\nini malem, malem jum’at\npada siap-siap sunah rasul',
            'Banyak-banyak menabung\nkagak nyambung',
            'Jalan kaki ke pasar baru\njauh boooooooooooo….',
            'Buah semangka berdaun sirih\nbuah ajaib kali yah????????? ',
            'Disini bingung, disana linglung\nmangnya enak, engga nyambung….',
            'Beli duren ke irian jaya\nemang disini dak ada ya',
            'Jaka sembung naik becak\nlagi males jalan cak',
            'Ayam kurus bulunya banyak\nrugi banget yang beli………',
            'Jalan kaki ke kalimantan…\ncepeeeee deeeeehhhh. ',
            'Pergi ke pasar, nyari obat gatal\ndasar, gak modal!!',
            'Buah semangka buah duren\nnggak nyangka gue keren',
            'Buah kedondong buah atep\ndulu bencong sekarang tetepp',
            'Buah mangga buah manggis\nternyata ada cewek maniez',
            'Buah manggis buah pepaya\ncewek manis siapa yg punya',
            'Belok kanan kudu ati-ati\nnenek-nenek kaga punye banda\ntulung jangan dimasukin ati\nkan ane cuma bercanda',      
            ]                
            let pantun2 = pantun[Math.floor(Math.random() * pantun.length)]
            await client.reply(from, pantun2, id)
            break
        case '.cerpen': //7
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const cerpen = [
            '"Baik Luar Dalam"\n\n"Din, ada Devi tuh di depan nyariin kamu katanya, ditemuin gih. Dah nungguin dari tadi." Sahut Devi kepada Dinda yang sedang mengerjakan tugas sekolah di rumah Dinda.\n"Bi surti, bilang aja aku gak ada, lagi keluar apa cari alasan lain gitu." Pinta Dinda pada Bi Surti yang bekerja di rumahnya.\n"Iya, Non."\n"Kamu kenapa kaya gitu sama Devi? Dia sudah datang jauh-jauh malah kamu gituin. Devi itu anak baik lho, Din."\n"Iya dari memang luarnya keliatan baik, manis, ramah. Tapi apa hanya itu saja kamu mengukur sifat seseorang? Dari luar memang manis. Tapi dalamnya tuh pahit."\n"Pahit gimana maksudnya?"\n"Devi itu sering ngomongin keburukan temannya sendiri di belakang orangnya. Banyak pokoknya, yang gak bisa aku jelasin ke kamu.\n"Beda sama kamu, lihatlah kamu ini. Judes, ceplas-ceplos kalo ngomong sama aku. Tapi hatimu tulus, Tin, bukan baik di luar tapi dalamnya busuk. Aku gak butuh kawan yang tampilan luar orang dalam berteman." Jelas Dinda.',
            '"Cowok Idaman"\n\nPagi itu Tya berangkat sekolah bersama Ica sahabatnya. Sembari menyusuri lorong kelas yang biasa mereka lewati, Tya bertanya pada Ica.\n"Ca, menurutmu tipe cewek idaman Ari itu kaya gimana sih?"\nSambil tersenyum Nina lantas menjawab. "Gimana ya? Setahuku tipenya Ari sih gak muluk-muluk. Karena setahu aku dia lebih suka sama cewek yang natural gitu lah."\n"Hmm gitu ya, gak suka sama cewek yang hobi dandan berarti" Sambut Tya dengan wajah yang semakin berbinar kegirangan.\n"Ya kira-kira seperti itu lah."\n"Terus gimana dong supaya wajah tetep cantik meski gak pake make up tebal?" Tanya Tya lagi.\n"Coba aja kamu pakai masker bengkoang dan scrub gula pasir biar bibir merah merona gitu" Jawab Ica.\n"Wah iya juga ya, nanti malam ku coba deh Ca"\nSelama beberapa hari Tya mencoba ide yang diberikan oleh Ica. Tya pun sangat senang karena wajahnya lama kelamaan mulai tampak lebih cerah dan berseri. Bekas jerawat yang awalnya tampak jelas pun sudah mulai menghilang.\nMasker Bengkoang dan Scrub gula pasir untuk wajah dan bibir pun tak pernah lupa untuk terus ia gunakan mengingat seminggu lagi bakal ada acara pensi.\nPastinya di acara ini Tya bakal ketemu Ari dan dia harus tampil cantik dan mempesona agar menarik perhatian Ari, Lelaki idamannya.',
            '"Tak Konsisten"\n\nTerdengar bunyi alarm begitu keras mengusik tidur agus yang begitu terlelap. Dia mengeliat menahan rasa kantuk. Kemudian dia membuka matanya secara perlahan.\n"Oh Tuhan!" Agus terkejut melihat jam ternyata pukul 07.00 pagi. Dia langsung bergegas  menuju kamar mandi, kemudia dia mandi dan merapikan diri lalu tancap gas untuk pergi ke kantor. Sesampainay ia di kantor, dia sudah terlambat menghadiri meeting yang diajukan dari jam biasannya karena bosnya akan segera pergi keluar Negri.\n"Maaf, Pak. Saya boleh masuk?" Tanya Agus pada bosnya yang sedang memimpin meeting.\n"Iya, silahkan duduk, Gus, tapi maaf hari ini proyekmu digantikan oleh Riyan."\n"Tapi kenapa, Pak? Saya hanya terlambat sebentar."\n"Ini bukan masalah sebentar atau lama. Kita di perusahaan ini para pekerja profesional. Project itu dari dulu saya percayakan sama kamu tapi kamu ternyata tidak bisa konsisten. Meskipun telat sebentar, ada diantara temanmu yang bisa memberi ide bagus untuk proyek itu. Jadi maaf sekali lagi, sudah bagus kamu tidak saya keluarkan dari tim." Jelas bosnya dengan tegas.\nLangsung seketika Agus terdiam dengan wajah yang penuh dengan penyesalan. Setelah meeting selesai Agus pergi menuju meja kerjanya.\n"Kamu kenapa hari ini, Gus? Sampai telat seperti ini tak seperti biasannya."\n"Ini salahku, Dev. Aku begadang semalam nonton bola Tim kesukaanku sampai larut malam, sampai-sampai aku lupa kalau ada project penting dan seharusnya menguntungkan bagiku."\n"Hmm makanya kamu harus mengutamakan profesi dari pada hobi." Sambung Devi sedikit menasehati.',
            '"Trauma"\n\nDari dalam sebuah ruangan terdengar suara ketukan pintu.\n"Silakan masuk" Sambung Pak Abdillah dari dalam ruangan.\n"Maaf pak, apakah Pak Abdillah ada?" Tanya seseorang yang sedang dipanggil interview.\n"Tidak ada, silakan keluar!"\nSelanjutnya…\n"Maaf pak"\n"Tau di mana Pak Abdillah? Kenapa Office Boy (OB) yang ada di dalam ruangan?" Tanya seseorang itu kepada karyawan lain yang berada di luar ruangan.\n"Yang di dalam tadi Pak Abdillah. Dia memang suka pura-pura seperti itu untuk mengetes bawahannya." Ia menjelaskan.\n"Maksudnya pak?"\n"Ya artinya kamu tidak lolos interview hari ini, begitulah Pak Abdillah. Dia trauma dengan beberapa bawahannya karena urusan materi."',
            '"Rajin Belajar"\n\nHari Senin yang sangat cerah. Setelah anak-anak selesai malaksanakan upacara bendera, mereka semua menuju kelas nya masing masing untuk belajar di kelas nya.\nHari ini ada empat mata pelajaran yakni, matematika, Bahasa indonesia, Bahasa Inggris, dan Sejarah.\nMata pelajaran yang pertama adalah matematika. Bapak guru menyuruh untuk ,engerjakan halaman 7 sampai 8.\nSuasana di dalam kelas nampak hening ketika para siswa sedang mengerjakan soal yang di berikan oleh bapak guru tersebut.\nSetelah selesai, kemudian pak guru berpesan kepada murid-muridnya untuk mempelajari materi per-kalian dan pembagian dengan soal cerita karena sewaktu-waktu akan diadakan tes dadakan.\nSetelah selesai melaksanakan proses belajar di sekolah, para siswa kemudian pulang kerumahnya masing-masing.\nDinda, Nuryati, dan Indah pulang bersama, mereka bertiga berjalan kaki karena memang jarak sekolah kerumah mereka tidak terlalu jauh.\n"Setelah makan siang nanti kita bermain bersama ya?. Di rumahku ada boneka baru yang di belikan ayahku dari Bandung." Pinta Indah kepada kedua temanya.\n"Asyik." Ucap Dinda dengan penuh kegembiraan.\n"Gimana, Nur, kamu bisa ikut gak?"\n"Aku tidak bisa ikut. Aku mau belajar saja, karena tadi kan pak guru berpesan untuk belajar untuk persiapan karena akan ada tes dadakan." Sanjang Nuryati dengan polosnya.\nSesampai di rumahnya, Tika langsung ganti baju, makan siang, kemudian tidur siang agar malamnya dia bisa belajar dengan tenang dan bisa konsentrasi.\nSesekali ia bertanya kepada ayahnya jika ada yang kurang paham dengan materi di buku.\nSedangkan Dinda dan Indah asyik bermain boneka hingga larut sehingga mereka tidak sempat mempelajari materi. Keesokan harin nya mereka berangkat bersama, sesampai di kelas, ternyata memang ada tes dadakan.\nDinda dan Indah merasa kesulitan mengerjakan soal-soal yang diberikan oleh pak guru dan akhirnya mereka mendapat nilai jelek sehingga mereka harus mengulang tes susulan.\nLain halnya dengan Nuryati. Ia mendapat nilai terbaik di antara teman satu kelas nya karena dia sudah belajar dengan sungguh-sungguh sesuai nasihat gurunya. Bapak guru meminta agar Dinda dan Indah belajar dengan temannya, Nuryati.\n"Wah, Nur, selamat ya, kamu mendapa nilai terbaik. Besok kita akan ikut belajar denganmu ya." ucap Dinda pada Nuryati.',
            '"Keutamaan Sedekah"\n\n"Bu, hari ini barang dagangan tidak habis bahkan hanya sedikit sekali yang terjual. Hanya segini yang bisa Bapak berikan ke Ibu." Sambil memberikan uang hasil dagangan kepada istri nya untuk kebutuhan sehari hari."Iya Pak, tidak papa yang penting Bapak sudah berusaha dan memang selebihnya ini merupakan rejeki dari Tuhan."\nKeesokan harinya, sang suami berangkat bekerja lagi dengan membawa barang dagangannya ke pasar. Di tengah-tengah perjalanan ia bertemu dengan nenek tua yang terlihat kebingungan pinggir di jalan.\n"Ada apa nek?" Tanya pak Tugimin kepada nenek tua tersebut.\n"Nak, bolehkah nenek meminta uang? Nenek ingin pulang tapi tidak ada ongkos." Pinta nenek lirih kepada Pak Tugimin.\n"Uangku juga mepet, dagangan saya dari kemarin tidak laku banyak, untuk makan saja masih kurang, ah tapi tidak apa-apa. Kata pak ustad sedekah akan melancarkan rejeki, bismillah saja." Gumam pak Tugimin dalam hati.\n"Baiklah, Nek, ini ada uang tapi tidak terlalu banyak buat naik bis nenek sampai tujuan ya. Biar saya antar sampai ke terminal." Ucap Pak Tugimin sambil mengantar nenek tersebut menuju terminal.\n"Terima kasih nak, sudah mau membantu nenek, semoga rejekimu selalu lancar."\n"Aamiin, Nek".\nSetelah mengantar nenek tersebut, Pak Tugimin kembali ke pasar melanjutkan menjual dagangannya. Sesampainya Ia di pasar, ada seorang pembeli yang hendak memborong dagangannya sampai habis.\n"Alhamdulillah rejeki memang tidak akan tertukar. Memang sedekah akan melancarkan rejeki." Gumam Pak Tugimin bersyukur.',
            '"Malas Sekolah"\n\nMinggu menjadi hari libur yang membuat orang malas melakukan aktivitas. Ada yang memilih berlibur, ada pula yang memilih di rumah melepas lelah setelah hari-hari sebelumnya penuh dengan aktivitas.\nBegitu pula dengan Dani, dia memilih untuk bersantai-santai di rumahnya. Sampai-sampai setelah hari Minggu Dani masih belum siap menghadapi aktivitas sekolah yang menurutnya sangat membosankan.\n"Dik, kamu tidak berangkat sekolah? Ini sudah siang lho. Nanti telat." Tanya ibunya.\n"Dicky masih capek, Bu. Bolos sehari saja tidak apa-apa. Lagian gak ada PR dan tes kok. Bu."\n"Ya jangan begitu. Sekolah itu bayar loh Dik. Menuntut ilmu itu jangan kami sepelekan begitu saja Dik." Jawab ibu nya menyanggah.\n"Sudahlah bu, Dicky masih ngantuk mau lanjut tidur lagi."\nMelihat gelagat dari anaknya, ibunya menjadi kesal dan geram dan menyeret anaknya ke sebuah tempat. Kemudian ibunya mengajak Dicky ke panti asuhan yang disana dipenuhi oleh anak anak dengan latar belakang yang berbeda.\n"Nah, lihat mereka. Sudah tidak punya orang tua yang membiayai sekolah padahal mereka juga mau sekolah." Jelas ibunya memberi tahu anaknya.\nKemudian ibunya mengajak nya lagi ke suatu tempat yang disana banyak anak-anak yang mengamen di jalanan. "Lihat mereka, mereka mengemis mencari uang. Untuk makan saja mereka harus bersusah payah apa lagi untuk biaya sekolah." Jelas ibunya lagi.\nKemudian Dicky sadar dan akhirnya Ia mau berangkat sekolah meskipun agak terlambat. Dia diantar ibunya sampai ke sekolah. Di dalam perjalanan menuju sekolah dia melihat anak sekolah yang berjalan pincang.\n"Alangkah beruntungnya aku, masih memiliki fisik yang sempurna tapi bermalasan-malasan untuk sekolah. Sedangkan mereka yang cacat saja bisa semangat seperti itu." Gumamnya dalam hati.',
            ]                
            let cerpen2 = cerpen[Math.floor(Math.random() * cerpen.length)]
            await client.reply(from, cerpen2, id)
            break
        case '.puisi': //7
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const puisi = [
            'Menyerah\n\nCerita keteladanan membuat aku merasa mual\nSemua kurasa sudah cukup, aku ingin memuntahkannya\nMual dengan apa yang ada padaku\nMemuntahkan semua yang menjadi milikku\nBagaimana bisa?\nAtau hanya aku yang tidak bisa\nTerdiam bagai patung, mencerna tanpa memperoleh makna\nDalam satu atau dua, mati menjadi lebih terpuji\nBelajar lebih banyak untuk  mengerti tanpa berkuasa atas diri sendiri',
            'Butir Mutiara Dari Pendosa\n\nAku pendosa, hilangkan taat untuk khianat\nMemilih pergi dari tinggal untuk mati\nNaluri memaksa aku untuk tetap seperti koloni\nLiar, brutal\nAku pendosa\nMengemis, dalam iba yang dipandang sebelah mata\nTakut, kecil tidak berarti\nMengais ampunan dalam sisa yang begitu memuakkan\nAku pendosa\nMenitikkan air mata mutiara dalam kalut hati penuh emosi',
            'Hakim Maha Adil\n\nUntuk siapa semua kerja dan susah payah\nKabarnya ada ganjaran berupa surga dan neraka\nHingga lelah tidak lagi dapat dirasa, hingga sakit tidak lagi bisa mempengaruhi\nMereka bermaksud apa dengan kerja keras dan susah payah\nKatanya ada segunung harta yang menjadi perebutan semua manusia\nUntuk apa bumi sibuk tiada henti\nKami memiliki peta hidup sendiri-sendiri\nTentang pahala dan dosa, kami tidak peduli\nHidup menjadi baik agar hidupmu baik\nYang maha adil melihat dari langit yang begitu tinggi',
            'Esok Hari\n\nBilakah kau bertanya esok seperti apa dunia?\nIa yang lelah, ia yang terlalu banyak menjadi saksi\nDunia yang bosan, manusia terus mengucapkan kemunafikan\nTiang renta terus tergeruk oleh serakahnya\nBila bumi dihancurkan, kami telah membaca\nGunung dan kapas berterbangan\nKandungan yang gugur, kami menjadi lupa diri karena ngeri\nAmpunan telah tertutup, hanya penyesalan yang membuat kita sama\nBila lah mana matahari lupa akan garis edarnya\nKata ampun sudah tidak lagi bermakna',
            'Dalam Bumi Gelap\n\nTersihir, semua tertunduk karena malu\nSesaat, untuk kemudian kembali terjaga dan bertelanjang\nMenari, mengucapkan mantra-mantra\nTerselubung, gelap beratap sinar dari api abadi\nPantas saja Tuhan menjadi murka\nDalam bumi gelap,suara tangis tidak menjadi satu-satunya bunyi\nDuka bukan pula satu-satunya rasa\nDalam bumi yang gelap\nManusia menjadi Tuhan untuk diri mereka sendiri',
            'Tentang Mereka\n\nAlkisah tentang mereka yang tidak lagi mengerti, ngeri menjadi di kala ambisi terus di isi\nDengan lahapan api, dengan mesin pemberani\nSeperti tuli telinga yang dibawa sepanjang hari\nBisik angker tidak memundurkan tekat\nRupiah menjadi sesembahan tuhan manusia yang sama\nTentang mereka dengan hati tak lagi peduli\nJiwa malang menjadi bergelimpangan mengakhiri suratan\nTertahan air mata akan mereka tumpahkan pada yang memberikan mereka hidup\nSesaat setelah iblis itu pergi',
            'Dalam Takjub\n\nAku tidak melihat yang sama\nKe pada ke dua permata yang bersinar sebagai pertanda\nTidak, aku tidak tertarik kepadanya\nHanya dua buah permata sama rupa\nKagum ku tidak terpaku pada bagian itu\nMenyeluruh, lebih mengena\nTidak hanya pada dua bola mata\nNamun,menilik sampai jauh pada hatinya',
            ]                
            let puisi2 = puisi[Math.floor(Math.random() * puisi.length)]
            await client.reply(from, puisi2, id)
            break
        case '.kuis':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const kuis = await get.get('https://api.vhtear.com/family100&apikey=bot').json()
            await client.reply(from, `${kuis.result.soal}\n\nJawaban : ${kuis.result.jawaban}`, id)
            break
        case '.kuis2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const kuis2 = await get.get('https://api.vhtear.com/funkuis&apikey=bot').json()
            await client.reply(from, `${kuis2.result.soal}\n\n${kuis2.result.desk}`, id)
            break
        case '.tebakgambar':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const tebakgambar = await get.get('https://api.vhtear.com/tebakgambar&apikey=bot').json()
            await client.sendFileFromUrl(from, tebakgambar.result.soalImg, 'tebakgambar.jpg', tebakgambar.result.jawaban, id)
            break

        case '.meme':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const meme = await get.get('https://meme-api.herokuapp.com/gimme/memes').json()
            await client.sendFileFromUrl(from, meme.url, 'meme.jpg', meme.title, id)
            break
        case '.mememaker':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.mememaker* _template/teks atas/teks bawah_\nContoh : *.mememaker* _doge/WAH BOTNYA/MEME SEKALI!_\nNote : ketik *.template* untuk melihat template meme!', id)
            client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, 'https://api.memegen.link/images/'+args[1]+'.png', id)
            break
        case '.memecustom':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            arg = body.trim().split('|')
            if (arg.length >= 4) {
                client.reply(from, mess.wait, id)
                const memecustom = arg[1]
                const memecustom2 = arg[2]
                const memecustom3 = arg[3]
                await client.sendFileFromUrl(from, 'https://api.memegen.link/images/custom/'+memecustom+'/'+memecustom2+'.png?background='+memecustom3, id)
            } else {
                await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.memecustom* _|teks atas|teks bawah|link gambar_\nContoh : *.memecustom* |MANA BOTNYA NYING, UPDATE TEROS|MASUKKAN SKRG JUGA!|https://i.imgflip.com/41e671.png', id)
            }
            break
        case '.template':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, template, id)
            break     
        case '.1cak':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const cak = await get.get('https://api.vhtear.com/googleimg?query=meme%201cak&apikey=bot').json()
            let cak2 = cak.result.result_search[Math.floor(Math.random() * cak.result.result_search.length)]
            await client.sendFileFromUrl(from, cak2, '1cak.jpg', `1CAK :: For Fun Only!`, id)
            break
        case '.1cak2': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const cak3 = ['1', '2']
            const cak4 = ['0', '1', '2', '3', '4', '5', '6', '7', '8'] 
            const cak5 = ['0', '1', '2', '3', '4', '5', '6']
            const cak6 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const cak7 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const cak8 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']           
            let cak9 = cak3[Math.floor(Math.random() * cak3.length)]
            let cak10 = cak4[Math.floor(Math.random() * cak4.length)]
            let cakq11 = cak5[Math.floor(Math.random() * cak5.length)]
            let cakq12 = cak6[Math.floor(Math.random() * cak6.length)]
            let cakq13 = cak7[Math.floor(Math.random() * cak7.length)]
            let cakq14 = cak8[Math.floor(Math.random() * cak8.length)]
            await client.sendLinkWithAutoPreview(from, `https://1cak.com/${cak9}${cak10}${cakq11}${cakq12}${cakq13}${cakq14}`, ``)
            break
        case '.9gag':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const gag = await get.get('https://api.vhtear.com/googleimg?query=meme%209gag&apikey=bot').json()
            let gag2 = gag.result.result_search[Math.floor(Math.random() * gag.result.result_search.length)]
            await client.sendFileFromUrl(from, gag2, '9gag.jpg', ``, id)
            break
        case '.reddit': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args[1].includes('memek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('rape')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bukake')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tante')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('girang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tempik')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('softcore')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hardcore')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gangbang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bondage')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('montok')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bohai')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bohay')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('eue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngeue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('breast')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('naked')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('blowjob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sex')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nude')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bra')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('boobs')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('boob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tit')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tits')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngewe')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('incest')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pornstar')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('porn')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('porno')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('puting')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nipples')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nipple')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pussy')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('vagina')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fetish')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('clirotis')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cliroti')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('clit')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jembut')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('peju')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('creampie')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gapping')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('venti')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cock')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('penis')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kontol')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bbc')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bbw')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tetek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nenen')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bh')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('beha')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('payudara')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('toket')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('toge')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('psk')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('lonte')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pelacur')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sperma')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('mani')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('coli')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('coly')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fap')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('masturbation')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('masturbasi')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('onani')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngocok')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('colmek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('doggy style')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('lewd')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hentai')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('doujin')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngeue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngentot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngentod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fuck')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jilmek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sepong')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jilbob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cosplay')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('milf')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('crot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('mesum')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bikini')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('onlyfans')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nsfw')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ass')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pantat')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('anus')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('anal')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('thic')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('thicc')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bokep')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kentot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kentod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('entod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hole')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('glory')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.reddit* _subreddit_\nContoh : *.reddit* _anime_')
            const reddit = await get.get('https://meme-api.herokuapp.com/gimme/'+args[1]).json()
            await client.sendFileFromUrl(from, reddit.url, 'meme.jpg', reddit.title, id)
            break
        case '.funny': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const funny = await get.get('https://meme-api.herokuapp.com/gimme/funny').json()
            await client.sendFileFromUrl(from, funny.url, 'funny.jpg', funny.title, id)
            break
        case '.cringe': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const cringe = await get.get('https://meme-api.herokuapp.com/gimme/cringepics').json()
            await client.sendFileFromUrl(from, cringe.url, 'cringe.jpg', cringe.title, id)
            break
        case '.perfect': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const perfect = await get.get('https://meme-api.herokuapp.com/gimme/PerfectTiming').json()
            await client.sendFileFromUrl(from, perfect.url, 'perfect.jpg', perfect.title, id)
            break
        case '.crap': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const crap = await get.get('https://meme-api.herokuapp.com/gimme/CrappyDesign').json()
            await client.sendFileFromUrl(from, crap.url, 'crap.jpg', crap.title, id)
            break
        case '.cursed':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const cursed = await get.get('https://meme-api.herokuapp.com/gimme/cursedimages').json()
            await client.sendFileFromUrl(from, cursed.url, 'cursed.jpg', cursed.title, id)
            break
        case '.creepy':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const creepy = await get.get('https://meme-api.herokuapp.com/gimme/creepy').json()
            await client.sendFileFromUrl(from, creepy.url, 'creepy.jpg', creepy.title, id)
            break
        case '.wtf':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const wtf = await get.get('https://meme-api.herokuapp.com/gimme/WTF').json()
            await client.sendFileFromUrl(from, wtf.url, 'wtf.jpg', wtf.title, id)
            break
        case '.dankmeme': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const dankmeme = await get.get('https://meme-api.herokuapp.com/gimme/dankmemes').json()
            await client.sendFileFromUrl(from, dankmeme.url, 'dankmeme.jpg', dankmeme.title, id)
            break
        case '.animeme':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const animeme = await get.get('https://meme-api.herokuapp.com/gimme/animemes').json()
            await client.sendFileFromUrl(from, animeme.url, 'animeme.jpg', animeme.title, id)
            break
        case '.jojoke':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const jojoke = ['UnexpectedJoJo', 'ShitPostCrusaders', 'jojokes']
            let jojoke2 = jojoke[Math.floor(Math.random() * jojoke.length)]
            const jojoke3 = await get.get('https://meme-api.herokuapp.com/gimme/'+jojoke2).json()
            await client.sendFileFromUrl(from, jojoke3.url, 'jojoke.jpg', jojoke3.title, id)
            break
        case '.indomeme':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const indomeme = await get.get('https://meme-api.herokuapp.com/gimme/indonesia').json()
            await client.sendFileFromUrl(from, indomeme.url, 'indomeme.jpg', indomeme.title, id)
            break
        case '.halal': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const halal = await get.get('https://meme-api.herokuapp.com/gimme/Izlam').json()
            await lient.sendFileFromUrl(from, halal.url, 'halal.jpg', halal.title, id)
            break
        case '.it': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const it = await get.get('https://meme-api.herokuapp.com/gimme/ProgrammerHumor').json()
            await client.sendFileFromUrl(from, it.url, 'it.jpg', it.title, id)
            break
        case '.pornhub': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const pornhub = await get.get('https://meme-api.herokuapp.com/gimme/PornhubComments').json()
            await client.sendFileFromUrl(from, pornhub.url, 'pornhub.jpg', pornhub.title, id)
            break
        case '.woooosh': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const woooosh = await get.get('https://meme-api.herokuapp.com/gimme/woooosh').json()
            await client.sendFileFromUrl(from, woooosh.url, 'woooosh.jpg', woooosh.title, id)
            break
        case '.davie504':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const davie504 = await get.get('https://meme-api.herokuapp.com/gimme/davie504').json()
            await client.sendFileFromUrl(from, davie504.url, 'davie504.jpg', davie504.url, id)
            break
        case '.milos':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const milos = await get.get('https://meme-api.herokuapp.com/gimme/RicardoMilosMemes').json()
            await client.sendFileFromUrl(from, milos.url, 'milos.jpg', milos.title, id)
            break
        case '.react':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const react = await get.get('https://meme-api.herokuapp.com/gimme/reactiongifs').json()
            await client.sendFileFromUrl(from, react.url, 'react.jpg', react.title, id)
            break
        case '.art': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const art = await get.get('https://meme-api.herokuapp.com/gimme/Art').json()
            await client.sendFileFromUrl(from, art.url, 'art.jpg', art.title, id)
            break
        case '.girl': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const girl = ['PrettyGirls', 'cutegirlgifs', 'Celebs', 'IRLgirls', 'realasians', 'Tight_Dress']
            let girl2 = girl[Math.floor(Math.random() * girl.length)]
            const girl3 = await get.get('https://meme-api.herokuapp.com/gimme/'+girl2).json()
            await client.sendFileFromUrl(from, girl3.url, 'girl.jpg', girl3.title, id)
            break
        case '.boy': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const boy = await get.get('https://meme-api.herokuapp.com/gimme/LadyBoners').json()
            await client.sendFileFromUrl(from, boy.url, 'boy.jpg', boy.title, id)
            break
        case '.roll':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const dice = Math.floor(Math.random() * 6) + 1
            await client.sendStickerfromUrl(from, 'https://www.random.org/dice/dice'+dice+'.png')
            break
        case '.flip':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const side = Math.floor(Math.random() * 2) + 1
            if (side == 1) {
                await client.sendStickerfromUrl(from, 'https://3.bp.blogspot.com/-vrPjlUouSro/Uxn_KAU67VI/AAAAAAAAA28/35_EB8P_Lpw/s1600/1000+DPN+ANGKLUNG.jpg')
            } else {
                await client.sendStickerfromUrl(from, 'https://2.bp.blogspot.com/-NfLsQ977f30/Uxn_KCVSPNI/AAAAAAAAA3E/IBNVzuxexbs/s1600/1000+BLK+ANGKLUNG.jpg')
            }
            break
        case '.kiss':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.kiss* _@user_\nContoh : *.kiss* _@pahrul_')
            arg = body.trim().split(' ')
            const person = author.replace('@c.us', '')
            await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/g65lsKd2n5gTC/giphy.gif')
            await client.sendTextWithMentions(from, '@'+person+' kissed '+arg[1])
            break
        case '.slap':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.slap* _@user_\nContoh : *.slap* _@jokowi_')
            arg = body.trim().split(' ')
            const person2 = author.replace('@c.us', '')
            await client.sendGiphyAsSticker(from, 'https://media.giphy.com/media/3XlEk2RxPS1m8/giphy.gif')
            await client.sendTextWithMentions(from, '@'+person2+' slapped '+arg[1])
            break

        case '.anime':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.anime* _judul_\nContoh : *.anime* _boruto_', id)
            const anime = await get.get('https://mhankbarbar.herokuapp.com/api/kuso?q='+body.slice(7)+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (anime.error) return client.reply(from, mess.null, id)
            await client.sendFileFromUrl(from, anime.thumb, 'anime.jpg', `Title : ${anime.title}\n${anime.info}\n\n${anime.link_dl}Synopsis : ${anime.sinopsis}`, id)
            break
        case '.anime2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.anime* _judul_\nContoh : *.anime* _boruto_', id)
            const anime2 = await get.get('https://api.jikan.moe/v3/search/anime?q='+body.slice(8)).json()
            if (anime2.error) return client.reply(from, mess.null, id)
            await client.sendFileFromUrl(from, anime2.results[0].image_url, 'anime2.jpg', `Title : ${anime2.results[0].title}\nEpisodes : ${anime2.results[0].episodes}\nRating : ${anime2.results[0].rated}\nScore : ${anime2.results[0].score}\nSynopsis : ${anime2.results[0].synopsis} ${anime2.results[0].url}`, id)
            break
        case '.manga':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.anime* _judul_\nContoh : *.anime* _boruto_', id)
            const manga = await get.get('https://mhankbarbar.herokuapp.com/api/komiku?q='+body.slice(7)+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (manga.error) return client.reply(from, mess.null, id)
            await client.sendFileFromUrl(from, manga.thumb, 'manga.jpg', `${manga.info}${manga.genre}\n\nSynopsis : ${manga.sinopsis}\n\n${manga.link_dl}`, id)
            break
        case '.manga2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.manga* _judul_\nContoh : *.manga* _boruto_', id)
            const manga2 = await get.get('https://api.jikan.moe/v3/search/manga?q='+body.slice(8)).json()
            if (manga2.error) return client.reply(from, mess.null, id)
            await client.sendFileFromUrl(from, manga2.results[0].image_url, 'manga2.jpg', `Title : ${manga2.results[0].title}\nChapters : ${manga2.results[0].chapters}\nVolumes : ${manga2.results[0].volumes}\nScore : ${manga2.results[0].score}\nSynopsis : ${manga2.results[0].synopsis} ${manga2.results[0].url}`, id)
            break
        case '.top':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const top = await get.get('https://api.jikan.moe/v3/top/anime/1').json()
            if (top.error) return client.reply(from, mess.null, id)
            const top2 = `${top.top[0].rank}. ${top.top[0].title}\nEpisodes : ${top.top[0].episodes}\nScore : ${top.top[0].score}\n${top.top[0].url}`
            const top3 = `${top.top[1].rank}. ${top.top[1].title}\nEpisodes : ${top.top[1].episodes}\nScore : ${top.top[1].score}\n${top.top[1].url}`
            const top4 = `${top.top[2].rank}. ${top.top[2].title}\nEpisodes : ${top.top[2].episodes}\nScore : ${top.top[2].score}\n${top.top[2].url}`
            const top5 = `${top.top[3].rank}. ${top.top[3].title}\nEpisodes : ${top.top[3].episodes}\nScore : ${top.top[3].score}\n${top.top[3].url}`
            const top6 = `${top.top[4].rank}. ${top.top[4].title}\nEpisodes : ${top.top[4].episodes}\nScore : ${top.top[4].score}\n${top.top[4].url}`
            const top7 = `${top.top[5].rank}. ${top.top[5].title}\nEpisodes : ${top.top[5].episodes}\nScore : ${top.top[5].score}\n${top.top[5].url}`
            const top8 = `${top.top[6].rank}. ${top.top[6].title}\nEpisodes : ${top.top[6].episodes}\nScore : ${top.top[6].score}\n${top.top[6].url}`
            const top9 = `${top.top[7].rank}. ${top.top[7].title}\nEpisodes : ${top.top[7].episodes}\nScore : ${top.top[7].score}\n${top.top[7].url}`
            const top10 = `${top.top[8].rank}. ${top.top[8].title}\nEpisodes : ${top.top[8].episodes}\nScore : ${top.top[8].score}\n${top.top[8].url}`
            const top11 = `${top.top[9].rank}. ${top.top[9].title}\nEpisodes : ${top.top[9].episodes}\nScore : ${top.top[9].score}\n${top.top[9].url}`
            await client.reply(from, `${top2}\n\n${top3}\n\n${top4}\n\n${top5}\n\n${top6}\n\n${top7}\n\n${top8}\n\n${top9}\n\n${top10}\n\n${top11}`, id)
            break
        case '.upcoming':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const upcoming = await get.get('https://api.jikan.moe/v3/top/anime/1/upcoming').json()
            if (upcoming.error) return client.reply(from, mess.null, id)
            const upcoming2 = `${upcoming.top[0].rank}. ${upcoming.top[0].title}\nDate : ${upcoming.top[0].start_date}\n${upcoming.top[0].url}`
            const upcoming3 = `${upcoming.top[1].rank}. ${upcoming.top[1].title}\nDate : ${upcoming.top[1].start_date}\n${upcoming.top[1].url}`
            const upcoming4 = `${upcoming.top[2].rank}. ${upcoming.top[2].title}\nDate : ${upcoming.top[2].start_date}\n${upcoming.top[2].url}`
            const upcoming5 = `${upcoming.top[3].rank}. ${upcoming.top[3].title}\nDate : ${upcoming.top[3].start_date}\n${upcoming.top[3].url}`
            const upcoming6 = `${upcoming.top[4].rank}. ${upcoming.top[4].title}\nDate : ${upcoming.top[4].start_date}\n${upcoming.top[4].url}`
            const upcoming7 = `${upcoming.top[5].rank}. ${upcoming.top[5].title}\nDate : ${upcoming.top[5].start_date}\n${upcoming.top[5].url}`
            const upcoming8 = `${upcoming.top[6].rank}. ${upcoming.top[6].title}\nDate : ${upcoming.top[6].start_date}\n${upcoming.top[6].url}`
            const upcoming9 = `${upcoming.top[7].rank}. ${upcoming.top[7].title}\nDate : ${upcoming.top[7].start_date}\n${upcoming.top[7].url}`
            const upcoming10 = `${upcoming.top[8].rank}. ${upcoming.top[8].title}\nDate : ${upcoming.top[8].start_date}\n${upcoming.top[8].url}`
            const upcoming11 = `${upcoming.top[9].rank}. ${upcoming.top[9].title}\nDate : ${upcoming.top[9].start_date}\n${upcoming.top[9].url}`
            await client.reply(from, `${upcoming2}\n\n${upcoming3}\n\n${upcoming4}\n\n${upcoming5}\n\n${upcoming6}\n\n${upcoming7}\n\n${upcoming8}\n\n${upcoming9}\n\n${upcoming10}\n\n${upcoming11}`, id)
            break
        case '.jurnalotaku':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.jurnalotaku* _kata kunci_\nContoh : *.jurnalotaku* _boruto_', id)
            const jurnalotaku = await get.get('https://api.i-tech.id/anim/otaku?key=JDPQSX-rz6Wf0-DgfTRY-SXsBB8-oX1ZMU&type=search&query='+body.slice(13)).json()
            if (jurnalotaku.error) return client.reply(from, mess.null, id)
            await client.reply(from, `Title : ${jurnalotaku.result[0].title}\n${jurnalotaku.result[0].link}\n\nTitle : ${jurnalotaku.result[1].title}\n${jurnalotaku.result[1].link}\n\nTitle : ${jurnalotaku.result[2].title}\n${jurnalotaku.result[2].link}\n\nTitle : ${jurnalotaku.result[3].title}\n${jurnalotaku.result[3].link}\n\nTitle : ${jurnalotaku.result[4].title}\n${jurnalotaku.result[4].link}\n\nTitle : ${jurnalotaku.result[5].title}\n${jurnalotaku.result[5].link}\n\nTitle : ${jurnalotaku.result[6].title}\n${jurnalotaku.result[6].link}\n\nTitle : ${jurnalotaku.result[7].title}\n${jurnalotaku.result[7].link}\n\nTitle : ${jurnalotaku.result[8].title}\n${jurnalotaku.result[8].link}\n\nTitle : ${jurnalotaku.result[9].title}\n${jurnalotaku.result[9].link}`, id)
            break
        case '.sauce':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (isMedia && type === 'image' || quotedMsg && quotedMsg.type === 'image') {
                if (isMedia) {
                    var mediaData = await decryptMedia(message, uaOverride)
                } else {
                    var mediaData = await decryptMedia(quotedMsg, uaOverride)
                }
                const fetch = require('node-fetch')
                const imgBS4 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                client.reply(from, mess.wait, id)
                fetch('https://trace.moe/api/search', {
                    method: 'POST',
                    body: JSON.stringify({ image: imgBS4 }),
                    headers: { "Content-Type": "application/json" }
                })
                .then(respon => respon.json())
                .then(resolt => {
                    if (resolt.docs && resolt.docs.length <= 0) {
                        client.reply(from, 'Saya tidak tau senpai 😭', id)
                    }
                    const { is_adult, title, title_chinese, title_romaji, title_english, episode, similarity, filename, at, tokenthumb, anilist_id } = resolt.docs[0]
                    teks = ''
                    if (similarity < 0.92) {
                        teks = 'Saya kurang yakin senpai 🥺\n\n'
                    }
                    teks += `Title Japanese : ${title}\nTitle Chinese : ${title_chinese}\nTitle Romaji : ${title_romaji}\nTitle English : ${title_english}\n`
                    teks += `Ecchi : ${is_adult}\n`
                    teks += `Episode : ${episode.toString()}\n`
                    teks += `Kesamaan : ${(similarity * 100).toFixed(1)}%\n`
                    var video = `https://media.trace.moe/video/${anilist_id}/${encodeURIComponent(filename)}?t=${at}&token=${tokenthumb}`;
                    client.sendFileFromUrl(from, video, 'sauce.mp4', teks, id).catch(() => {
                        client.reply(from, teks, id)
                    })
                })
                .catch(() => {
                    client.reply(from, mess.null, id)
                })
            } else {
                client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.sauce* _[upload gambar]_', id)
            }
            break
        case '.waifu': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const waifu = await get.get('https://api.computerfreaker.cf/v1/anime').json()
            await client.sendFileFromUrl(from, waifu.url, 'waifu2.jpg', `Waifu!`, id)
            break
        case '.husbu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const husbu = await get.get('').json()
            await client.sendFileFromUrl(from, husbu.image, 'husbu.jpg', `Husbu!`, id)
            break
        case '.loli':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const loli = await get.get('https://mhankbarbar.herokuapp.com/api/randomloli').json()
            await client.sendFileFromUrl(from, loli.result, 'loli.jpeg.', 'Lolinya om!', id)
            break
        case '.shota': //50
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const shota = ["https://dthezntil550i.cloudfront.net/01/latest/011701071212505690002062152/1280_960/07b38755-5195-47b6-8f61-4bf34f4886ac.png", "https://img.pawoo.net/media_attachments/files/015/199/224/original/71aa529c92fa1124.jpeg", "https://img.pawoo.net/accounts/headers/000/504/773/original/4aa25f5eb49ddd1d.jpeg", "https://data.whicdn.com/images/155031469/original.jpg", "https://i.pinimg.com/564x/1f/b7/45/1fb7452cdf553e517240f534da5c29f8.jpg", "https://img.pawoo.net/media_attachments/files/029/937/815/original/1b4c2e3b8c3fbc7a.jpeg", "https://pbs.twimg.com/media/Ef19ga9XsAA3sIU.jpg", "https://pbs.twimg.com/media/D61zlGeXsAAwESo.jpg", "https://pbs.twimg.com/media/ERCVdHVWoAApscE.jpg", "https://pbs.twimg.com/media/D52DlkMXsAESgql.jpg", "https://pbs.twimg.com/media/D52DlkQWwAUi84D.jpg:large", "https://pbs.twimg.com/media/D52DlkNWkAAn43A.jpg", "https://lh3.googleusercontent.com/proxy/_CZ5S3QypJyit2K6iDanAftGMv4ajiUPIJQ-1BxWJwlSZxc_54uu8lXki8ljy491gCwHlMmq0gfrmzv2tw", "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/7e60cfec-aa10-4808-8deb-a58347a645c3/dc2lrn4-06a8f732-f723-4908-bc65-810720eae8ec.png/v1/fill/w_600,h_734,q_80,strp/pat_your_king_arthur_by_dumplingyumyum_dc2lrn4-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOiIsImlzcyI6InVybjphcHA6Iiwib2JqIjpbW3siaGVpZ2h0IjoiPD03MzQiLCJwYXRoIjoiXC9mXC83ZTYwY2ZlYy1hYTEwLTQ4MDgtOGRlYi1hNTgzNDdhNjQ1YzNcL2RjMmxybjQtMDZhOGY3MzItZjcyMy00OTA4LWJjNjUtODEwNzIwZWFlOGVjLnBuZyIsIndpZHRoIjoiPD02MDAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.Laq-lKRC_8_HskCSYiewYza9Fh1wqtMDgyu9oben1cw", "https://img-9gag-fun.9cache.com/photo/a5o6dng_460s.jpg", "https://img-9gag-fun.9cache.com/photo/aAx6VE9_460s.jpg", "https://img-9gag-fun.9cache.com/photo/aDx7ewK_460s.jpg", "https://img-9gag-fun.9cache.com/photo/a7MOLZx_460s.jpg", "https://pbs.twimg.com/media/C-vW4hIVYAAqRbC.jpg", "https://dthezntil550i.cloudfront.net/sw/latest/sw1703040819041350002062152/1280_960/e8c42cfa-257b-4533-811a-d3efec3c1ba6.png", "https://img-9gag-fun.9cache.com/photo/a7MNm0e_460s.jpg", "https://img-9gag-fun.9cache.com/photo/aq7XrdQ_460s.jpg", "https://static.zerochan.net/Seragaki.Aoba.full.1841085.jpg", "https://i.pinimg.com/originals/97/7e/1f/977e1f929f3ab224aa1d9c282747531d.jpg", "https://i.pinimg.com/originals/ef/21/ba/ef21baa0901a993cb4aaf54d5224a10f.jpg", "https://pm1.narvii.com/5756/859bf4feedbb35b6d5f1eb07bb6be7b33a5361ab_hq.jpg", "https://i.pinimg.com/236x/d0/1f/f3/d01ff36ba1ed7d37dcdacb37737194a7--sibling-dramatical-murder.jpg", "https://static.zerochan.net/DRAMAtical.Murder.full.1801079.jpg", "https://i.pinimg.com/originals/64/b1/b0/64b1b094a5838a9d027d5c015d683f9d.png", "https://a.wattpad.com/cover/40430138-352-k280292.jpg", "https://i.pinimg.com/originals/68/9b/23/689b23f079451b2a2b8b12e61c72352d.jpg", "https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1551638317l/44195036._SX318_.jpg", "https://lh3.googleusercontent.com/proxy/gwIOTOYftti3a_6uDMZP1btauqBQzAN40Fl099PFQBFvydxq37wd-X6LHo7013yoz9-TYjLRSLPxuA2EdnVWo0aVb89rAdxgKb35tZR_ICj0Lw39VQ", "https://pbs.twimg.com/media/DPJJ6ZHUEAEur7G.jpg", "https://images-cdn.9gag.com/photo/ayx939y_700b.jpg", "https://pbs.twimg.com/media/DKNBWb_VYAAP-FA.jpg", "https://static.zerochan.net/Shion.%28No.6%29.full.1020725.jpg", "https://i.pinimg.com/originals/cf/5e/5a/cf5e5af670cb6bbcd72c60702da7aaf7.png", "https://i.pinimg.com/originals/fc/a8/10/fca810312e7517f0137f6fcafe53870e.jpg", "https://i.pinimg.com/originals/b1/83/f2/b183f2016540922adb3d7ec4ec3f5928.jpg", "https://mangadex.org/images/manga/52712.png?1597184718", "https://i.pinimg.com/originals/bd/f5/9e/bdf59e6b83a444fbaa160ba151215dbd.jpg", "https://pbs.twimg.com/profile_images/1148226136272322561/IxRKk-j2.jpg", "https://mangadex.org/images/manga/35826.jpg?1598199766", "https://data.whicdn.com/images/168765624/original.jpg", "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/bc03b99f-ec18-4749-9d18-d0a703590efc/dcdol4q-9fd8d4b5-4258-4fe7-a209-c945eb607661.png/v1/fill/w_1600,h_1600,q_80,strp/some_shota_boi_by_dandisenpai334_dcdol4q-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOiIsImlzcyI6InVybjphcHA6Iiwib2JqIjpbW3siaGVpZ2h0IjoiPD0xNjAwIiwicGF0aCI6IlwvZlwvYmMwM2I5OWYtZWMxOC00NzQ5LTlkMTgtZDBhNzAzNTkwZWZjXC9kY2RvbDRxLTlmZDhkNGI1LTQyNTgtNGZlNy1hMjA5LWM5NDVlYjYwNzY2MS5wbmciLCJ3aWR0aCI6Ijw9MTYwMCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.idmjSpCvG7UOIm4JgO6fl24QmU8mM-LoZPYKYkOR86A", "https://img.fireden.net/cm/image/1564/29/1564294244585.jpg", "https://cdn.sketchmob.com/uploads/2020/07/316298_4f681788e-720x960.jpg", "https://i.kym-cdn.com/photos/images/newsfeed/000/916/858/d7f.jpg", "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/a66b30c1-d95d-46bf-b536-e8ddf3880934/dd0hzb4-c9905f82-d97c-47a0-9d28-837226158d45.png/v1/fill/w_600,h_600,q_80,strp/shota_boy_maker_ver_beta_by_kairita0704_dd0hzb4-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOiIsImlzcyI6InVybjphcHA6Iiwib2JqIjpbW3siaGVpZ2h0IjoiPD02MDAiLCJwYXRoIjoiXC9mXC9hNjZiMzBjMS1kOTVkLTQ2YmYtYjUzNi1lOGRkZjM4ODA5MzRcL2RkMGh6YjQtYzk5MDVmODItZDk3Yy00N2EwLTlkMjgtODM3MjI2MTU4ZDQ1LnBuZyIsIndpZHRoIjoiPD02MDAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.UDuZIb-o5FzkCKAooMM3izZFgULmsiT7kSVXIdIgZAA"]
            let shota2 = shota[Math.floor(Math.random() * shota.length)]
            await client.sendFileFromUrl(from, shota2, 'shota.jpeg.', 'Tante-tante culik aku dong!', id)
            break 
        case '.neesan': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const neesan = await get.get('https://meme-api.herokuapp.com/gimme/oneesan').json()
            await client.sendFileFromUrl(from, neesan.url, 'neesan.jpg', neesan.title, id)
            break
        case '.yuri': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const yuri = await get.get('https://api.computerfreaker.cf/v1/yuri').json()
            await client.sendFileFromUrl(from, yuri.url, 'yuri.jpg', `Lesbeh!`, id)
            break
        case '.yaoi': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const yaoi = await get.get('https://meme-api.herokuapp.com/gimme/Yaoi_IRL').json()
            await client.sendFileFromUrl(from, yaoi.url, 'yaoi.jpg', yaoi.title, id)
            break 
        case '.neko': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const neko = await get.get('https://api.computerfreaker.cf/v1/neko').json()
            await client.sendFileFromUrl(from, neko.url, 'neko.jpg', `Nyan Nyan`, id)
            break
        case '.furry': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const furry = await get.get('https://meme-api.herokuapp.com/gimme/furry').json()
            await client.sendFileFromUrl(from, furry.url, 'furry.jpg', furry.title, id)
            break 
        case '.hug': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const hug = await get.get('https://api.computerfreaker.cf/v1/hug').json()
            await client.sendFileFromUrl(from, hug.url, 'hug.jpg', `Peyuk!`, id)
            break
        case '.baguette': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const baguette = await get.get('https://api.computerfreaker.cf/v1/baguette').json()
            await client.sendFileFromUrl(from, baguette.url, 'baguette.jpg', `Rotinya senpai!`, id)
            break
        case '.dva': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const dva = await get.get('https://api.computerfreaker.cf/v1/dva').json()
            await client.sendFileFromUrl(from, dva.url, 'meme.jpg', `D.VA`, id)
            break
        case '.pokemon':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            pokemon = Math.floor(Math.random() * 890) + 1;
            await client.sendFileFromUrl(from, 'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+pokemon+'.png','Pokemon.png', `Pokemon-pokemon dimana kamu!`, id)
            break
        case '.stand': //3-5
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const stand = fs.readFileSync('./lib/stand.json')
            const stand2 = JSON.parse(stand)
            const stand3 = Math.floor(Math.random() * stand2.length)
            const stand4 = stand2[stand3]
            await client.sendFileFromUrl(from, stand4.image, 'stand.jpg', stand4.teks, id)
            break
        case '.hololive': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const hololive = await get.get('https://meme-api.herokuapp.com/gimme/Hololive').json()
            await client.sendFileFromUrl(from, hololive.url, 'hololive.jpg', hololive.title, id)
            break
        case '.helltaker': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const helltaker = await get.get('https://meme-api.herokuapp.com/gimme/Helltaker').json()
            await client.sendFileFromUrl(from, helltaker.url, 'helltaker.jpg', helltaker.title, id)
            break
        case '.wp': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const wp = await get.get('https://meme-api.herokuapp.com/gimme/wallpaper').json()
            await client.sendFileFromUrl(from, wp.url, 'wp.jpg', wp.title, id)
            break
        case '.wpnime' :
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const wpnime = await get.get('https://meme-api.herokuapp.com/gimme/Animewallpaper').json()
            await client.sendFileFromUrl(from, wpnime.url, 'wpnime.jpg', wpnime.title, id)
            break
        case '.cat':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const cat = await get.get('https://aws.random.cat/meow?ref=cat').json()
            await client.sendFileFromUrl(from, cat.file, 'cat.jpg', 'Neko!', id)
            break
        case '.kitten':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            kitten = Math.floor(Math.random() * 900) + 300;
            kitten2 = Math.floor(Math.random() * 900) + 300;
            await client.sendFileFromUrl(from, 'http://placekitten.com/'+kitten+'/'+kitten2, 'kitten.png','Neko!', id)
            break
        case '.dog':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const dog = await get.get('https://random.dog/woof.json?ref=').json()
            await client.sendFileFromUrl(from, dog.url, 'dog.jpg', 'Inu!', id)
            break
        case '.shibe':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const shibe = ["https://cdn.shibe.online/shibes/247d0ac978c9de9d9b66d72dbdc65f2dac64781d.jpg","https://cdn.shibe.online/shibes/1cf322acb7d74308995b04ea5eae7b520e0eae76.jpg","https://cdn.shibe.online/shibes/1ce955c3e49ae437dab68c09cf45297d68773adf.jpg","https://cdn.shibe.online/shibes/ec02bee661a797518d37098ab9ad0c02da0b05c3.jpg","https://cdn.shibe.online/shibes/1e6102253b51fbc116b887e3d3cde7b5c5083542.jpg","https://cdn.shibe.online/shibes/f0c07a7205d95577861eee382b4c8899ac620351.jpg","https://cdn.shibe.online/shibes/3eaf3b7427e2d375f09fc883f94fa8a6d4178a0a.jpg","https://cdn.shibe.online/shibes/c8b9fcfde23aee8d179c4c6f34d34fa41dfaffbf.jpg","https://cdn.shibe.online/shibes/55f298bc16017ed0aeae952031f0972b31c959cb.jpg","https://cdn.shibe.online/shibes/2d5dfe2b0170d5de6c8bc8a24b8ad72449fbf6f6.jpg","https://cdn.shibe.online/shibes/e9437de45e7cddd7d6c13299255e06f0f1d40918.jpg","https://cdn.shibe.online/shibes/6c32141a0d5d089971d99e51fd74207ff10751e7.jpg","https://cdn.shibe.online/shibes/028056c9f23ff40bc749a95cc7da7a4bb734e908.jpg","https://cdn.shibe.online/shibes/4fb0c8b74dbc7653e75ec1da597f0e7ac95fe788.jpg","https://cdn.shibe.online/shibes/125563d2ab4e520aaf27214483e765db9147dcb3.jpg","https://cdn.shibe.online/shibes/ea5258fad62cebe1fedcd8ec95776d6a9447698c.jpg","https://cdn.shibe.online/shibes/5ef2c83c2917e2f944910cb4a9a9b441d135f875.jpg","https://cdn.shibe.online/shibes/6d124364f02944300ae4f927b181733390edf64e.jpg","https://cdn.shibe.online/shibes/92213f0c406787acd4be252edb5e27c7e4f7a430.jpg","https://cdn.shibe.online/shibes/40fda0fd3d329be0d92dd7e436faa80db13c5017.jpg","https://cdn.shibe.online/shibes/e5c085fc427528fee7d4c3935ff4cd79af834a82.jpg","https://cdn.shibe.online/shibes/f83fa32c0da893163321b5cccab024172ddbade1.jpg","https://cdn.shibe.online/shibes/4aa2459b7f411919bf8df1991fa114e47b802957.jpg","https://cdn.shibe.online/shibes/2ef54e174f13e6aa21bb8be3c7aec2fdac6a442f.jpg","https://cdn.shibe.online/shibes/fa97547e670f23440608f333f8ec382a75ba5d94.jpg","https://cdn.shibe.online/shibes/fb1b7150ed8eb4ffa3b0e61ba47546dd6ee7d0dc.jpg","https://cdn.shibe.online/shibes/abf9fb41d914140a75d8bf8e05e4049e0a966c68.jpg","https://cdn.shibe.online/shibes/f63e3abe54c71cc0d0c567ebe8bce198589ae145.jpg","https://cdn.shibe.online/shibes/4c27b7b2395a5d051b00691cc4195ef286abf9e1.jpg","https://cdn.shibe.online/shibes/00df02e302eac0676bb03f41f4adf2b32418bac8.jpg","https://cdn.shibe.online/shibes/4deaac9baec39e8a93889a84257338ebb89eca50.jpg","https://cdn.shibe.online/shibes/199f8513d34901b0b20a33758e6ee2d768634ebb.jpg","https://cdn.shibe.online/shibes/f3efbf7a77e5797a72997869e8e2eaa9efcdceb5.jpg","https://cdn.shibe.online/shibes/39a20ccc9cdc17ea27f08643b019734453016e68.jpg","https://cdn.shibe.online/shibes/e67dea458b62cf3daa4b1e2b53a25405760af478.jpg","https://cdn.shibe.online/shibes/0a892f6554c18c8bcdab4ef7adec1387c76c6812.jpg","https://cdn.shibe.online/shibes/1b479987674c9b503f32e96e3a6aeca350a07ade.jpg","https://cdn.shibe.online/shibes/0c80fc00d82e09d593669d7cce9e273024ba7db9.jpg","https://cdn.shibe.online/shibes/bbc066183e87457b3143f71121fc9eebc40bf054.jpg","https://cdn.shibe.online/shibes/0932bf77f115057c7308ef70c3de1de7f8e7c646.jpg","https://cdn.shibe.online/shibes/9c87e6bb0f3dc938ce4c453eee176f24636440e0.jpg","https://cdn.shibe.online/shibes/0af1bcb0b13edf5e9b773e34e54dfceec8fa5849.jpg","https://cdn.shibe.online/shibes/32cf3f6eac4673d2e00f7360753c3f48ed53c650.jpg","https://cdn.shibe.online/shibes/af94d8eeb0f06a0fa06f090f404e3bbe86967949.jpg","https://cdn.shibe.online/shibes/4b55e826553b173c04c6f17aca8b0d2042d309fb.jpg","https://cdn.shibe.online/shibes/a0e53593393b6c724956f9abe0abb112f7506b7b.jpg","https://cdn.shibe.online/shibes/7eba25846f69b01ec04de1cae9fed4b45c203e87.jpg","https://cdn.shibe.online/shibes/fec6620d74bcb17b210e2cedca72547a332030d0.jpg","https://cdn.shibe.online/shibes/26cf6be03456a2609963d8fcf52cc3746fcb222c.jpg","https://cdn.shibe.online/shibes/c41b5da03ad74b08b7919afc6caf2dd345b3e591.jpg","https://cdn.shibe.online/shibes/7a9997f817ccdabac11d1f51fac563242658d654.jpg","https://cdn.shibe.online/shibes/7221241bad7da783c3c4d84cfedbeb21b9e4deea.jpg","https://cdn.shibe.online/shibes/283829584e6425421059c57d001c91b9dc86f33b.jpg","https://cdn.shibe.online/shibes/5145c9d3c3603c9e626585cce8cffdfcac081b31.jpg","https://cdn.shibe.online/shibes/b359c891e39994af83cf45738b28e499cb8ffe74.jpg","https://cdn.shibe.online/shibes/0b77f74a5d9afaa4b5094b28a6f3ee60efcb3874.jpg","https://cdn.shibe.online/shibes/adccfdf7d4d3332186c62ed8eb254a49b889c6f9.jpg","https://cdn.shibe.online/shibes/3aac69180f777512d5dabd33b09f531b7a845331.jpg","https://cdn.shibe.online/shibes/1d25e4f592db83039585fa480676687861498db8.jpg","https://cdn.shibe.online/shibes/d8349a2436420cf5a89a0010e91bf8dfbdd9d1cc.jpg","https://cdn.shibe.online/shibes/eb465ef1906dccd215e7a243b146c19e1af66c67.jpg","https://cdn.shibe.online/shibes/3d14e3c32863195869e7a8ba22229f457780008b.jpg","https://cdn.shibe.online/shibes/79cedc1a08302056f9819f39dcdf8eb4209551a3.jpg","https://cdn.shibe.online/shibes/4440aa827f88c04baa9c946f72fc688a34173581.jpg","https://cdn.shibe.online/shibes/94ea4a2d4b9cb852e9c1ff599f6a4acfa41a0c55.jpg","https://cdn.shibe.online/shibes/f4478196e441aef0ada61bbebe96ac9a573b2e5d.jpg","https://cdn.shibe.online/shibes/96d4db7c073526a35c626fc7518800586fd4ce67.jpg","https://cdn.shibe.online/shibes/196f3ed10ee98557328c7b5db98ac4a539224927.jpg","https://cdn.shibe.online/shibes/d12b07349029ca015d555849bcbd564d8b69fdbf.jpg","https://cdn.shibe.online/shibes/80fba84353000476400a9849da045611a590c79f.jpg","https://cdn.shibe.online/shibes/94cb90933e179375608c5c58b3d8658ef136ad3c.jpg","https://cdn.shibe.online/shibes/8447e67b5d622ef0593485316b0c87940a0ef435.jpg","https://cdn.shibe.online/shibes/c39a1d83ad44d2427fc8090298c1062d1d849f7e.jpg","https://cdn.shibe.online/shibes/6f38b9b5b8dbf187f6e3313d6e7583ec3b942472.jpg","https://cdn.shibe.online/shibes/81a2cbb9a91c6b1d55dcc702cd3f9cfd9a111cae.jpg","https://cdn.shibe.online/shibes/f1f6ed56c814bd939645138b8e195ff392dfd799.jpg","https://cdn.shibe.online/shibes/204a4c43cfad1cdc1b76cccb4b9a6dcb4a5246d8.jpg","https://cdn.shibe.online/shibes/9f34919b6154a88afc7d001c9d5f79b2e465806f.jpg","https://cdn.shibe.online/shibes/6f556a64a4885186331747c432c4ef4820620d14.jpg","https://cdn.shibe.online/shibes/bbd18ae7aaf976f745bc3dff46b49641313c26a9.jpg","https://cdn.shibe.online/shibes/6a2b286a28183267fca2200d7c677eba73b1217d.jpg","https://cdn.shibe.online/shibes/06767701966ed64fa7eff2d8d9e018e9f10487ee.jpg","https://cdn.shibe.online/shibes/7aafa4880b15b8f75d916b31485458b4a8d96815.jpg","https://cdn.shibe.online/shibes/b501169755bcf5c1eca874ab116a2802b6e51a2e.jpg","https://cdn.shibe.online/shibes/a8989bad101f35cf94213f17968c33c3031c16fc.jpg","https://cdn.shibe.online/shibes/f5d78feb3baa0835056f15ff9ced8e3c32bb07e8.jpg","https://cdn.shibe.online/shibes/75db0c76e86fbcf81d3946104c619a7950e62783.jpg","https://cdn.shibe.online/shibes/8ac387d1b252595bbd0723a1995f17405386b794.jpg","https://cdn.shibe.online/shibes/4379491ef4662faa178f791cc592b52653fb24b3.jpg","https://cdn.shibe.online/shibes/4caeee5f80add8c3db9990663a356e4eec12fc0a.jpg","https://cdn.shibe.online/shibes/99ef30ea8bb6064129da36e5673649e957cc76c0.jpg","https://cdn.shibe.online/shibes/aeac6a5b0a07a00fba0ba953af27734d2361fc10.jpg","https://cdn.shibe.online/shibes/9a217cfa377cc50dd8465d251731be05559b2142.jpg","https://cdn.shibe.online/shibes/65f6047d8e1d247af353532db018b08a928fd62a.jpg","https://cdn.shibe.online/shibes/fcead395cbf330b02978f9463ac125074ac87ab4.jpg","https://cdn.shibe.online/shibes/79451dc808a3a73f99c339f485c2bde833380af0.jpg","https://cdn.shibe.online/shibes/bedf90869797983017f764165a5d97a630b7054b.jpg","https://cdn.shibe.online/shibes/dd20e5801badd797513729a3645c502ae4629247.jpg","https://cdn.shibe.online/shibes/88361ee50b544cb1623cb259bcf07b9850183e65.jpg","https://cdn.shibe.online/shibes/0ebcfd98e8aa61c048968cb37f66a2b5d9d54d4b.jpg"]
            let shibe2 = shibe[Math.floor(Math.random() * shibe.length)]
            await client.sendFileFromUrl(from, shibe2, 'shibe.jpg', 'Inu!', id)
            break
        case '.fox':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const fox = await get.get('https://randomfox.ca/floof/').json()
            await client.sendFileFromUrl(from, fox.image, 'fox.jpeg.', 'Fox!', id)
            break
        case '.bird': //10
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const bird = ["https://cdn.shibe.online/birds/fd076a5ece27593d882384e4477eefeda3a9a0d2.jpg", "https://cdn.shibe.online/birds/c450000633380716766e85bd30f1056ad35de017.jpg", "https://cdn.shibe.online/birds/141e3b46439c3df3d169fe6f78e6e7bc15676e56.jpg", "https://cdn.shibe.online/birds/94249ab2957a1490214ce750de60302a45b015d6.jpg", "https://cdn.shibe.online/birds/fd2efb02b5b60aeabc4523388bc5fb72d6c4c050.jpg", "https://cdn.shibe.online/birds/3ceec9383040a5a6ff0fb96b63b10e600fbe4f86.jpg", "https://cdn.shibe.online/birds/a597dfc40c4c1fbde390e18cffbd42810a406a1b.jpg", "https://cdn.shibe.online/birds/11c7a86864e86a8e98514ba5c34a97fab23a3f7d.jpg", "https://cdn.shibe.online/birds/554fdcbf15ae6f094af27a73d3326bd682c7487d.jpg", "https://cdn.shibe.online/birds/c8976cca1a9109709f18b8b157ab031715ba24e0.jpg",]
            let bird2 = bird[Math.floor(Math.random() * bird.length)]
            await client.sendFileFromUrl(from, bird2, 'bird.jpeg.', 'Wung ape tu man?', id)
            break 
        case '.goat':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const goat = await get.get('https://api.i-tech.id/tools/goat?key=MjAf8I-CW2h62-bXriRJ-JrbLXP-jUz8vW').json()
            await client.sendFileFromUrl(from, goat.result, 'goat.jpeg.', 'Mbek!', id)
            break

        case '.ayat': //30
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const ayat = [
            'Q.S. Al Baqarah ayat 165\nوَالَّذِينَ آمَنُوا أَشَدُّ حُبًّا لِلَّهِ\nArtinya: Orang-orang yang beriman lebih kuat cintanya kepada Allah.',
            'Q.S. Ali Imran ayat 31\nقُلْ إِنْ كُنْتُمْ تُحِبُّونَ اللَّهَ فَاتَّبِعُونِي يُحْبِبْكُمُ اللَّهُ وَيَغْفِرْ لَكُمْ ذُنُوبَكُمْ ۗ وَاللَّهُ غَفُورٌ رَحِيمٌ\nArtinya: Katakanlah: "Jika kamu (benar-benar) mencintai Allah, ikutilah aku, niscaya Allah mengasihi dan mengampuni dosa-dosamu". Allah Maha Pengampun lagi Maha Penyayang.',
            'Q.S. Maryam ayat 96\nإِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ سَيَجْعَلُ لَهُمُ الرَّحْمَٰنُ وُدًّا\nArtinya: Sesungguhnya orang-orang yang beriman dan beramal saleh, kelak Allah Yang Maha Pemurah akan menanamkan dalam (hati) mereka rasa kasih sayang.',
            'Q.S. Al-Baqarah ayat 163\nوَإِلَٰهُكُمْ إِلَٰهٌ وَاحِدٌ ۖ لَا إِلَٰهَ إِلَّا هُوَ الرَّحْمَٰنُ الرَّحِيمُ\nArtinya: Dan Tuhanmu adalah Tuhan Yang Maha Esa; tidak ada Tuhan melainkan Dia Yang Maha Pemurah lagi Maha Penyayang.',
            'Q.S. Ar-Ra`d ayat 28\nالَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُمْ بِذِكْرِ اللَّهِ ۗ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ\nArtinya: (yaitu) orang-orang yang beriman dan hati mereka manjadi tenteram dengan mengingat Allah. Ingatlah, hanya dengan mengingati Allah-lah hati menjadi tenteram.',
            'Q.S. Al-Ahzab ayat 21\nلَقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ لِمَنْ كَانَ يَرْجُو اللَّهَ وَالْيَوْمَ الآخِرَ وَذَكَرَ اللَّهَ كَثِيرًا\nArtinya: Sesungguhnya telah ada pada (diri) Rasulullah itu teladan yang baik bagimu (yaitu) bagi orang yang mengharap (rahmat) Allah dan (balasan kebaikan pada) hari kiamat dan dia banyak menyebut Allah.',
            'Q.S. An-Nisa` ayat 59\nيَا أَيُّهَا الَّذِينَ آمَنُوا أَطِيعُوا اللَّهَ وَأَطِيعُوا الرَّسُولَ\nArtinya: Hai orang-orang yang beriman, taatilah Allah dan taatilah Rasul-Nya….',
            'Q.S. An-Nisa` ayat 80\nمَنْ يُطِعِ الرَّسُولَ فَقَدْ أَطَاعَ اللَّهَ ۖ وَمَنْ تَوَلَّىٰ فَمَا أَرْسَلْنَاكَ عَلَيْهِمْ حَفِيظًا\nArtinya: Barangsiapa yang mentaati Rasul itu, sesungguhnya ia telah mentaati Allah. Dan barangsiapa yang berpaling (dari ketaatan itu), maka Kami tidak mengutusmu untuk menjadi pemelihara bagi mereka.',
            'Q.S. Al-Hujurat ayat 1\nيَا أَيُّهَا الَّذِينَ آمَنُوا لَا تُقَدِّمُوا بَيْنَ يَدَيِ اللَّهِ وَرَسُولِهِ ۖ وَاتَّقُوا اللَّهَ ۚ إِنَّ اللَّهَ سَمِيعٌ عَلِيمٌ\nArtinya: Hai orang-orang yang beriman, janganlah kamu mendahului Allah dan Rasulnya dan bertakwalah kepada Allah. Sesungguhnya Allah Maha Mendengar lagi Maha Mengetahui.',
            'Q.S. At-Taubah ayat 24\nقُلْ إِنْ كَانَ آبَاؤُكُمْ وَأَبْنَاؤُكُمْ وَإِخْوَانُكُمْ وَأَزْوَاجُكُمْ وَعَشِيرَتُكُمْ وَأَمْوَالٌ اقْتَرَفْتُمُوهَا وَتِجَارَةٌ تَخْشَوْنَ كَسَادَهَا وَمَسَاكِنُ تَرْضَوْنَهَا أَحَبَّ إِلَيْكُمْ مِنَ اللَّهِ وَرَسُولِهِ وَجِهَادٍ فِي سَبِيلِهِ فَتَرَبَّصُوا حَتَّىٰ يَأْتِيَ اللَّهُ بِأَمْرِهِ ۗ وَاللَّهُ لَا يَهْدِي الْقَوْمَ الْفَاسِقِينَ\nArtinya: Katakanlah: "jika bapa-bapa, anak-anak, saudara-saudara, isteri-isteri, kaum keluargamu, harta kekayaan yang kamu usahakan, perniagaan yang kamu khawatiri kerugiannya, dan tempat tinggal yang kamu sukai, adalah lebih kamu cintai dari Allah dan Rasul-Nya dan dari berjihad di jalan-Nya, maka tunggulah sampai Allah mendatangkan keputusan-Nya". Dan Allah tidak memberi petunjuk kepada orang-orang yang fasik.',
            'Q.S. Al-Isra ayat 23\nوَقَضَىٰ رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا ۚ إِمَّا يَبْلُغَنَّ عِنْدَكَ الْكِبَرَ أَحَدُهُمَا أَوْ كِلَاهُمَا فَلَا تَقُلْ لَهُمَا أُفٍّ وَلَا تَنْهَرْهُمَا وَقُلْ لَهُمَا قَوْلًا كَرِيمًا\nArtinya: Dan Tuhanmu telah memerintahkan supaya kamu jangan menyembah selain Dia dan hendaklah kamu berbuat baik pada ibu bapakmu dengan sebaik-baiknya. Jika salah seorang di antara keduanya atau kedua-duanya sampai berumur lanjut dalam pemeliharaanmu, maka sekali-kali janganlah kamu mengatakan kepada keduanya perkataan "ah" dan janganlah kamu membentak mereka dan ucapkanlah kepada mereka perkataan yang mulia.',
            'Q.S. Al-Isra ayat 24\nوَاخْفِضْ لَهُمَا جَنَاحَ الذُّلِّ مِنَ الرَّحْمَةِ وَقُلْ رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا\nArtinya: Dan rendahkanlah dirimu terhadap mereka berdua dengan penuh kesayangan dan ucapkanlah: "Wahai Tuhanku, kasihilah mereka keduanya, sebagaimana mereka berdua telah mendidik aku waktu kecil".',
            'Q.S. An-Nisa ayat 36\nوَاعْبُدُوا اللَّهَ وَلَا تُشْرِكُوا بِهِ شَيْئًا ۖ وَبِالْوَالِدَيْنِ إِحْسَانًا وَبِذِي الْقُرْبَىٰ وَالْيَتَامَىٰ وَالْمَسَاكِينِ وَالْجَارِ ذِي الْقُرْبَىٰ وَالْجَارِ الْجُنُبِ وَالصَّاحِبِ بِالْجَنْبِ وَابْنِ السَّبِيلِ وَمَا مَلَكَتْ أَيْمَانُكُمْ ۗ إِنَّ اللَّهَ لَا يُحِبُّ مَنْ كَانَ مُخْتَالًا فَخُورًا\nArtinya: Sembahlah Allah dan janganlah kamu mempersekutukan-Nya dengan sesuatupun. Dan berbuat baiklah kepada dua orang ibu-bapa, karib-kerabat, anak-anak yatim, orang-orang miskin, tetangga yang dekat dan tetangga yang jauh, dan teman sejawat, ibnu sabil dan hamba sahayamu. Sesungguhnya Allah tidak menyukai orang-orang yang sombong dan membangga-banggakan diri.',
            'Q.S. Luqman ayat 14\nوَوَصَّيْنَا الْإِنْسَانَ بِوَالِدَيْهِ حَمَلَتْهُ أُمُّهُ وَهْنًا عَلَىٰ وَهْنٍ وَفِصَالُهُ فِي عَامَيْنِ أَنِ اشْكُرْ لِي وَلِوَالِدَيْكَ إِلَيَّ الْمَصِيرُ\nArtinya: Dan Kami perintahkan kepada manusia (berbuat baik) kepada dua orang ibu-bapaknya; ibunya telah mengandungnya dalam keadaan lemah yang bertambah-tambah, dan menyapihnya dalam dua tahun. Bersyukurlah kepada-Ku dan kepada dua orang ibu bapakmu, hanya kepada-Kulah kembalimu.',
            'Q.S. Al-Ahqaf ayat 15\nوَوَصَّيْنَا الْإِنْسَانَ بِوَالِدَيْهِ إِحْسَانًا ۖ حَمَلَتْهُ أُمُّهُ كُرْهًا وَوَضَعَتْهُ كُرْهًا ۖ وَحَمْلُهُ وَفِصَالُهُ ثَلَاثُونَ شَهْرًا ۚ حَتَّىٰ إِذَا بَلَغَ أَشُدَّهُ وَبَلَغَ أَرْبَعِينَ سَنَةً قَالَ رَبِّ أَوْزِعْنِي أَنْ أَشْكُرَ نِعْمَتَكَ الَّتِي أَنْعَمْتَ عَلَيَّ وَعَلَىٰ وَالِدَيَّ وَأَنْ أَعْمَلَ صَالِحًا تَرْضَاهُ وَأَصْلِحْ لِي فِي ذُرِّيَّتِي ۖ إِنِّي تُبْتُ إِلَيْكَ وَإِنِّي مِنَ الْمُسْلِمِينَ\nArtinya: Kami perintahkan kepada manusia supaya berbuat baik kepada dua orang ibu bapaknya, ibunya mengandungnya dengan susah payah, dan melahirkannya dengan susah payah (pula). Mengandungnya sampai menyapihnya adalah tiga puluh bulan, sehingga apabila dia telah dewasa dan umurnya sampai empat puluh tahun ia berdoa: "Ya Tuhanku, tunjukilah aku untuk mensyukuri nikmat Engkau yang telah Engkau berikan kepadaku dan kepada ibu bapakku dan supaya aku dapat berbuat amal yang saleh yang Engkau ridhai; berilah kebaikan kepadaku dengan (memberi kebaikan) kepada anak cucuku. Sesungguhnya aku bertaubat kepada Engkau dan sesungguhnya aku termasuk orang-orang yang berserah diri.".',
            'Q.S. Al-A`la 17\nوَالْآخِرَةُ خَيْرٌ وَأَبْقَىٰ\nArtinya: Sedang kehidupan akhirat adalah lebih baik dan lebih kekal.',
            'Q.S. Yunus ayat 24\nإِنَّمَا مَثَلُ الْحَيَاةِ الدُّنْيَا كَمَاءٍ أَنْزَلْنَاهُ مِنَ السَّمَاءِ فَاخْتَلَطَ بِهِ نَبَاتُ الْأَرْضِ مِمَّا يَأْكُلُ النَّاسُ وَالْأَنْعَامُ حَتَّىٰ إِذَا أَخَذَتِ الْأَرْضُ زُخْرُفَهَا وَازَّيَّنَتْ وَظَنَّ أَهْلُهَا أَنَّهُمْ قَادِرُونَ عَلَيْهَا أَتَاهَا أَمْرُنَا لَيْلًا أَوْ نَهَارًا فَجَعَلْنَاهَا حَصِيدًا كَأَنْ لَمْ تَغْنَ بِالْأَمْسِ ۚ كَذَٰلِكَ نُفَصِّلُ الْآيَاتِ لِقَوْمٍ يَتَفَكَّرُونَ\nArtinya: Sesungguhnya perumpamaan kehidupan duniawi itu hanya seperti air (hujan) yang Kami turunkan dari langit, lalu tumbuhlah tanaman-tanaman bumi dengan subur (karena air itu), di antaranya ada yang dimakan manusia dan hewan ternak. Hingga apabila bumi itu telah sempurna keindahannya, dan berhias, dan pemiliknya mengira bahwa mereka pasti menguasainya (memetik hasilnya), datanglah kepadanya adzab Kami pada waktu malam atau siang, lalu Kami jadikan (tanaman)nya seperti tanaman yang sudah disabit, seakan-akan belum pernah tumbuh kemarin. Demikianlah Kami menjelaskan tanda-tanda (kekuasaan Kami) kepada orang yang berpikir.',
            'Q.S. Al-Kahfi ayat 45-46\nوَاضْرِبْ لَهُمْ مَثَلَ الْحَيَاةِ الدُّنْيَا كَمَاءٍ أَنْزَلْنَاهُ مِنَ السَّمَاءِ فَاخْتَلَطَ بِهِ نَبَاتُ الْأَرْضِ فَأَصْبَحَ هَشِيمًا تَذْرُوهُ الرِّيَاحُ ۗ وَكَانَ اللَّهُ عَلَىٰ كُلِّ شَيْءٍ مُقْتَدِرًا ﴿٤٥﴾ الْمَالُ وَالْبَنُونَ زِينَةُ الْحَيَاةِ الدُّنْيَا ۖ وَالْبَاقِيَاتُ الصَّالِحَاتُ خَيْرٌ عِنْدَ رَبِّكَ ثَوَابًا وَخَيْرٌ أَمَلًا\nArtinya: Dan buatkanlah untuk mereka (manusia) perumpamaan kehidupan dunia ini, ibarat air (hujan) yang Kami turunkan dari langit, sehingga menyuburkan tumbuh-tumbuhan di bumi, kemudian (tumbuh-tumbuhan) itu menjadi kering yang diterbangkan oleh angin. Dan Allâh Mahakuasa atas segala sesuatu. Harta dan anak-anak adalah perhiasan kehidupan dunia tetapi amal kebajikan yang terus menerus adalah lebih baik pahalanya di sisi Rabb-mu serta lebih baik untuk menjadi harapan.',
            'Q.S. Al-Munafiqun ayat 9\nيَا أَيُّهَا الَّذِينَ آمَنُوا لَا تُلْهِكُمْ أَمْوَالُكُمْ وَلَا أَوْلَادُكُمْ عَنْ ذِكْرِ اللَّهِ ۚ وَمَنْ يَفْعَلْ ذَٰلِكَ فَأُولَٰئِكَ هُمُ الْخَاسِرُونَ\nArtinya: Wahai orang-orang yang beriman!Janganlah harta bendamu dan anak-anakmu melalaikan kamu dari mengingat Allâh.Dan barangsiapa berbuat demikian, maka mereka itulah orang-orang yang rugi.',
            'Q.S. Ali Imran ayat 185\nكُلُّ نَفْسٍ ذَائِقَةُ الْمَوْتِ ۗ وَإِنَّمَا تُوَفَّوْنَ أُجُورَكُمْ يَوْمَ الْقِيَامَةِ ۖ فَمَنْ زُحْزِحَ عَنِ النَّارِ وَأُدْخِلَ الْجَنَّةَ فَقَدْ فَازَ ۗ وَمَا الْحَيَاةُ الدُّنْيَا إِلَّا مَتَاعُ الْغُرُورِ\nArtinya: Tiap-tiap yang berjiwa akan merasakan mati. Dan sesungguhnya pada hari kiamat sajalah disempurnakan pahalamu. Barangsiapa dijauhkan dari neraka dan dimasukkan ke dalam surga, maka sungguh ia telah beruntung. Kehidupan dunia itu tidak lain hanyalah kesenangan yang memperdayakan.',
            'Q.S. Al-Hujurat ayat 13\nيَا أَيُّهَا النَّاسُ إِنَّا خَلَقْنَاكُمْ مِنْ ذَكَرٍ وَأُنْثَىٰ وَجَعَلْنَاكُمْ شُعُوبًا وَقَبَائِلَ لِتَعَارَفُوا ۚ إِنَّ أَكْرَمَكُمْ عِنْدَ اللَّهِ أَتْقَاكُمْ ۚ إِنَّ اللَّهَ عَلِيمٌ خَبِيرٌ\nArtinya: Hai manusia, sesungguhnya Kami menciptakan kamu dari seorang laki-laki dan seorang perempuan dan menjadikan kamu berbangsa-bangsa dan bersuku-suku supaya kamu saling kenal-mengenal. Sesungguhnya orang yang paling mulia diantara kamu disisi Allah ialah orang yang paling takwa diantara kamu. Sesungguhnya Allah Maha Mengetahui lagi Maha Mengenal.',
            'Q.S. An-Najm ayat 45\nوَأَنَّهُ خَلَقَ الزَّوْجَيْنِ الذَّكَرَ وَالْأُنْثَىٰ\nArtinya: Dan bahwasanya Dialah yang menciptakan berpasang-pasangan pria dan wanita.',
            'Q.S. An-Nur ayat 3\nالزَّانِي لَا يَنْكِحُ إِلَّا زَانِيَةً أَوْ مُشْرِكَةً وَالزَّانِيَةُ لَا يَنْكِحُهَا إِلَّا زَانٍ أَوْ مُشْرِكٌ ۚ وَحُرِّمَ ذَٰلِكَ عَلَى الْمُؤْمِنِينَ\nArtinya: Laki-laki yang berzina tidak mengawini melainkan perempuan yang berzina, atau perempuan yang musyrik; dan perempuan yang berzina tidak dikawini melainkan oleh laki-laki yang berzina atau laki-laki musyrik, dan yang demikian itu diharamkan atas oran-orang yang mukmin.',
            'Q.S. Al-Balad ayat 17\nثُمَّ كَانَ مِنَ الَّذِينَ آمَنُوا وَتَوَاصَوْا بِالصَّبْرِ وَتَوَاصَوْا بِالْمَرْحَمَةِ\nArtinya: Dan dia (tidak pula) termasuk orang-orang yang beriman dan saling berpesan untuk bersabar dan saling berpesan untuk berkasih sayang.',
            'Q.S. An-Naba` ayat 8\nخَلَقْنَاكُمْ أَزْوَاجًا\nArtinya: Dan Kami jadikan kamu berpasang-pasangan,...',
            'Q.S. Al-Baqarah ayat 221\nوَلَا تَنْكِحُوا الْمُشْرِكَاتِ حَتَّىٰ يُؤْمِنَّ ۚ وَلَأَمَةٌ مُؤْمِنَةٌ خَيْرٌ مِنْ مُشْرِكَةٍ وَلَوْ أَعْجَبَتْكُمْ ۗ وَلَا تُنْكِحُوا الْمُشْرِكِينَ حَتَّىٰ يُؤْمِنُوا ۚ وَلَعَبْدٌ مُؤْمِنٌ خَيْرٌ مِنْ مُشْرِكٍ وَلَوْ أَعْجَبَكُمْ ۗ أُولَٰئِكَ يَدْعُونَ إِلَى النَّارِ ۖ وَاللَّهُ يَدْعُو إِلَى الْجَنَّةِ وَالْمَغْفِرَةِ بِإِذْنِهِ ۖ وَيُبَيِّنُ آيَاتِهِ لِلنَّاسِ لَعَلَّهُمْ يَتَذَكَّرُونَ\nArtinya: Dan janganlah kamu menikahi wanita-wanita musyrik, sebelum mereka beriman. Sesungguhnya wanita budak yang mukmin lebih baik dari wanita musyrik, walaupun dia menarik hatimu. Dan janganlah kamu menikahkan orang-orang musyrik (dengan wanita-wanita mukmin) sebelum mereka beriman. Sesungguhnya budak yang mukmin lebih baik dari orang musyrik, walaupun dia menarik hatimu. Mereka mengajak ke neraka, sedang Allah mengajak ke surga dan ampunan dengan izin-Nya. Dan Allah menerangkan ayat-ayat-Nya (perintah-perintah-Nya) kepada manusia supaya mereka mengambil pelajaran.',
            'Q.S An-Nisa ayat 1\nيَا أَيُّهَا النَّاسُ اتَّقُوا رَبَّكُمُ الَّذِي خَلَقَكُمْ مِنْ نَفْسٍ وَاحِدَةٍ وَخَلَقَ مِنْهَا زَوْجَهَا وَبَثَّ مِنْهُمَا رِجَالًا كَثِيرًا وَنِسَاءً ۚ وَاتَّقُوا اللَّهَ الَّذِي تَسَاءَلُونَ بِهِ وَالْأَرْحَامَ ۚ إِنَّ اللَّهَ كَانَ عَلَيْكُمْ رَقِيبًا\nArtinya: Hai sekalian manusia, bertakwalah kepada Tuhan-mu yang telah menciptakan kamu dari seorang diri, dan dari padanya Allah menciptakan isterinya; dan dari pada keduanya Allah memperkembang biakkan laki-laki dan perempuan yang banyak. Dan bertakwalah kepada Allah yang dengan (mempergunakan) nama-Nya kamu saling meminta satu sama lain, dan (peliharalah) hubungan silaturahim. Sesungguhnya Allah selalu menjaga dan mengawasi kamu.',
            'Q.S. Ar-Rum ayat 21\nوَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُمْ مِنْ أَنْفُسِكُمْ أَزْوَاجًا لِتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُمْ مَوَدَّةً وَرَحْمَةً ۚ إِنَّ فِي ذَٰلِكَ لَآيَاتٍ لِقَوْمٍ يَتَفَكَّرُونَ\nArtinya: Dan di antara tanda-tanda kekuasaan-Nya ialah Dia menciptakan untukmu isteri-isteri dari jenismu sendiri, supaya kamu cenderung dan merasa tenteram kepadanya, dan dijadikan-Nya diantaramu rasa kasih dan sayang. Sesungguhnya pada yang demikian itu benar-benar terdapat tanda-tanda bagi kaum yang berpikir.',
            'Q.S. An-Nur ayat 26\nالْخَبِيثَاتُ لِلْخَبِيثِينَ وَالْخَبِيثُونَ لِلْخَبِيثَاتِ ۖ وَالطَّيِّبَاتُ لِلطَّيِّبِينَ وَالطَّيِّبُونَ لِلطَّيِّبَاتِ ۚ أُولَٰئِكَ مُبَرَّءُونَ مِمَّا يَقُولُونَ ۖ لَهُمْ مَغْفِرَةٌ وَرِزْقٌ كَرِيمٌ\nArtinya: Wanita-wanita yang keji adalah untuk laki-laki yang keji, dan laki-laki yang keji adalah buat wanita-wanita yang keji (pula), dan wanita-wanita yang baik adalah untuk laki-laki yang baik dan laki-laki yang baik adalah untuk wanita-wanita yang baik (pula). Mereka (yang dituduh) itu bersih dari apa yang dituduhkan oleh mereka (yang menuduh itu). Bagi mereka ampunan dan rezeki yang mulia (surga).',
            'Q.S. Az-Zariyat ayat 49\nوَمِنْ كُلِّ شَيْءٍ خَلَقْنَا زَوْجَيْنِ لَعَلَّكُمْ تَذَكَّرُونَ\nArtinya: Dan segala sesuatu Kami ciptakan berpasang-pasangan supaya kamu mengingat kebesaran Allah.',
            'Q.S. Yasin ayat 36\nسُبْحَانَ الَّذِي خَلَقَ الْأَزْوَاجَ كُلَّهَا مِمَّا تُنْبِتُ الْأَرْضُ وَمِنْ أَنْفُسِهِمْ وَمِمَّا لَا يَعْلَمُونَ\nArtinya: Maha Suci Tuhan yang telah menciptakan pasangan-pasangan semuanya, baik dari apa yang ditumbuhkan oleh bumi dan dari diri mereka maupun dari apa yang tidak mereka ketahui.',
            ]                
            let ayat2 = ayat[Math.floor(Math.random() * ayat.length)]
            await client.reply(from, ayat2, id)
            break
        case '.hadits': //30
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const hadits = [
            'قال رسولُ اللهِ -صلى الله عليه وسلم- : إِنَّ لِكُلِّ دِيْنِ خُلُقًا وَخُلُقُ الإسلامَ الْحَيَاءُ\nDari Anas bin Malik radhiallahu anhu, dia berkata, Nabi shallallahu alaihi was sallam, bersabda : "Sesungguhnya setiap agama memiliki akhlak, dan akhlak Islami adalah rasa malu." (HR. Ibnu Majah).',
            'إِنَّ اللهَ كَرِيْمٌ يُحِبُّ الْكَرَمَ وَمَعَالِيَ اْلأَخْلاَقِ وَيُبْغِضُ سِفْسَافَهَا\n"Sesungguhnya Allah Maha Pemurah menyukai kedermawanan dan akhlak yang mulia serta membenci akhlak yang rendah (hina)." (HR. Bukhari, Muslim).',
            'إنَّ مِنْ خِيَارِكُمْ أَحْسَنَكُمْ أَخْلاَقًا\n"Sesungguhnya yang terbaik diantara kalian adalah yang terbaik akhlaknya." (HR. Ahmad).',
            'عَنْ أَبِي هُرَيْرَةَ قَالَ قَالَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ أَكْمَلُ الْمُؤْمِنِينَ إِيمَانًا أَحْسَنُهُمْ خُلُقًا وَخِيَارُكُمْ خِيَارُكُمْ لِنِسَائِهِمْ خُلُقًا\n"Orang mukmin yang paling sempurna keimanannya adalah ia yang memiliki akhlak terbaik. Yang terbaik diantara kalian adalah yang terbaik akhlaknya kepada pasangannya." (HR. At Tirmidzi).',
            'عَنْ عَائِشَةَ قَالَتْ سَمِعْتُ النَّبِيَّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ يَقُولُ إِنَّ الْمُؤْمِنَ يُدْرِكُ بِحُسْنِ خُلُقِهِ دَرَجَاتِ قَائِمِ اللَّيْلِ صَائِمِ النَّهَار\nAisyah radhiallahu anha, ia berkata, "Aku mendengar Nabi shallallahu alaihi was sallam, berkata, ‘Sungguh orang-orang yang beriman dengan akhlak baik mereka bisa mencapai (menyamai) derajat mereka yang menghabiskan seluruh malamnya dalam shalat dan seluruh siangnya dengan berpuasa." (HR. Ahmad).',
            'إِنَّ الْمُؤْمِنَ لَيُدْرِكُ بِحُسْنِ خُلُقِهِ دَرَجَةَ الصَّائِمِ الْقَائِمِ\n"Sesungguhnya seorang mukmin akan mendapatkan kedudukan alli puasa dan halat dengan akhlak baiknya." (HR. Abu Dawud).',
            'عَنْ أَبِي الدَّرْدَاءِ قَالَ سَمِعْتُ النَّبِيَّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ يَقُولُ مَا مِنْ شَيْءٍ يُوضَعُ فِي الْمِيزَانِ أَثْقَلُ مِنْ حُسْنِ الْخُلُقِ وَإِنَّ صَاحِبَ حُسْنِ الْخُلُقِ لَيَبْلُغُ بِهِ دَرَجَةَ صَاحِبِ الصَّوْمِ وَالصَّلَاةِ\nAbu Darda radhiallahu anhu, meriwayatkan, "Aku mendengar Nabi shallallahu alaihi was sallam berkata, ‘Tak ada yang lebih berat pada timbangan (mizan, pada hari pembalasan) dari pada akhlak yang baik. Sungguh orang yang berakhlak baik akan mencapai derajat orang yang berpuasa dan shalat." (HR. At Tirmidzi).',
            'عَنْ أَبِي الدَّرْدَاءِ أَنَّ النَّبِيَّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ مَا شَيْءٌ أَثْقَلُ فِي مِيزَانِ الْمُؤْمِنِ يَوْمَ الْقِيَامَةِ مِنْ خُلُقٍ حَسَنٍ وَإِنَّ اللَّهَ لَيُبْغِضُ الْفَاحِشَ الْبَذِيءَ\nDari Abu Darda’ radhiallahu anhu bahwasanya Nabi shallallahu alaihi was sallam bersabda, "Tidak ada sesuatu yang lebih berat dalam timbangan seorang mukmin kelak ada hari kiamat daripada akhlak yang baik. Sesungguhnya Allah amatlah murka terhadap seseorang yang keji lagi jahat." (HR. Tirmidzi).',
            'عَنْ عَبْدِ اللَّهِ بْنِ عَمْرٍو رَضِيَ اللَّهُ عَنْهُمَا عَنْ النَّبِيِّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ وَالْمُهَاجِرُ مَنْ هَجَرَ مَا نَهَى اللَّهُ عَنْهُ\n"Orang muslim yang baik adalah yang muslim lainnya aman dari gangguan ucapan dan tangannya, dan orang yang hijrah (termasuk kelompok muhajirin) adalah yang meninggalkan apa-apa yang dilarang Allah." (HR. Bukhari).',
            'إِنَّ الرِّفْقَ لَا يَكُونُ فِي شَيْءٍ إِلَّا زَانَهُ وَلَا يُنْزَعُ مِنْ شَيْءٍ إِلَّا شَانَهُ\n"Sesungguhnya kelembutan itu tidak berada pada sesuatu kecuali menghiasinya dan tidak dicabut dari sesuatu kecuali memperburuknya." (HR. Muslim).',
            'أَنَا زَعِيمٌ بِبَيْتٍ فِي رَبَضِ الْجَنَّةِ لِمَنْ تَرَكَ الْمِرَاءَ وَإِنْ كَانَ مُحِقًّا وَبِبَيْتٍ فِي وَسَطِ الْجَنَّةِ لِمَنْ تَرَكَ الْكَذِبَ وَإِنْ كَانَ مَازِحًا وَبِبَيْتٍ فِي أَعْلَى الْجَنَّةِ لِمَنْ حَسَّنَ خُلُقَهُ\n"Aku adalah penjamin sebuah rumah di sekitar taman (Surga) bagi seseorang yang meniggalkan perdebatan walaupun ia benar, penjamin rumah ditengah Surga bagi orang yang meninggalkan dusta walaupun ia bercanda, juga menjadi penjamin sebuah rumah di Surga paling atas bagi orang yang memiliki akhlak yang baik." (HR. Abu Dawud).',
            'كاَنَ خُلُقُهُ الْقُرْآنَ\n"Akhlak Rasulullah adalah Al Qur’an." (HR. Muslim).',
            'عَنْ أَبِي هُرَيْرَةَ قَالَ قَالَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ الْإِيمَانُ بِضْعٌ وَسَبْعُونَ أَوْ بِضْعٌ وَسِتُّونَ شُعْبَةً فَأَفْضَلُهَا قَوْلُ لَا إِلَهَ إِلَّا اللَّهُ وَأَدْنَاهَا إِمَاطَةُ الْأَذَى عَنْ الطَّرِيقِ وَالْحَيَاءُ شُعْبَةٌ مِنْ الْإِيمَانِ (مسلم\nDari Abu Hurairah radhiallahu anhu, Rasulullah shallallahu alaihi was sallam bersabda,"Iman itu lebih dari 70 atau 60 cabang, cabang iman tertinggi adalah mengucapakna Laa ilaha illallaah, dan ang terendah adalah menyingkirkan gangguan dari jalan, dan rasa (akhlak) malu merupakan sebagian dari iman." (HR. Muslim).',
            'حَدَّثَنَا قَتَادَةُ عَنْ أَنَسٍ عَنْ النَّبِيِّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ\n"Tidaklah seorang diantara kalian dikatakan beriman hingga ia mencinta untuk saudaranya apa-apa yang ia sukai untuk dirinya sendiri." (HR. Bukhari).',
            'عَنْ أَبِي هُرَيْرَةَ أَنَّ رَسُولَ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ لَا يَدْخُلُ الْجَنَّةَ مَنْ لَا يَأْمَنُ جَارُهُ بَوَائِقَهُ (مسلم\n"Tidak akan masuk Surga orang yang tetangganya tidak aman dari gangguannya." (HR. Muslim).',
            'عَنْ أَبِي ذَرٍّ قَالَ قَالَ لِي رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ اتَّقِ اللَّهِ حَيْثُمَا كُنْتَ وَأَتْبِعْ السَّيِّئَةَ الْحَسَنَةَ تَمْحُهَا وَخَالِقِ النَّاسَ بِخُلُقٍ حَسَنٍ\nDari Abu Dzar radhiallahu anhu, ia berkata, Rasulullah shallallahu alaihi was sallam pernah bersabda kepadaku, "Bertakwalah kamu kepada Allah dimana saja kamu berada dan ikutilah setiap keburukan dengan kebaikan yang dapat menghapuskannya, serta pergaulilah manusia dengan akhlak yang baik." (HR. At Tirmidzi).',
            'أَنَّ رَجُلًا قَالَ لِلنَّبِيِّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ أَوْصِنِي قَالَ لَا تَغْضَبْ فَرَدَّدَ مِرَارًا قَالَ لَا تَغْضَبْ\nSeseorang berkata kepada Rasulullah shallallahu alaihi was sallam, ‘Nasihati aku.’ Beliau bersabda ‘Jangan marah.’ Beliau mengulang beberapa kali, ‘Jangan marah.’ (HR. Bukhari).',
            'النَّبِيُّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ يَقُولُ اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ مُنْكَرَاتِ الْأَخْلَاقِ وَالْأَعْمَالِ وَالْأَهْوَاءِ\nNabi shallallahu alaihi was sallam mengucapkan : ‘Allaahumma inni a’udzubika min munkaraatil akhlaaqu wal a’mali wal ahwaai’ (Ya Allah, aku berlindung kepada-Mu dari berbagai kemunkaran akhlak, amal maupun hawa nafsu).’ (HR. At Tirmidzi).',
            'عَنْ أَبِي هُرَيْرَةَ قَالَ سُئِلَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ عَنْ أَكْثَرِ مَا يُدْخِلُ النَّاسَ الْجَنَّةَ فَقَالَ تَقْوَى اللَّهِ وَحُسْنُ الْخُلُقِ وَسُئِلَ عَنْ أَكْثَرِ مَا يُدْخِلُ النَّاسَ النَّارَ فَقَالَ الْفَمُ وَالْفَرْجُ\nDari Abu Hurairah radhiallahu anhu, ia berkata, Rasulullah shallallahu alaihi was sallam pernah ditanya tentang sesutu yang paling banyak memasukkan seseorang ke dalam Surga, maka beliaupun menjawab, ‘Takwa kepada Allah dan akhlak yang mulia.’ Dan beliau juga ditanya tentang sesuatu yang paling banyak memasukan orang ke dalam Neraka, maka beliau menjawab, ‘Mulut dan kemaluan.’ (HR. At Tirmidzi).',
            'كَانَ رَسُوْلُ اللهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ أَحْسَنَ النَّاسِ خُلُقاً\n"Rasulullah shallallahu alaihi was sallam adalah orang yang paling baik akhlaknya." (HR. Bukhari, Muslim).',
            'مَنْ أَرَادَ الدُّنْيَا فَعَلَيْهِ بِاْلعِلْمِ، وَمَنْ أَرَادَ الآخِرَهَ فَعَلَيْهِ بِالْعِلْمِ، وَمَنْ أَرَادَهُمَا فَعَلَيْهِ باِلعِلْمِ\n"Barangsiapa yang hendak menginginkan dunia, maka hendaklah ia menguasai ilmu. Barangsiapa menginginkan akhirat, hendaklah ia menguasai ilmu. Dan barang siapa yang menginginkan keduanya (dunia dan akhirat), hendaklah ia menguasai ilmu." (HR. Ahmad).',
            'كُوْنـُـوْا رَبَّانِيِّـْينَ حُلَمَاءَ فُقَهَاءَ عُلَمَاءَ وَيُقَالُ اَلرَّبَّانِيُّ الَّذِى يُــرَبِــّى النَّاسَ بِصِغَارِ اْلعِلْمِ قَبْلَ كِبَارِهِ\n"Jadilah pendidik yang penyantun, ahli fikih, dan ulama. Disebut pendidik apabila seseorang mendidik manudia dengan memberikan ilmu sedikit-sedikit yang lama-lama menjadi banyak." (HR. Bukhari).',
            'كُلُّ مَوْلُودٍ يُولَدُ عَلَى الْفِطْرَةِ فَأَبَوَاهُ يُهَوِّدَانِهِ أَوْ يُنَصِّرَانِهِ أَوْ يُمَجِّسَانِهِ كَمَثَلِ الْبَهِيمَةِ تُنْتَجُ الْبَهِيمَةَ هَلْ تَرَى فِيهَا جَدْعَاءَ\n"Setiap anak dilahirkan dalam keadaan fitrah (suci). Kemudian kedua orang tunyalah yang akan menjadikan anak itu menjadi Yahudi, Nasrani, atau Majusi sebagaimana binatang ternak yang melahirkan binatang ternak dengan sempurna. Apakah kalian melihat ada cacat padanya?" (HR. Bukhari).',
            'طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ\n"Menuntut ilmu adalah kewajiban bagi setiap muslim." (HR. Ibnu Majah).',
            'مَنْ سَلَكَ طَرِيْقًا يَلْتَمِسُ فِيْهِ عِلْمًا سَهَّلَ اللهُ بِهِ طَرِيْقًا إِلَى الْجَنَّةِ\n"Barangsiapa yang menempuh suatu jalan untuk menuntut ilmu, maka Allah Swt akan memudahkan baginya jalan menuju surga." (HR. Muslim).',
            'إِنَّ الْأَنْبِيَاءَ لَمْ يُوَرِّثُوا دِينَارًا وَلَا دِرْهَمًا إِنَّمَا وَرَّثُوا الْعِلْمَ فَمَنْ أَخَذَ بِهِ أَخَذَ بِحَظٍّ وَافِرٍ\n"Sesungguhnya para Nabi tidak mewariskan dinar dan dirham, sesungguhnya mereka hanyalah mewariskan ilmu, maka barangsiapa yang telah mengambilnya, maka ia telah mengambil bagian yang banyak." (HR. Abu Dawud dan At-Tirmidzi).',
            'اِفْتَحُوْا عَلَى صِبْيَانَكُمْ أَوَّلَ كَلِمَةٍ بِلاَ إِلَهَ اِلاَّ اللهُ\n"Ajarkanlah kalimat pertama kepada anak-anak kalian La ilaha Illallah." (HR. Al-Hakim).',
            'تَعَلّمُواالعِلْمَ وَتَعَلّمُوْا لِلْعِلْمِ السّكِيْنَةَ وَالْوَقَا رَ وَتَوَاضَعُوْا لِمَنْ تَتَعَلّمُوانَ مِنْهُ\n"Belajarlah kalian ilmu untuk ketenteraman dan ketenangan, serta rendah hatilah pada orang yang kamu belajar darinya."  (HR. Ath-Thabrani).',
            'لَا يَتْبَغِ لِلْجَاهِلِ اَنْ يَسْكُنَ عَلَى جَهْلِهِ وَلَا لِلْعَالِمِ اَنْ يَسْكُنَ عَلَى عِلْمِهِ\n"Tidak pantas bagi orang yang bodoh itu mendiamkan kebodohannya dan tidak pantas pula orang yang berilmu mendiamkan ilmunya." (HR. Ath-Thabrani).',
            'مَا نَحَلَ وَالِدٌ وَلَدًا مِنْ نَحْلٍ أَفْضَلَ مِنْ أَدَبٍ حَسَنٍ\n"Tiada suatu pemberian yang lebih utama dari orang tua kepada anaknya selain pendidikan yang baik. (HR. Al-Hakim).',
            ]                
            let hadits2 = hadits[Math.floor(Math.random() * hadits.length)]
            await client.reply(from, hadits2, id)
            break   
        case '.quran':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.quran*_no surah_\nContoh : *.quran1*\nSurah yang tersedia :\n1. Al-Fatihah\n87. Al-A`la\n95. At-Tin\n97. Al-Qadr\n98. Al-Bayyinah\n99. Al-Zalzalah\n100. Al-Adiyat\n101. Al-Qari`ah\n102. At-Takatsur\n103. Al-Asr\n104. Al-Humazah\n105. Al-Fiil\n106. Al-Quraisy\n107. Al-Maun\n108. Al-Kautsar\n109. Al-Kafirun\n110. An-Nasr\n111. Al-Lahab\n112. Al-Ikhlas\n113. Al-Falaq\n114. An-nas', id)
            break
        case '.quran1':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/001.mp3', 'play.mp3', '', id)
            break
        case '.quran87':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/087.mp3', 'play.mp3', '', id)
            break   
        case '.quran95':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/095.mp3', 'play.mp3', '', id)
            break
        case '.quran97':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/097.mp3', 'play.mp3', '', id)
            break
        case '.quran98':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/098.mp3', 'play.mp3', '', id)
            break
        case '.quran99':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/099.mp3', 'play.mp3', '', id)
            break
        case '.quran100':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/100.mp3', 'play.mp3', '', id)
            break   
        case '.quran101':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/101.mp3', 'play.mp3', '', id)
            break
        case '.quran102':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/102.mp3', 'play.mp3', '', id)
            break
        case '.quran103':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/103.mp3', 'play.mp3', '', id)
            break
        case '.quran104':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/104.mp3', 'play.mp3', '', id)
            break
        case '.quran105':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/105.mp3', 'play.mp3', '', id)
            break   
        case '.quran106':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/106.mp3', 'play.mp3', '', id)
            break
        case '.quran107':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/107.mp3', 'play.mp3', '', id)
            break
        case '.quran108':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/108.mp3', 'play.mp3', '', id)
            break
        case '.quran109':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/109.mp3', 'play.mp3', '', id)
            break
        case '.quran110':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/110.mp3', 'play.mp3', '', id)
            break   
        case '.quran111':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/111.mp3', 'play.mp3', '', id)
            break
        case '.quran112':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/112.mp3', 'play.mp3', '', id)
            break
        case '.quran113':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/113.mp3', 'play.mp3', '', id)
            break
        case '.quran114':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/quran/114.mp3', 'play.mp3', '', id)
            break
        case '.jadwalsholat':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.jadwalsholat* _kota_\nContoh : *.jadwalsholat* _dumai_')
            const daerah = body.slice(14)
            const jadwalShalat = await get.get(`https://api.haipbis.xyz/jadwalsholat?daerah=${daerah}`).json()
            if (jadwalShalat.error) return client.reply(from, jadwalShalat.error, id)
            const { Imsyak, Subuh, Dhuha, Dzuhur, Ashar, Maghrib, Isya } = await jadwalShalat
            arrbulan = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
            tgl = new Date().getDate()
            bln = new Date().getMonth()
            thn = new Date().getFullYear()
            const resultJadwal = `Lokasi : ${daerah}, ${tgl} ${arrbulan[bln]} ${thn}\nImsyak : ${Imsyak}\nSubuh : ${Subuh}\nDhuha : ${Dhuha}\nZuhur : ${Dzuhur}\nAshar : ${Ashar}\nMaghrib : ${Maghrib}\nIsya : ${Isya}`
            await client.reply(from, resultJadwal, id)
            break
        case '.jam':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.jam* _kota_\nContoh : *.jam* _tokyo_', id)
            const jam = await get.get('https://api.i-tech.id/tools/jam?key=JDPQSX-rz6Wf0-DgfTRY-SXsBB8-oX1ZMU&kota='+args[1]).json()
            if (jam.error) return client.reply(from, jam.error, id)
            await client.reply(from, `Lokasi : ${jam.address}\nLatitude : ${jam.latitude}\nLongtitude : ${jam.longitude}\nWaktu : ${jam.time}\nTanggal : ${jam.date}\nZona Waktu : ${jam.timezone}`, id)
            break
        case '.cuaca':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.cuaca* _kota_\nContoh : *.cuaca* _dumai_', id)
            const tempat = body.slice(7)
            const weather = await get.get('https://api.i-tech.id/tools/cuaca?key=JDPQSX-rz6Wf0-DgfTRY-SXsBB8-oX1ZMU&kota='+ tempat).json()
            if (weather.error) {
                await client.reply(from, mess.null, id)
            } else {
                await client.reply(from, `Lokasi : ${weather.tempat}\nCuaca : ${weather.cuaca}\nDeskripsi : ${weather.deskripsi}\nSuhu : ${weather.suhu}\nKelembapan : ${weather.kelembapan}\nAngin : ${weather.angin}\nUdara : ${weather.udara}`, id)
            }
            break
        case '.covid':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const covid = await get.get('https://covid-simple.satyawikananda.tech/api/world').json()
            await client.reply(from, `Global ${covid.lastUpdate}\nTotal : ${covid.totalCases}\nPositif : ${covid.activeCases}\nSembuh : ${covid.recovered}\nMeninggal : ${covid.deaths}\nKasus Selesai: ${covid.closedCases}`, id)
            break
        case '.covidindo':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const covidindo = await get.get('https://apicovid19indonesia-v2.vercel.app/api/indonesia').json()
            await client.reply(from, `indonesia ${covidindo.lastUpdate}\nPositif : ${covidindo.positif}\nDirawat : ${covidindo.dirawat}\nSembuh : ${covidindo.sembuh}\nMeninggal : ${covidindo.meninggal}`, id)
            break
        case '.gempa':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const bmkg = await get.get('https://api.haipbis.xyz/bmkg').json()
            const { shakemap, waktu, magnitudo, kedalaman, lokasi, potensi, saranBMKG } = bmkg
            const hasil = `${waktu}\nLokasi : ${lokasi}\nMagnitude : ${magnitudo}\nKedalaman : ${kedalaman}\nPotensi : ${potensi}\nSaran BMKG : ${saranBMKG}`
            await client.sendFileFromUrl(from, shakemap, 'shakemap.jpg', hasil, id)
            break
        case '.jadwaltvnow':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const jadwalNow = await get.get('https://api.haipbis.xyz/jadwaltvnow').json()
            await client.reply(from, `Jam : ${jadwalNow.jam}\nJadwalTV : ${jadwalNow.jadwalTV}`, id)
            break
        case '.jadwaltv':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const jadwalTv = async (query) => {
                const res = await get.get(`https://api.haipbis.xyz/jadwaltv/${query}`).json()
                if (res.error) return client.reply(from, '⚠️ Tidak ada hasil!.', id)
                switch(query) {
                    case 'antv':
                        return `ANTV\n${res.join('\n')}`
                        break
                    case 'gtv':
                        return `GTV\n${res.join('\n')}`
                        break
                    case 'indosiar':
                        return `INDOSIAR\n${res.join('\n')}`
                        break
                    case 'inewstv':
                        return `iNewsTV\n${res.join('\n')}`
                        break
                    case 'kompastv':
                        return `KompasTV\n${res.join('\n')}`
                        break
                    case 'mnctv':
                        return `MNCTV\n${res.join('\n')}`
                        break
                    case 'metrotv':
                        return `MetroTV\n${res.join('\n')}`
                        break
                    case 'nettv':
                        return `NetTV\n${res.join('\n')}`
                        break
                    case 'rcti':
                        return `RCTI\n${res.join('\n')}`
                        break
                    case 'sctv':
                        return `SCTV\n${res.join('\n')}`
                        break
                    case 'rtv':
                        return `RTV\n${res.join('\n')}`
                        break
                    case 'trans7':
                        return `Trans7\n${res.join('\n')}`
                        break
                    case 'transtv':
                        return `TransTV\n${res.join('\n')}`
                        break
                    default:
                        return mess.null
                        break
                }
            }
            exports.jadwalTv = jadwalTv            
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.jadwaltv* _channel_\nContoh : *.jadwaltv* _gtv_.', id)
            const query = body.slice(10).toLowerCase()
            const jadwal = await jadwalTv(query)
            await client.reply(from, jadwal, id)
            break
        case '.trend':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const trend = await get.get('https://api.haipbis.xyz/trendingtwitter/worldwide').json()
            if (trend.error) return client.reply(from, mess.null, id)
            await client.reply(from, `Worldwide ${trend.datetime}\n\n${trend.result[0].title}\n${trend.result[0].link}\n\n${trend.result[1].title}\n${trend.result[1].link}\n\n${trend.result[2].title}\n${trend.result[2].link}\n\n${trend.result[3].title}\n${trend.result[3].link}\n\n${trend.result[4].title}\n${trend.result[4].link}\n\n${trend.result[5].title}\n${trend.result[5].link}\n\n${trend.result[6].title}\n${trend.result[6].link}\n\n${trend.result[7].title}\n${trend.result[7].link}\n\n${trend.result[8].title}\n${trend.result[8].link}\n\n${trend.result[9].title}\n${trend.result[9].link}`, id)
            break
        case '.trendindo':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const trend2 = await get.get('https://api.haipbis.xyz/trendingtwitter/id').json()
            if (trend2.error) return client.reply(from, mess.null, id)
            await client.reply(from, `Indonesia ${trend2.datetime}\n\n${trend2.result[0].title}\n${trend2.result[0].link}\n\n${trend2.result[1].title}\n${trend2.result[1].link}\n\n${trend2.result[2].title}\n${trend2.result[2].link}\n\n${trend2.result[3].title}\n${trend2.result[3].link}\n\n${trend2.result[4].title}\n${trend2.result[4].link}\n\n${trend2.result[5].title}\n${trend2.result[5].link}\n\n${trend2.result[6].title}\n${trend2.result[6].link}\n\n${trend2.result[7].title}\n${trend2.result[7].link}\n\n${trend2.result[8].title}\n${trend2.result[8].link}\n\n${trend2.result[9].title}\n${trend2.result[9].link}`, id)
            break  
        case '.hari':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.hari* _tanggal+bulan_\nContoh : *.hari* _17+agustus_', id)
            const hari = await get.get('https://api.haipbis.xyz/harinasional?tanggal='+ args[1]).json()
            if (hari.error) return client.reply(from, mess.null, id)
            await client.reply(from, `Tanggal : ${hari.tanggal}\nKeterangan : ${hari.keterangan}`, id)
            break
        case '.spec':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.spec* _hp_\nContoh : *.spec* _samsung j2 prime_', id)
            const spec = await get.get('https://api.vhtear.com/gsmarena?query='+ args[1]+'&apikey=bot').json()
            if (spec.error) return client.reply(from, spec.error, id)
            await client.sendFileFromUrl(from, spec.result.image, 'spec.jpg', `${spec.result.title}\n\n${spec.result.spec}`, id)
            break
        case '.shopee':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.shopee* _barang_\nContoh : *.shopee* _samsung j2 prime_', id)
            const shopee = await get.get('https://api.vhtear.com/shopee?query='+ args[1]+'&count=10&apikey=bot').json()
            if (shopee.error) return client.reply(from, shopee.error, id)
            await client.sendFileFromUrl(from, shopee.result.items[0].image_cover, 'shopee.jpg', `${shopee.result.items[0].nama}\n${shopee.result.items[0].harga}\n${shopee.result.items[0].description}\n${shopee.result.items[0].link_product}`, id)
            break
        case '.shopee2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.shopee2* _barang_\nContoh : *.shopee* _samsung j2 prime_', id)
            const shopee2 = await get.get('https://api.vhtear.com/shopee?query='+ args[1]+'&count=10&apikey=bot').json()
            if (shopee2.error) return client.reply(from, shopee2.error, id)
            const res_mangazx = `${shopee2.result.items[0].nama}\n${shopee2.result.items[0].harga}\n${shopee2.result.items[0].link_product}`
            const res_mangaz1x = `${shopee2.result.items[1].nama}\n${shopee2.result.items[1].harga}\n${shopee2.result.items[1].link_product}`
            const res_mangaz2x = `${shopee2.result.items[2].nama}\n${shopee2.result.items[2].harga}\n${shopee2.result.items[2].link_product}`
            const res_mangaz3x = `${shopee2.result.items[3].nama}\n${shopee2.result.items[3].harga}\n${shopee2.result.items[3].link_product}`
            const res_mangaz4x = `${shopee2.result.items[4].nama}\n${shopee2.result.items[4].harga}\n${shopee2.result.items[4].link_product}`
            const res_mangaz5x = `${shopee2.result.items[5].nama}\n${shopee2.result.items[5].harga}\n${shopee2.result.items[5].link_product}`
            const res_mangaz6x = `${shopee2.result.items[6].nama}\n${shopee2.result.items[6].harga}\n${shopee2.result.items[6].link_product}`
            const res_mangaz7x = `${shopee2.result.items[7].nama}\n${shopee2.result.items[7].harga}\n${shopee2.result.items[7].link_product}`
            const res_mangaz8x = `${shopee2.result.items[8].nama}\n${shopee2.result.items[8].harga}\n${shopee2.result.items[8].link_product}`
            const res_mangaz9x = `${shopee2.result.items[9].nama}\n${shopee2.result.items[9].harga}\n${shopee2.result.items[9].link_product}`
            await client.reply(from, `${res_mangazx}\n\n${res_mangaz1x}\n\n${res_mangaz2x}\n\n${res_mangaz3x}\n\n${res_mangaz4x}\n\n${res_mangaz5x}\n\n${res_mangaz6x}\n\n${res_mangaz7x}\n\n${res_mangaz8x}\n\n${res_mangaz9x}`, id)
            break
        case '.resep':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.resep* _makanan_\nContoh : *.resep* _rendang_', id)
            const resep = await get.get('https://api.vhtear.com/resepmasakan?query='+ args[1]+'&apikey=bot').json()
            if (resep.error) return client.reply(from, resep.error, id)
            await client.sendFileFromUrl(from, resep.result.image, 'resep.jpg', `${resep.result.title}\n\n${resep.result.desc}\n\nBahan-bahan :\n${resep.result.bahan}\n\nLangkah-langkah :\n${resep.result.cara}`, id)
            break  
        case '.kurs':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            const kurs = await get.get('https://api.terhambar.com/idr').json()
            if (kurs.error) return client.reply(from, mess.null, id)
            await client.reply(from, `${kurs.result.source_name} ${kurs.result.last_update}\nDollar ke Rupiah : ${kurs.result.value}`, id)
            break

        case '.ss':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.ss* _link_\nContoh : *.ss* _https://www.google.com_', id)
            const ss = body.slice(4)
            const ss2 = await get.get('https://api.haipbis.xyz/ssweb?url='+ ss).json()
            if (ss2.error) return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, `${ss2.result}`, 'ss.jpg', ``, id)
            break
        case '.qr':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.qr* _link_\nContoh : *.qr* _https://www.youtube.com/watch?v=qDxrZyuRDKY_', id)
            const linz = body.slice(4)
            const shortlinkz = await get.get('https://api.i-tech.id/tools/qr?key=MjAf8I-CW2h62-bXriRJ-JrbLXP-jUz8vW&query='+ linz).json()
            if (shortlinkz.error) return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, `${shortlinkz.result}`, 'qr.jpg', ``, id)
            break
        case '.short':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.short* _link_\nContoh : *.short* _https://www.youtube.com/watch?v=qDxrZyuRDKY_', id)
            const lin = body.slice(7)
            const shortlink = await get.get('https://api.haipbis.xyz/bitly?url='+ lin).json()
            if (shortlink.error) return client.reply(from, mess.null, id)
            await client.reply(from, shortlink.result, id)
            break
        case '.ascii':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.ascii* _teks_\nContoh : *.ascii* _jihyo_', id)
            const txt = await get.get('https://api.vhtear.com/textscreen?query='+ args[1]+'&apikey=bot').json()
            if (txt.error) return client.reply(from, txt.error, id)
            await client.reply(from, txt.result.text, id)
            break
        case '.google':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.google* _kata kunci_\nContoh : *.google* _cebong', id)
            const google = await get.get('https://api.vhtear.com/googlesearch?query='+ args[1]+'&apikey=bot').json()
            if (google.error) return client.reply(from, google.error, id)
            await client.sendLinkWithAutoPreview(from, google.result[0], ``)
            break
        case '.i': case '.image':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.image* _kata kunci_\nContoh : *.image* _jihyo_', id)
            if (args[1].includes('memek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('rape')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bukake')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tante')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('girang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tempik')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('softcore')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hardcore')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gangbang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bondage')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('montok')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bohai')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bohay')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('eue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngeue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('breast')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('naked')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('blowjob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sex')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nude')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bra')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('boobs')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('boob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tit')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tits')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngewe')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('incest')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pornstar')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('porn')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('porno')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('puting')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nipples')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nipple')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pussy')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('vagina')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fetish')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('clirotis')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cliroti')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('clit')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jembut')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('peju')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('creampie')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gapping')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('venti')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cock')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('penis')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kontol')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bbc')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bbw')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tetek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nenen')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bh')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('beha')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('payudara')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('toket')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('toge')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('psk')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('lonte')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pelacur')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sperma')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('mani')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('coli')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('coly')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fap')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('masturbation')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('masturbasi')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('onani')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngocok')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('colmek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('doggy style')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('lewd')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hentai')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('doujin')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngeue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngentot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngentod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fuck')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jilmek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sepong')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jilbob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cosplay')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('milf')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('crot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('mesum')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bikini')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('onlyfans')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nsfw')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ass')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pantat')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('anus')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('anal')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('thic')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('thicc')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bokep')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kentot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kentod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('entod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hole')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('glory')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const cakfo = await get.get('https://api.vhtear.com/googleimg?query='+ args[1]+'&apikey=bot').json()
            if (cakfo.error) return client.reply(from, cakfo.error, id)
            let cakgo = cakfo.result.result_search[Math.floor(Math.random() * cakfo.result.result_search.length)]
            await client.sendFileFromUrl(from, cakgo, 'image.jpg', ``, id)
            break     
        case '.pi':  case '.pinterest': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.pinterest* _kata kunci_\nContoh : *.pinterest* _jihyo_', id)
            const piq = await get.get('https://api.fdci.se/rep.php?gambar='+ args[1]).json()
            if (piq.error) return client.reply(from, piq.error, id)
            const b = JSON.parse(JSON.stringify(piq));
            const piq2 =  b[Math.floor(Math.random() * b.length)];
            await client.sendFileFromUrl(from, piq2, 'pinterest.jpg', ``, id)
            break 
        case '.un': case '.unsplah': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.unsplah* _kata kunci_\nContoh : *.unsplah* _beach_')
            const un = await get.get('https://api.unsplash.com/search/photos?page=beach&query='+ args[1] +'&client_id=J92b7gyJFWEdgT3z6OXZlqXovHjcn9242Ob4rKdE3uA').json()
            await client.sendFileFromUrl(from, `${un.results[0].urls.full}`, 'unsplah.jpg', `${un.results[0].description}`, id)
            break
        case '.playstore':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.playstore* _kata kunci_\nContoh : *.playstore* _free fire_', id)
            const playstore = await get.get('https://api.vhtear.com/playstore?query='+ args[1]+'&apikey=bot').json()
            if (playstore.error) return client.reply(from, playstore.error, id)
            await client.sendFileFromUrl(from, playstore.result[0].icon, 'playstore.jpg', `Title : ${playstore.result[0].title}\nDev : ${playstore.result[0].developer}\nDesc : ${playstore.result[0].description}\nhttps://play.google.com${playstore.result[0].url}`, id)
            break   
        case '.yt':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args[1].includes('memek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('rape')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bukake')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tante')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('girang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tempik')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('softcore')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hardcore')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gangbang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gang')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bondage')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('montok')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bohai')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bohay')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('eue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngeue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('breast')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('naked')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('blowjob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sex')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nude')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bra')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('boobs')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('boob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tit')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tits')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngewe')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('incest')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pornstar')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('porn')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('porno')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('puting')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nipples')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nipple')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pussy')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('vagina')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fetish')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('clirotis')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cliroti')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('clit')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jembut')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('peju')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('creampie')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('gapping')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('venti')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cock')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('penis')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kontol')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bbc')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bbw')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('tetek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nenen')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bh')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('beha')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('payudara')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('toket')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('toge')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('psk')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('lonte')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pelacur')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sperma')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('mani')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('coli')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('coly')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fap')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('masturbation')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('masturbasi')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('onani')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngocok')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('colmek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('doggy style')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('lewd')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hentai')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('doujin')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngeue')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngentot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ngentod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('fuck')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jilmek')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('sepong')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('jilbob')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('cosplay')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('milf')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('crot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('mesum')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bikini')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('onlyfans')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('nsfw')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('ass')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('pantat')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('anus')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('anal')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('thic')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('thicc')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('bokep')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kentot')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('kentod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('entod')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('hole')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args[1].includes('glory')) if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.yt* _kata kunci_\nContoh : *.yt* _jihyo_', id)
            const yt = await get.get('https://api.vhtear.com/youtube?query='+ args[1]+'&apikey=bot').json()
            if (yt.error) return client.reply(from, yt.error, id)
            await client.sendFileFromUrl(from, yt.result[0].image, 'yt.jpg', `Title : ${yt.result[0].title}\nChannel : ${yt.result[0].channel}\nDuration : ${yt.result[0].duration}\nViews : ${yt.result[0].views}\n${yt.result[0].urlyt}`, id)
            break
        case '.yt2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.yt2* _kata kunci_\nContoh : *.yt2* _jihyo_', id)
            const yt2 = await get.get('https://api.vhtear.com/youtube?query='+ args[1]+'&count=10&apikey=bot').json()
            if (yt2.error) return client.reply(from, yt2.error, id)
            const ytt = `Title : ${yt2.result[0].title}\nChannel : ${yt2.result[0].channel}\nDuration : ${yt2.result[0].duration}\nViews : ${yt2.result[0].views}\n${yt2.result[0].urlyt}`
            const ytt1 = `Title : ${yt2.result[1].title}\nChannel : ${yt2.result[1].channel}\nDuration : ${yt2.result[1].duration}\nViews : ${yt2.result[1].views}\n${yt2.result[0].urlyt}`
            const ytt2 = `Title : ${yt2.result[2].title}\nChannel : ${yt2.result[2].channel}\nDuration : ${yt2.result[2].duration}\nViews : ${yt2.result[2].views}\n${yt2.result[0].urlyt}`
            const ytt3 = `Title : ${yt2.result[3].title}\nChannel : ${yt2.result[3].channel}\nDuration : ${yt2.result[3].duration}\nViews : ${yt2.result[3].views}\n${yt2.result[0].urlyt}`
            const ytt4 = `Title : ${yt2.result[4].title}\nChannel : ${yt2.result[4].channel}\nDuration : ${yt2.result[4].duration}\nViews : ${yt2.result[4].views}\n${yt2.result[0].urlyt}`
            const ytt5 = `Title : ${yt2.result[5].title}\nChannel : ${yt2.result[5].channel}\nDuration : ${yt2.result[5].duration}\nViews : ${yt2.result[5].views}\n${yt2.result[0].urlyt}`
            const ytt6 = `Title : ${yt2.result[6].title}\nChannel : ${yt2.result[6].channel}\nDuration : ${yt2.result[6].duration}\nViews : ${yt2.result[6].views}\n${yt2.result[0].urlyt}`
            const ytt7 = `Title : ${yt2.result[7].title}\nChannel : ${yt2.result[7].channel}\nDuration : ${yt2.result[7].duration}\nViews : ${yt2.result[7].views}\n${yt2.result[0].urlyt}`
            const ytt8 = `Title : ${yt2.result[8].title}\nChannel : ${yt2.result[8].channel}\nDuration : ${yt2.result[8].duration}\nViews : ${yt2.result[8].views}\n${yt2.result[0].urlyt}`
            const ytt9 = `Title : ${yt2.result[9].title}\nChannel : ${yt2.result[9].channel}\nDuration : ${yt2.result[9].duration}\nViews : ${yt2.result[9].views}\n${yt2.result[0].urlyt}`
            await client.reply(from, `${ytt}\n\n${ytt1}\n\n${ytt2}\n\n${ytt3}\n\n${ytt4}\n\n${ytt5}\n\n${ytt6}\n\n${ytt7}\n\n${ytt8}\n\n${ytt9}`, id)
            break    
        case '.igstalk':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.igstalk* _username_\nContoh : *.igstalk* _pahrulkis_', id)
            const stalk = await get.get('https://mhankbarbar.herokuapp.com/api/stalk?username='+ args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (stalk.error) return client.reply(from, mess.null, id)
            const { Biodata, Jumlah_Followers, Jumlah_Following, Jumlah_Post, Name, Username, Profile_pic } = stalk
            const caps = `Name : ${Name}\nUsername : ${Username}\nBio : ${Biodata}\nFollowers : ${Jumlah_Followers}\nFollowing : ${Jumlah_Following}\nPosts : ${Jumlah_Post}\nhttps://www.instagram.com/${args[1]}`
            await client.sendFileFromUrl(from, Profile_pic, 'igstalk.jpg', caps, id)
            break
        case '.twstalk':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.twstalk* _username_\nContoh : *.twstalk* _pahrulkis_', id)
            const stalk2 = await get.get('https://mhankbarbar.herokuapp.com/api/twstalk?username='+ args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (stalk2.error) return client.reply(from, stalk2.error, id)
            const caps2 = `Name : ${stalk2.full_name}\nUsername : ${stalk2.name}\nFollowers : ${stalk2.followers_count}\nPosts : ${stalk2.status_count}`
            await client.sendFileFromUrl(from, stalk2.profile_pic, 'twstalk.jpg', caps2, id)
            break
        case '.tikstalk':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.tikstalk* _twice_tiktok_official_\nContoh : *.tikstalk* _twice_tiktok_official_', id)
            const tik2 = await get.get('https://api.vhtear.com/tiktokprofile?query=@'+ args[1]+'&apikey=bot').json()
            if (tik2.error) return client.reply(from, tik2.error, id)
            await client.sendFileFromUrl(from, tik2.result.picture, 'tikstalk.jpg', `Username : ${tik2.result.username}\nTitle : ${tik2.result.title}\nBio : ${tik2.result.bio}\nFollowers : ${tik2.result.follower}\nFollowings : ${tik2.result.follow}\nLikes : ${tik2.result.like_count}\nPosts : ${tik2.result.video_post}\n${tik2.result.url_account}`, id)
            break    
        case '.s': case '.sticker':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (isMedia && type === 'image') {
                const mediaData = await decryptMedia(message, uaOverride)
                    const imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                    await client.sendImageAsSticker(from, imageBase64)
                } else if (quotedMsg && quotedMsg.type == 'image') {
                    const mediaData = await decryptMedia(quotedMsg, uaOverride)
                    const imageBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                    client.reply(from, 'Stickernya senpai!', id)
                    await client.sendImageAsSticker(from, imageBase64)
                } else if (args.length === 2) {
                    const url = args[1]
                    if (url.match(isUrl)) {
                        await client.sendStickerfromUrl(from, url, { method: 'get' })
                            .catch(err => console.log('Caught exception: .', err))
                    } else {
                        await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.sticker* _[upload/reply gambar/link]_', id)
                    }
                } else {
                    await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.sticker* _[upload/reply gambar/link]_', id)
                }
                break
        case '.sg': case '.stickergif':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isMedia) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.sticker* _[upload video/gif]_\nNote : video/gif maksimal 10 detik!', id)
                if (isMedia) {
                    if (mimetype === 'video/mp4' && message.duration < 10 || mimetype === 'image/gif' && message.duration < 10) {
                        const mediaData = await decryptMedia(message, uaOverride)
                        await client.reply(from, mess.wait, id)
                        const filename = `./media/aswu.${mimetype.split('/')[1]}`
                        await fs.writeFileSync(filename, mediaData)
                        await exec(`gify ${filename} ./media/output.gif --fps=30 --scale=240:240`, async function (error, stdout, stderr) {
                            const gif = await fs.readFileSync('./media/output.gif', { encoding: "base64" })
                            client.reply(from, 'Stickernya senpai!', id)
                            await client.sendImageAsSticker(from, `data:image/gif;base64,${gif.toString('base64')}`)
                        })
                    } else (
                        await client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.sticker* _[upload video/gif]_\nNote : video/gif maksimal 10 detik!', id)
                    )
                }
                break
        case '.snbg':  case '.stickernobg':
            if (isBlocked) return client.reply(from, mess.ban, id)
            const { RemoveBgResult, removeBackgroundFromImageBase64, removeBackgroundFromImageFile } = require('remove.bg')
            if (!isGroupMsg) return client.reply(from, 'Salah', id)
                if (isMedia && type === 'image') {
                    try {
                    var mediaData = await decryptMedia(message, uaOverride)
                    var imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                    var base64img = imageBase64
                    var outFile = './media/img/noBg.png' //5tHjBbPSh3gYoHD9rTqiVCa7 [ { title: 'Insufficient credits', code: 'insufficient_credits' } ]
                    var result = await removeBackgroundFromImageBase64({ base64img, apiKey: '4i6nGJjXhVBFUeDa6Pkqn9hg', size: 'auto', type: 'auto', outFile })
                        client.reply(from, 'Stickernya senpai!', id)
                        await fs.writeFile(outFile, result.base64img)
                        await client.sendImageAsSticker(from, `data:${mimetype};base64,${result.base64img}`)
                    } catch(err) {
                        console.log(err)
                        client.reply(from, `⚠️ Maaf senpai, tidak dapat mengidentifikasi background!`, id)
                    }
                    
                } else if (quotedMsg && quotedMsg.type == 'image') {
                    client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.stickernobg* _[upload gambar]_`, id) 
                } else {
                    client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.stickernobg* _[upload gambar]_`, id)
                }
                break
        case '.sti': case '.stickertoimage':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (args.length === 2) return client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.stickertoimage* _[reply sticker]_`, id)
            if (quotedMsg) {
                if( quotedMsg.type === 'sticker') {
                        mediaData = await decryptMedia(quotedMsg, uaOverride)
                        client.reply(from, 'Gambarnya senpai!', id)
                        await client.sendImage(from, `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`, `image.jpg`, ``)
                    } else {
                        client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.stickertoimage* _[reply sticker]_`, id)
                    }
                } else {
                    client.reply(from, `⚠️ Perintah salah senpai!\nContoh : *.stickertoimage* _[reply sticker]_`, id)
                }
            break
        case '.lirik':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length == 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.lirik* _judul/potongan lirik_', id)
            const lagu = body.slice(8)
            const lirik = await liriklagu(lagu)
            await client.reply(from, lirik, id)
            break
        case '.chord':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.chord* _artist/band judul_', id)
            const query__ = body.slice(7)
            const chord = await get.get('https://api.i-tech.id/tools/chord?key=JDPQSX-rz6Wf0-DgfTRY-SXsBB8-oX1ZMU&query='+ query__).json()
            if (chord.error) return client.reply(from, chord.error, id)
            await client.reply(from, chord.result, id)
            break

        case '.fb': //####################
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.fb* _link_\nContoh : *.fb* _https://web.facebook.com/watch/?v=299023470958021_\n*.fb* _https://web.facebook.com/TvKNHBI.AMKB.KALTARA/videos/299023470958021_', id)
            if (!args[1].includes('facebook.com')) return client.reply(from, mess.link, id)
            client.reply(from, mess.wait, id)
            const epbe = await fb(args[1])
            await client.sendFileFromUrl(from, epbe.url, `fb${epbe.exts}`, epbe.capt, id)
            break
        case '.igpic':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.igpic* _link_\nContoh : *.igpic* _https://www.instagram.com/p/CCvk2iZFzWJ_', id)
            const igpic = await get.get('https://mhankbarbar.herokuapp.com/api/ig?url='+args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (igpic.status == "false") return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, `${igpic.result}`, 'ig.jpg', `Nih senpai!`, id)
            break
        case '.igmp4':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.igmp4* _link_\nContoh : *.igmp4* _https://www.instagram.com/p/CCx37jUlwZo_', id)
            const igmp4 = await get.get('https://mhankbarbar.herokuapp.com/api/ig?url='+args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (igmp4.status == "false") return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, `${igmp4.result}`, 'ig.mp4.', `Nih senpai!`, id)
            break
        case '.tw':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.tw* _link_\nContoh : *.tw* _https://twitter.com/flirtchaes/status/1318506801189457921_', id)
            const tw = await get.get('https://mhankbarbar.herokuapp.com/api/twit?url='+args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (tw.status == "false") return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, `${tw.result}`, 'tw.mp4.', `${tw.quote}`, id)
            break
        case '.pic':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.pic* _link gambar_\nContoh : *.pic* _https://i.imgflip.com/41e671.png_', id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, args[1], 'pic.jpg', `Nih senpai!`, id)
            break
        case '.pin':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.pin* _link_\nContoh : *.pin* _https://id.pinterest.com/pin/129126714302845787_', id)
            const pin = await get.get('https://scrap.terhambar.com/pin?url='+args[1]).json()
            if (pin.status == "false") return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, `${pin.response.thumbnail}`, 'pin.jpg', `${pin.response.title}`, id)
            break
        case '.ytmp3':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
                if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.ytmp3* _link_\nContoh : *.ytmp3* _https://youtu.be/qDxrZyuRDKY_\nNote : Harus berupa shortlink, full link _https://www.youtube.com/watch?v=qDxrZyuRDKY_ tidak bisa senpai!', id)
                const ytmp3 = await get.get('https://mhankbarbar.herokuapp.com/api/yta?url='+args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
                if (ytmp3.error) {
                    await client.reply(from, mess.null, id)
                } else {
                    await client.reply(from, mess.wait, id)
                    await client.sendFileFromUrl(from, result, `${ytmp3.title}.mp3`, ``, id).catch(() => client.reply(from, mess.null, id))
                }
                break
        case '.ytmp4':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
                if (args.length === 1) return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.ytmp4* _link_\nContoh : *.ytmp4* _https://youtu.be/qDxrZyuRDKY_\nNote : Harus berupa shortlink, full link _https://www.youtube.com/watch?v=qDxrZyuRDKY_ tidak bisa senpai!', id)
                const ytmp4 = await get.get('https://mhankbarbar.herokuapp.com/api/ytv?url='+args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
                if (ytmp4.error) {
                    await client.reply(from, mess.null, id)
                } else {
                    await client.reply(from, mess.wait, id)
                    await client.sendFileFromUrl(from, result, `${ytmp4.title}.mp4`, `${ytmp4.title}`, id).catch(() => client.reply(from, mess.null, id))
                }
                break
 
        case '.play':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.play* _judul_\nContoh : *.play* _perawan atau janda_', id)
            const play = await get.get('https://api.vhtear.com/spotify?query='+args[1]+'&apikey=bot').json()
            await client.reply(from, mess.wait, id)
            if (play.result.result[0].music_prev == "null") return await client.reply(from, mess.null, id)
            await client.sendFileFromUrl(from, play.result.result[0].music_prev, 'play.mp3', ``, id)
            break
        case '.play2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.play2* _judul_\nContoh : *.play2* _perawan atau janda_', id)
            const play2 = await get.get('https://api.vhtear.com/music?query='+args[1]+'&apikey=bot').json()
            if (play2.result.response == "403") return client.reply(from, mess.null, id)
            await client.reply(from, mess.wait, id)
            await client.sendFileFromUrl(from, play2.result[0].linkMp3, 'play2.mp3', ``, id)
            break
        case '.play-bruh':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/bruh.mp3', 'play.mp3', '', id)
            break           
        case '.play-yoo':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/yoo.mp3', 'play.mp3', '', id)
            break 
        case '.play-sadviolin':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/sadviolin.mp3', 'play.mp3', '', id)
            break 
        case '.play-nope':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/nope.mp3', 'play.mp3', '', id)
            break        
        case '.play-wasted':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/wasted.mp3', 'play.mp3', '', id)
            break 
        case '.play-heheboi':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/heheboi.mp3', 'play.mp3', '', id)
            break 
        case '.play-reallynigga':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/reallynigga.mp3', 'play.mp3', '', id)
            break 
        case '.play-suprise':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/suprise.mp3', 'play.mp3', '', id)
            break   
        case '.play-xfiles':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/xfiles.mp3', 'play.mp3', '', id)
            break   
        case '.play-gay':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/gay.mp3', 'play.mp3', '', id)
            break  
        case '.play-yrug':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/yrug.mp3', 'play.mp3', '', id)
            break  
        case '.play-run':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/run.mp3', 'play.mp3', '', id)
            break   
        case '.play-tariksis':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/tariksis.mp3', 'play.mp3', '', id)
            break 
        case '.play-ubur':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/ubur.mp3', 'play.mp3', '', id)
            break 
        case '.play-slebor':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/slebor.mp3', 'play.mp3', '', id)
            break 
        case '.play-kumenangis':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/kumenangis.mp3', 'play.mp3', '', id)
            break      
        case '.play-ashiap':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/ashiap.mp3', 'play.mp3', '', id)
            break  
        case '.play-mabar':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/mabar.mp3', 'play.mp3', '', id)
            break  
        case '.play-hayyuk':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/hayyuk.mp3', 'play.mp3', '', id)
            break  
        case '.play-ara':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/araara.mp3', 'play.mp3', '', id)
            break 
        case '.play-wow':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/wow.mp3', 'play.mp3', '', id)
            break                           
        case '.play-nani':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/nani.mp3', 'play.mp3', '', id)
            break    
        case '.play-nico':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/nico.mp3', 'play.mp3', '', id)
            break   
        case '.play-baka':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/baka.mp3', 'play.mp3', '', id)
            break   
        case '.play-tobecontinued':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/tobecontinued.mp3', 'play.mp3', '', id)
            break   
        case '.play-tuturu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/ussr.mp3', 'play.mp3', '', id)
            break   
        case '.play-yare':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/yare.mp3', 'play.mp3', '', id)
            break   
        case '.play-zawarudo':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/zawarudo.mp3', 'play.mp3', '', id)
            break    
        case '.play-piao':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isCmd) return client.reply(from, mess.cmd, id)
            await client.reply(from, mess.wait, id)
            await client.sendFile(from, './media/play/piao.mp3', 'play.mp3', '', id)
            break

        case '.bot':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, bot, id)
            break
        case '.sk':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, sk, id)
            break
        case '.info':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, info, id)
            break
        case '.sc': case '.shortcut':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, shortcut, id)
            break
        case '.status': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            const ip = await get.get('https://ipapi.co/json').json()
            if (ip.country == "ID") {
                await client.reply(from, `Bot online senpai!\nVPN : OFF`, id)
            } else {
                await client.reply(from, `Bot online senpai!\nVPN : ON`, id)
            }
            break
        case '.donasi':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, donate, id)
            break
               
        case '.nm': case '.nsfwmenu':
            if (isBlocked) return client.reply(from, mess.ban, id)
            await client.reply(from, nsfwmenu, id)
            break
        case '.lewd': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const lewd = await get.get('https://meme-api.herokuapp.com/gimme/LewdThings').json()
            await client.sendFileFromUrl(from, lewd.url, 'lewd.jpg', lewd.title, id)
            break
        case '.bikini': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const bikini = await get.get('https://meme-api.herokuapp.com/gimme/bigtitsinbikinis').json()
            await client.sendFileFromUrl(from, bikini.url, 'bikini.jpg', bikini.title, id)
            break
        case '.cosplay': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const cosplay = ['cosplaygirls', 'cosplaybabes']
            let cosplay2 = cosplay[Math.floor(Math.random() * cosplay.length)]
            const cosplay3 = await get.get('https://meme-api.herokuapp.com/gimme/'+cosplay2).json()
            await client.sendFileFromUrl(from, cosplay3.url, 'cosplay.jpg', cosplay3.title, id)
            break
        case '.busty': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const busty = ['2busty', '2busty2hide']
            let busty2 = busty[Math.floor(Math.random() * busty.length)]
            const busty3 = await get.get('https://meme-api.herokuapp.com/gimme/'+busty2).json()
            await client.sendFileFromUrl(from, busty3.url, 'busty.jpg', busty3.title, id)
            break
        case '.onlyfans': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const onlyfans = ['Onlyfansluts', 'OnlyFansStars', 'OnlyFans_NonNude']
            let onlyfans2 = onlyfans[Math.floor(Math.random() * onlyfans.length)]
            const onlyfans3 = await get.get('https://meme-api.herokuapp.com/gimme/'+onlyfans2).json()
            await client.sendFileFromUrl(from, onlyfans3.url, 'onlyfans.jpg', onlyfans3.title, id)
            break
        case '.ecchi': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const ecchi = await get.get('https://meme-api.herokuapp.com/gimme/ecchi').json()
            await client.sendFileFromUrl(from, ecchi.url, 'ecchi.jpg', ecchi.title, id)
            break
        case '.hentai': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const hentai = await get.get('https://api.computerfreaker.cf/v1/hentai').json()
            await client.sendFileFromUrl(from, hentai.url, 'hentai.jpg', `Crot!`, id)
            break
        case '.milf': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const milf = await get.get('https://meme-api.herokuapp.com/gimme/AnimeMILFS').json()
            await client.sendFileFromUrl(from, milf.url, 'milf.jpg', milf.title, id)
            break 
        case '.lewdneko': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const lewdneko = await get.get('https://api.computerfreaker.cf/v1/nsfwneko').json()
            await client.sendFileFromUrl(from, lewdneko.url, 'lewdneko.jpg', `Nyan Nyan Crot!`, id)
            break
        case '.trap': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const trap = await get.get('https://api.computerfreaker.cf/v1/trap').json()
            await client.sendFileFromUrl(from, trap.url, 'trap.jpg', `Geh!`, id)
            break
        case '.rule34': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const rule34 = await get.get('https://meme-api.herokuapp.com/gimme/rule34').json()
            await client.sendFileFromUrl(from, rule34.url, 'rule34.jpg', rule34.title, id)
            break
        case '.nuke': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const nuke = [
            'LOLI',
            'ONEE-SAN',
            'MILF',
            'MOTHER',
            'TEACHER',
            'NETORARE (NTR)',
            'VANILLA',
            'UGLY BASTARD',
            'ELF',
            'RAPE',
            'SLAVE',
            'TENTACLE',
            'PAIZURI',
            'RANDOM',
            'AHEGAO',
            'PREGNANT',
            'GURO',
            'SCAT',
            'FUTA',
            'TRAP',
            'ANAL',
            'VIRGIN',
            'DOG',
            'HORSE',
            'INCEST',
            'BESTIALITY',
            'YURI',
            'YAOI',
            'MASTURBATION',
            'SEX TOYS',
            'ALIEN',
            'MIND BREAK',
            'PROSTITUTION',
            'MAID',
            'BIG ASS',
            'BIG BOOBS',
            'SLEEPING',
            'SISTER',
            'DAUGHTER',
            'AUNT',
            'NURSE',
            ]
            const nuke2 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const nuke3 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
            const nuke4 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const nuke5 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const nuke6 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const nuke7 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
            let nuke9 = nuke[Math.floor(Math.random() * nuke.length)]              
            let nuke10 = nuke2[Math.floor(Math.random() * nuke2.length)]
            let nuke11 = nuke3[Math.floor(Math.random() * nuke3.length)]
            let nuke12 = nuke4[Math.floor(Math.random() * nuke4.length)]
            let nuke13 = nuke5[Math.floor(Math.random() * nuke5.length)]
            let nuke14 = nuke6[Math.floor(Math.random() * nuke6.length)]
            let nuke15 = nuke7[Math.floor(Math.random() * nuke7.length)]
            await client.reply(from, `${nuke9}\nhttps://nhentai.net/${nuke10}${nuke11}${nuke12}${nuke13}${nuke14}${nuke15}`, id)
            break
        case '.jav': 
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            const jav = [
            'EMIRI SUZUHARA',
            'REINA KASHIMA',
            'MEGU FUJIURA',
            'NENE YOSHITAKA',
            'KANON KANADE',
            'YUA MIKAMI',
            'AIMI YOSHIKAWA',
            'ROLA TAKIZAWA',
            'AI UEHARA',
            'RIA SAKURAI',
            'ANRI OKITA',
            'RISA TACHIBANA',
            'KANA YUME',
            'AIRI SUZUMURA',
            'SUZU HONJO',
            'KARINA NISHIDA',
            'AMERI ICHINOSE',
            'NON NONOURA',
            'SHION UTSUNOMIYA',
            'MAKO ODA',
            'SORA AMAKAWA',
            'RIHO HORI',
            'YUI HATANO',
            'SUZU TAKACHIHO',
            'MARIA WAKUI',
            'MARIA NAGAI',
            'AIKA',
            'EMA SHIIBA',
            'NOZOMI KITANO',
            'KIRARA ASUKA',
            'EMA YUMEKAWA',
            'BENI ITOU',
            'YUNA SHIINA',
            'ICHIKA HOSHIMIYA',
            'HARUKA KASUMI',
            'CHINA MATSUOKA',
            'AOI TSUKASA',
            'MOMO SAKURA',
            'MAKI HOJO',
            'YURIA SATOMI',
            'YURI OSHIKAWA',
            'KOTONE SUZUMIYA',
            'HARUKI SATO',
            'AKI SASAKI',
            'RENA FUKIISHI',
            'AKINA KOKORONO',
            'KARIN AIZAWA',
            'AN TSUJIMOTO',
            'MARIE SHIRAISHI',
            'HITOMI TANAKA',
            'EIMI FUKUDA',
            ]
            const jav2 = ['A', 'B','C', 'D', 'E', 'F', 'G','H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
            const jav3 = ['A', 'B','C', 'D', 'E', 'F', 'G','H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'] 
            const jav4 = ['A', 'B','C', 'D', 'E', 'F', 'G','H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
            const jav5 = ['A', 'B','C', 'D', 'E', 'F', 'G','H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
            const jav6 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            const jav7 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
            const jav8 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
            let jav9 = jav[Math.floor(Math.random() * jav.length)]              
            let jav10 = jav2[Math.floor(Math.random() * jav2.length)]
            let jav11 = jav3[Math.floor(Math.random() * jav3.length)]
            let jav12 = jav4[Math.floor(Math.random() * jav4.length)]
            let jav13 = jav5[Math.floor(Math.random() * jav5.length)]
            let jav15 = jav6[Math.floor(Math.random() * jav6.length)]
            let jav16 = jav7[Math.floor(Math.random() * jav7.length)]
            let jav17 = jav8[Math.floor(Math.random() * jav8.length)]
            await client.reply(from, `${jav9} ${jav10}${jav11}${jav12}${jav13}-${jav15}${jav16}${jav17}`, id)
            break
        case '.cerdas':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            await client.reply(from, cerdas, id)
            break
        case '.nh': case '.nhentai':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1) client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.nhentai* _kode_\nContoh : *.nhentai* _177013_', id)
            const nhentai = await get.get('https://nhentai.net/api/gallery/'+args[1]).json()
            await client.reply(from, `${nhentai.title.english}\nMedia Id : ${nhentai.media_id}\nhttps://nhentai.net/${nhentai.id}`, id)
            break
        case '.nh2': case '.nhentai2':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1) client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.nhentai* _kata kunci_\nContoh : *.nhentai* _tsunade_', id)
            const nhentai2 = await get.get('https://nhentai.net/api/galleries/search?query='+args[1]).json()
            await client.reply(from, `${nhentai2.result[0].title.english}\nMedia Id : ${nhentai2.result[0].media_id}\nhttps://nhentai.net/${nhentai2.result[0].id}`, id)
            break
        case '.nh3': case '.nhentai3':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1) client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.nhentai2* _kode_\nContoh : *.nhentai2* _tsunade_', id)
            const nhentai3 = await get.get('https://nhentai.net/api/galleries/search?query='+args[1]).json()
            const nhentai4 = `${nhentai3.result[0].title.english}\nMedia Id : ${nhentai3.result[0].media_id}\nhttps://nhentai.net/${nhentai3.result[0].id}`
            const nhentai5 = `${nhentai3.result[1].title.english}\nMedia Id : ${nhentai3.result[1].media_id}\nhttps://nhentai.net/${nhentai3.result[1].id}`
            const nhentai6 = `${nhentai3.result[2].title.english}\nMedia Id : ${nhentai3.result[2].media_id}\nhttps://nhentai.net/${nhentai3.result[2].id}`
            const nhentai7 = `${nhentai3.result[3].title.english}\nMedia Id : ${nhentai3.result[3].media_id}\nhttps://nhentai.net/${nhentai3.result[3].id}`
            const nhentai8 = `${nhentai3.result[4].title.english}\nMedia Id : ${nhentai3.result[4].media_id}\nhttps://nhentai.net/${nhentai3.result[4].id}`
            const nhentai9 = `${nhentai3.result[5].title.english}\nMedia Id : ${nhentai3.result[5].media_id}\nhttps://nhentai.net/${nhentai3.result[5].id}`
            const nhentai10 = `${nhentai3.result[6].title.english}\nMedia Id : ${nhentai3.result[6].media_id}\nhttps://nhentai.net/${nhentai3.result[6].id}`
            const nhentai11 = `${nhentai3.result[7].title.english}\nMedia Id : ${nhentai3.result[7].media_id}\nhttps://nhentai.net/${nhentai3.result[7].id}`
            const nhentai12 = `${nhentai3.result[8].title.english}\nMedia Id : ${nhentai3.result[8].media_id}\nhttps://nhentai.net/${nhentai3.result[8].id}`
            const nhentai13 = `${nhentai3.result[9].title.english}\nMedia Id : ${nhentai3.result[9].media_id}\nhttps://nhentai.net/${nhentai3.result[9].id}`
            await client.reply(from, `${nhentai4}\n\n${nhentai5}\n\n${nhentai6}\n\n${nhentai7}\n\n${nhentai8}\n\n${nhentai9}\n\n${nhentai10}\n\n${nhentai11}\n\n${nhentai12}\n\n${nhentai13}`, id)
            break
        case '.nhp': case '.nhpage':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1) client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.nhpage* _media id/halaman_\nContoh : *.nhpage* _987560/1_\nNote : media id beda dengan kode, silahkan cek media id dengan perintah *.nhentai*, *.nhentai2* & *.nhentai3*', id)
            const nhpage = 'https://i.nhentai.net/galleries/'+args[1]+'.jpg'
            await client.sendFileFromUrl(from, nhpage, 'nhpage.jpg', `Crot!`, id)
            break
        case '.x': case '.xnxx':
            if (isBlocked) return client.reply(from, mess.ban, id)
            if (!isGroupMsg) return client.reply(from, mess.group, id)
            if (!isNsfw) return client.reply(from, mess.nsfw, id)
            if (args.length === 1)  return client.reply(from, '⚠️ Perintah salah senpai!\nContoh : *.xnxx* _link_\nContoh : *.xnxx* _https://www.xnxx.com/video-u5m5l92/i_tried_', id)
            const xnxx = await get.get('https://mhankbarbar.herokuapp.com/api/xnxx?url='+args[1]+'&apiKey=7eqNrrqr6UxSlck3uGDF').json()
            if (xnxx.result.error) return client.reply(from, mess.null, id)
            await client.sendFileFromUrl(from, xnxx.result.thumb, 'xnxx.jpg', `Title : ${xnxx.result.judul}\nSize : ${xnxx.result.size}\n\n⏳ Sedang di proses, silahkan tunggu sebentar senpai!`, id)
            await client.sendFileFromUrl(from, xnxx.result.vid, 'xnxx.mp4', xnxx.result.judul, id)
            break
        }
    } catch (err) {
        console.log(color('[ERROR].', 'red'), err)
    }
}
